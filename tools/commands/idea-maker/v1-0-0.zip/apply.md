---
name: idea-maker-apply
description: Generate project requirement document from idea checklist
---

# Idea Maker - Create Requirement Document

## Usage

Transform your idea checklist into a comprehensive project requirement document.

## Command Behavior

When invoked, this command will:

1. **Read checklist** - Load the idea file from `idea-maker-progress/{idea-name}.md`
2. **Create requirement folder** - Initialize `requirement/` directory (if not exists)
3. **Generate short name** - Create a concise identifier (max 20 characters)
4. **Work through checklist** - Address each unchecked item to build the requirement:
   - Elaborate on core features
   - Detail technical requirements
   - Specify user experience needs
   - Define success criteria
5. **Update progress** - Mark completed checklist items with `[x]`
6. **Create requirement document** - Generate comprehensive markdown file
7. **Save requirement** - Write to `requirement/{idea-short-name}-requirement.md`
8. **Update status** - Change idea status field (Not Started → In Progress → Completed)

## Workflow

### Initial State (idea-maker-progress/personal-habit-tracking-app.md)
```markdown
**Status**: Not Started

## Requirement Checklist
- [ ] Define core features
- [ ] Specify technical requirements
- [ ] Document user experience
- [ ] Define success criteria
```

### During Execution
```markdown
**Status**: In Progress

## Requirement Checklist
- [x] Define core features
- [x] Specify technical requirements ← Currently working on
- [ ] Document user experience
- [ ] Define success criteria
```

### Completion
```markdown
**Status**: Completed

## Requirement Checklist
- [x] Define core features
- [x] Specify technical requirements
- [x] Document user experience
- [x] Define success criteria
```

## Requirement Document Format

The generated requirement file will follow this structure:

```markdown
# Project Requirement: {Idea Name}

**Created**: {date}
**Version**: 1.0
**Status**: Draft

---

## 1. Executive Summary
{High-level overview of the project}

## 2. Problem Statement
{Detailed description of the problem being solved}

## 3. Target Audience
{Who will use this and their characteristics}

## 4. Functional Requirements

### 4.1 Core Features
- **Feature 1**: {Description, acceptance criteria}
- **Feature 2**: {Description, acceptance criteria}

### 4.2 User Stories
- As a {user type}, I want to {action} so that {benefit}

## 5. Technical Requirements

### 5.1 Technology Stack
- Frontend: {technologies}
- Backend: {technologies}
- Database: {technologies}
- Infrastructure: {requirements}

### 5.2 Non-Functional Requirements
- Performance: {requirements}
- Security: {requirements}
- Scalability: {requirements}
- Compatibility: {requirements}

## 6. User Experience Requirements

### 6.1 User Interface
- {UI specifications}

### 6.2 User Flow
- {Key user journeys}

### 6.3 Accessibility
- {Accessibility requirements}

## 7. Success Criteria
- [ ] Metric 1: {Description and target}
- [ ] Metric 2: {Description and target}

## 8. Constraints and Assumptions
- {Technical constraints}
- {Budget constraints}
- {Timeline assumptions}
- {Resource assumptions}

## 9. Risks and Mitigation
| Risk | Impact | Likelihood | Mitigation Strategy |
|------|--------|------------|---------------------|
| {Risk 1} | {High/Med/Low} | {High/Med/Low} | {Strategy} |

## 10. Timeline and Milestones
- **Phase 1**: {Description and duration}
- **Phase 2**: {Description and duration}

## 11. Dependencies
- {External dependencies}
- {Internal dependencies}

## 12. Appendices
- {Supporting documents}
- {References}
- {Glossary}
```

## Example Usage

**User request:**
```bash
/idea-maker-apply personal-habit-tracking-app
```

**Command actions:**
1. Opens `idea-maker-progress/personal-habit-tracking-app.md`
2. Creates `requirement/` folder (if not exists)
3. Generates short name: `habit-tracker` (20 chars max)
4. Works through each checklist item
5. Creates `requirement/habit-tracker-requirement.md`
6. Marks checklist items as `[x]` when completed
7. Updates idea file status to "Completed"

**Output:**
```
Created: requirement/habit-tracker-requirement.md
Status: All requirement items documented
Progress: 4/4 checklist items completed ✓
```

## Short Name Generation

The command will automatically generate a short name (max 20 characters) by:
1. Taking key words from the idea name
2. Removing common words (a, the, for, etc.)
3. Using kebab-case format
4. Truncating to 20 characters if needed

Examples:
- "Personal Habit Tracking App" → `habit-tracker`
- "AI-Powered Content Recommendation Engine" → `ai-content-rec`
- "Real-time Collaborative Whiteboard" → `collab-whiteboard`

## Implementation Guidelines

1. **Show Progress** - Display current completion percentage as you work
2. **One at a Time** - Focus on one checklist section at a time
3. **Be Comprehensive** - Expand each item with sufficient detail
4. **Ask for Input** - Prompt user for clarification when needed
5. **Verify Completion** - Ensure each section is fully documented before checking off
6. **Add Timestamp** - Include "Last Updated" field when saving
7. **Version Control** - Track requirement document versions for changes
8. **Interactive Review** - After generating, ask if any section needs expansion
