---
name: idea-maker
description: Interactive idea expansion and requirement generation workflow
---

# Idea Maker

A three-phase workflow for transforming ideas into comprehensive project requirements through interactive exploration, documentation, and archival.

## Overview

The Idea Maker workflow helps you:
1. **Expand** ideas through guided conversation
2. **Generate** structured requirement documents
3. **Archive** completed ideas for future reference

## Workflow Phases

### Phase 1: Append - Expand Your Idea
**Command**: `/idea-maker-append`

Interactive brainstorming session that:
- Asks clarifying questions about your idea
- Explores problem statement, audience, and features
- Documents collective insights
- Creates a requirement checklist
- Saves to `idea-maker-progress/{idea-name}.md`

**Example:**
```bash
/idea-maker-append

# Claude will guide you through questions like:
# - What problem are you solving?
# - Who is your target audience?
# - What are the key features?
# - What are the technical considerations?
```

### Phase 2: Apply - Create Requirement Document
**Command**: `/idea-maker-apply {idea-name}`

Transforms your checklist into a comprehensive requirement document:
- Reads your idea checklist
- Works through each requirement item
- Creates detailed specification
- Generates `requirement/{idea-short-name}-requirement.md`
- Updates checklist progress

**Example:**
```bash
/idea-maker-apply personal-habit-tracking-app

# Creates: requirement/habit-tracker-requirement.md
# With sections: Executive Summary, Problem Statement,
# Functional Requirements, Technical Specs, Success Criteria, etc.
```

### Phase 3: Archive - Store Completed Ideas
**Command**: `/idea-maker-archive {idea-name}`

Archives completed ideas for historical reference:
- Verifies completion and requirement document
- Adds completion metadata
- Moves to `idea-maker-progress/archived/YYYY-MM/`
- Updates INDEX.md with cross-references
- Links to requirement document

**Example:**
```bash
/idea-maker-archive personal-habit-tracking-app

# Moves to: idea-maker-progress/archived/2025-11/
# Updates: idea-maker-progress/archived/INDEX.md
# Preserves link to: requirement/habit-tracker-requirement.md
```

## Complete Workflow Example

```bash
# 1. Start with an idea
/idea-maker-append
User: "I want to build a task management app"

# Claude asks questions, documents insights
# Creates: idea-maker-progress/task-management-app.md

# 2. Generate requirement document
/idea-maker-apply task-management-app

# Claude works through checklist
# Creates: requirement/task-mgmt-app-requirement.md

# 3. Archive when complete
/idea-maker-archive task-management-app

# Moves to: idea-maker-progress/archived/2025-11/task-management-app.md
# Updates: idea-maker-progress/archived/INDEX.md
```

## Directory Structure

```
project-root/
├── idea-maker-progress/
│   ├── active-idea-1.md
│   ├── active-idea-2.md
│   └── archived/
│       ├── INDEX.md
│       ├── 2025-10/
│       │   └── completed-idea-1.md
│       └── 2025-11/
│           └── completed-idea-2.md
│
└── requirement/
    ├── active-req-1-requirement.md
    ├── active-req-2-requirement.md
    ├── completed-req-1-requirement.md
    └── completed-req-2-requirement.md
```

## Key Features

- **Interactive Exploration**: Guided questions to fully flesh out ideas
- **Structured Documentation**: Consistent requirement format
- **Progress Tracking**: Checkbox-based task completion
- **Historical Archive**: Organized by completion date
- **Cross-Referencing**: Links between ideas and requirements
- **Short Name Generation**: Auto-creates concise identifiers (max 20 chars)

## When to Use

Use Idea Maker when you:
- Have a rough concept that needs exploration
- Want to transform ideas into actionable requirements
- Need structured documentation for project planning
- Want to maintain a record of idea evolution
- Are starting a new project or feature

## Notes

- Each phase builds on the previous one
- Idea files track progress with checkboxes
- Requirement documents follow a comprehensive template
- Archives maintain searchable index with cross-references
- Short names are auto-generated (kebab-case, max 20 chars)
- Interactive sessions help uncover hidden requirements

## Tips

1. **Be thorough in append phase** - Better exploration leads to better requirements
2. **Answer questions completely** - More detail = more comprehensive requirements
3. **Review generated requirements** - You can always refine after apply
4. **Archive regularly** - Keep active directory focused on current work
5. **Use INDEX.md** - Search archives to avoid duplicate ideas
