---
name: idea-maker-append
description: Expand ideas interactively and create project requirement checklists
---

# Idea Maker - Expand Ideas

## Usage

Add a new idea and expand it through interactive discussion to create a comprehensive project requirement checklist.

## Command Behavior

When invoked, this command will:

1. **Create working directory** - Initialize `idea-maker-progress/` folder (if not exists)
2. **Gather initial idea** - Understand the core concept from the user
3. **Interactive expansion** - Ask clarifying questions to explore:
   - What problem does this solve?
   - Who is the target audience/users?
   - What are the key features?
   - What are the technical considerations?
   - What are potential challenges?
   - What does success look like?
4. **Note collective ideas** - Document all insights and discussions
5. **Create requirement checklist** - Generate a structured list of what needs to be included in the project requirement
6. **Save to progress folder** - Store in `idea-maker-progress/{idea-name}.md`

## Checklist Format

```markdown
# Idea: {Idea Name}

**Created**: {date}
**Status**: Not Started
**Priority**: {High/Medium/Low}

## Overview
{Brief description of the idea}

## Problem Statement
{What problem does this solve?}

## Target Audience
{Who will use this?}

## Key Insights
{Collective ideas and discussions from the interactive session}

## Requirement Checklist

### Core Features
- [ ] Define feature 1
- [ ] Define feature 2

### Technical Requirements
- [ ] Specify technical requirement 1
- [ ] Specify technical requirement 2

### User Experience
- [ ] Document UX requirement 1
- [ ] Document UX requirement 2

### Success Criteria
- [ ] Define success metric 1
- [ ] Define success metric 2

## Notes
{Any additional context, constraints, or considerations}
```

## Example Usage

**User request:**
```
/idea-maker-append
User: "I want to create a personal habit tracking app"
```

**Command generates:**
```
idea-maker-progress/
├── personal-habit-tracking-app.md
└── archived/  (created if doesn't exist)
```

**Interactive flow:**
1. Claude: "What specific problem are you trying to solve with habit tracking?"
2. User responds...
3. Claude: "Who is your target audience - individuals, teams, or both?"
4. User responds...
5. Claude: "What are the must-have features vs nice-to-have?"
6. ...and so on

## Implementation Guidelines

1. **Be Conversational** - Make the interaction feel like brainstorming with a colleague
2. **Ask One Question at a Time** - Don't overwhelm with multiple questions
3. **Build on Responses** - Use previous answers to inform next questions
4. **Capture Everything** - Document all ideas, even if they seem tangential
5. **Organize Logically** - Structure the checklist into clear categories
6. **Be Specific** - Each checklist item should be actionable for requirement writing
7. **Reasonable Scope** - Break large concepts into manageable requirement items
