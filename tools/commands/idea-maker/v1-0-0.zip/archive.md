---
name: idea-maker-archive
description: Archive completed idea checklists for record-keeping
---

# Idea Maker - Archive Completed Ideas

## Usage

Archive completed idea checklists to keep the active ideas directory clean and maintain a historical record.

## Command Behavior

When invoked, this command will:

1. **Verify completion** - Check that all checklist items are marked `[x]` and status is "Completed"
2. **Verify requirement exists** - Confirm that `requirement/{idea-short-name}-requirement.md` was created
3. **Add completion metadata** - Update idea file with completion timestamp and requirement link
4. **Create archive structure** - Ensure `idea-maker-progress/archived/YYYY-MM/` exists
5. **Move to archive** - Relocate from `idea-maker-progress/` to `idea-maker-progress/archived/YYYY-MM/`
6. **Update index** - Add entry to `idea-maker-progress/archived/INDEX.md`
7. **Confirm action** - Show success message with archive location and requirement file reference

## Directory Structure

### Before Archive
```
idea-maker-progress/
├── personal-habit-tracking-app.md
├── ai-content-recommendation.md
└── archived/
    └── INDEX.md

requirement/
├── habit-tracker-requirement.md
└── ai-content-rec-requirement.md
```

### After Archive
```
idea-maker-progress/
├── ai-content-recommendation.md
└── archived/
    ├── INDEX.md
    └── 2025-11/
        └── personal-habit-tracking-app.md

requirement/
├── habit-tracker-requirement.md
└── ai-content-rec-requirement.md
```

## Archive Format

Ideas are organized by completion month:
- `idea-maker-progress/archived/YYYY-MM/{idea-name}.md`

The INDEX.md maintains a searchable list with requirement references:

```markdown
# Archived Ideas

## 2025-11

- [Personal Habit Tracking App](2025-11/personal-habit-tracking-app.md)
  - **Completed**: 2025-11-18
  - **Requirement**: `requirement/habit-tracker-requirement.md`
  - **Priority**: High
  - **Summary**: Mobile app for tracking daily habits with analytics

- [AI Content Recommendation Engine](2025-11/ai-content-recommendation.md)
  - **Completed**: 2025-11-15
  - **Requirement**: `requirement/ai-content-rec-requirement.md`
  - **Priority**: Medium
  - **Summary**: ML-powered content recommendation system

## 2025-10

- [Real-time Collaborative Whiteboard](2025-10/collab-whiteboard.md)
  - **Completed**: 2025-10-28
  - **Requirement**: `requirement/collab-whiteboard-requirement.md`
  - **Priority**: High
  - **Summary**: WebRTC-based collaborative drawing tool
```

## Archived Idea File Format

When archiving, the idea file gets updated with completion metadata:

```markdown
# Idea: Personal Habit Tracking App

**Created**: 2025-11-10
**Completed**: 2025-11-18
**Status**: Completed ✓
**Priority**: High
**Requirement Document**: `requirement/habit-tracker-requirement.md`

## Overview
{Original overview}

## Requirement Checklist
- [x] Define core features
- [x] Specify technical requirements
- [x] Document user experience
- [x] Define success criteria

**All checklist items completed**: 2025-11-18

---

## Archive Notes
- Successfully generated comprehensive requirement document
- Ready for implementation phase
- All stakeholder questions addressed during expansion
```

## Example Usage

**User request:**
```bash
/idea-maker-archive personal-habit-tracking-app
```

**Command actions:**
1. Opens `idea-maker-progress/personal-habit-tracking-app.md`
2. Verifies all checklist items are `[x]` ✓
3. Verifies `requirement/habit-tracker-requirement.md` exists ✓
4. Adds completion timestamp: "Completed: 2025-11-18"
5. Adds requirement link to idea file
6. Creates `idea-maker-progress/archived/2025-11/` (if not exists)
7. Moves to `idea-maker-progress/archived/2025-11/personal-habit-tracking-app.md`
8. Updates `idea-maker-progress/archived/INDEX.md`
9. Confirms archival

**Output:**
```
✓ Idea archived successfully

Archived to: idea-maker-progress/archived/2025-11/personal-habit-tracking-app.md
Requirement: requirement/habit-tracker-requirement.md
Completed: 2025-11-18

Summary:
- 4/4 checklist items completed
- Requirement document generated
- Ready for implementation
```

## Validation Checks

Before archiving, the command validates:

| Check | Requirement | Action if Failed |
|-------|-------------|------------------|
| All checklist items checked | All items must be `[x]` | Abort and list incomplete items |
| Status is "Completed" | Status field must show "Completed" | Abort and show current status |
| Requirement file exists | `requirement/{short-name}-requirement.md` must exist | Abort and prompt to run apply first |
| File not already archived | Idea file must be in active directory | Abort and show archive location |

## Implementation Guidelines

1. **Validate Completion** - Only archive 100% completed ideas with requirement documents
2. **Preserve History** - Don't modify original idea content, only add completion metadata
3. **Maintain Index** - Always update INDEX.md for searchability and cross-referencing
4. **Date-based Organization** - Use YYYY-MM folder structure for chronological organization
5. **Link Requirements** - Always reference the requirement document location
6. **Confirm Action** - Show clear confirmation with both archive and requirement paths
7. **Error Handling** - Provide helpful error messages if validation fails
8. **Undo Capability** - Document how to restore archived ideas if needed

## Restoring Archived Ideas

If an idea needs to be revisited:

```bash
# Manual restoration (document for users)
# Move from: idea-maker-progress/archived/2025-11/{idea-name}.md
# Back to: idea-maker-progress/{idea-name}.md
# Update INDEX.md to remove the entry
# Update idea status back to "In Progress" if needed
```

## Best Practices

- ✅ Only archive after requirement document is reviewed
- ✅ Keep archive INDEX.md updated for easy searching
- ✅ Reference requirement documents in archive entries
- ✅ Use completion date in archive organization
- ✅ Preserve all original idea content and discussions

- ❌ Don't archive incomplete ideas
- ❌ Don't archive without requirement document
- ❌ Don't modify original idea insights during archival
- ❌ Don't skip INDEX.md updates
- ❌ Don't archive ideas still being refined
