# github-api

GitHub API patterns and best practices for cntm development. Use when implementing GitHub client, handling authentication, rate limits, or repository operations.

## Type

skill

## Usage

This skill helps with [describe usage here].

## Features

- Feature 1
- Feature 2
- Feature 3

## Configuration

[Describe any configuration options]

## Examples

[Provide usage examples]

## License

[Your license here]
