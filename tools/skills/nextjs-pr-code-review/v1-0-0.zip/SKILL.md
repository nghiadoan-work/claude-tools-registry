---
name: nextjs-pr-code-review
description: Reviews pull requests and code changes for the Residence Backoffice project, enforcing 90+ project-specific coding rules across 14 categories including clean architecture, state management with React Query, TanStack Table patterns, naming conventions, i18n, security, and TypeScript patterns. Use when reviewing PRs, checking code compliance, or validating architectural patterns for Next.js App Router with TypeScript projects.
---

# PR Code Review - Residence Backoffice

## Overview

This skill enforces Residence Backoffice project's specific coding standards across 14 rule categories with 90+ specific rules. Use this when reviewing pull requests or checking code compliance.

## Rule Categories

The project enforces rules across these categories (see references/ for details):

1. **Project Structure** (STRUCT-*) - Layer organization and dependencies
2. **Tech Stack** (TECH-*) - Approved/forbidden dependencies
3. **Clean Architecture** (ARCH-*) - Data flow and layer responsibilities  
4. **State Management** (STATE-*) - React Query patterns and custom hooks
5. **Networking** (NET-*) - API routes and data fetching
6. **Naming** (NAME-*) - File, directory, and symbol conventions
7. **Testing** (TEST-*) - Test strategies and patterns
8. **Tables** (TABLE-*) - TanStack Table usage requirements
9. **Routing & i18n** (I18N-*, ROUTE-*) - Localization and routing patterns
10. **Dependency Injection** (DI-*) - Manual DI in API routes
11. **Caching** (CACHE-*) - Server-side caching strategies
12. **Forms** (FORM-*) - React Hook Form with Zod validation
13. **Security** (SEC-*) - Input validation and environment variables
14. **UI & Theming** (UI-*) - shadcn/ui components and design tokens

## Review Process

### Automated Review Workflow (Recommended)

When asked to review a PR, follow this automated workflow:

**Step 1: Gather PR Information**
```bash
# Get PR metadata
gh pr view {PR_NUMBER} --json title,body,headRefName,baseRefName,state,changedFiles,additions,deletions,headRefOid

# Get complete list of ALL changed files (no limit)
gh pr view {PR_NUMBER} --json files --jq '.files[].path'
```

**Step 2: Categorize Files by Layer**
```bash
# Group files by layer for systematic review
gh pr view {PR_NUMBER} --json files --jq '.files[].path' | grep -E "src/hooks/"
gh pr view {PR_NUMBER} --json files --jq '.files[].path' | grep -E "src/app/.*page\.tsx$"
gh pr view {PR_NUMBER} --json files --jq '.files[].path' | grep -E "src/app/api/.*/route\.ts$"
gh pr view {PR_NUMBER} --json files --jq '.files[].path' | grep -E "src/domain/use-cases/"
```

**Step 3: Review Each File**
For each changed file:
1. Read the file content from the local repository using the Read tool
2. Apply layer-specific rules (see Layer-by-Layer Examination below)
3. Document violations with:
   - Rule ID (e.g., SEC-4, STRUCT-3)
   - File path and line number
   - Issue description
   - Suggested fix with code example

**Step 4: Compile Issues List**
Create a structured list of all violations:
```typescript
interface CodeIssue {
  ruleId: string;
  severity: 'critical' | 'major' | 'minor';
  file: string;
  line: number;
  description: string;
  suggestedFix: string;
}
```

**Step 5: Create GitHub Pending Review**
Use GitHub MCP to create a pending review with inline comments:

```typescript
// 1. Create pending review
mcp__github__create_pending_pull_request_review({
  owner: "central-pattana-ex",
  repo: "residence-backoffice",
  pullNumber: PR_NUMBER,
  commitID: HEAD_COMMIT_SHA
})

// 2. Add comment for each violation
mcp__github__add_comment_to_pending_review({
  owner: "central-pattana-ex",
  repo: "residence-backoffice",
  pullNumber: PR_NUMBER,
  path: "src/path/to/file.ts",
  line: 50,
  side: "RIGHT",
  body: `**[SEC-4] Missing Input Validation**

Issue: POST endpoint lacks comprehensive Zod schema validation.

Fix:
\`\`\`typescript
const Schema = z.object({ ... });
const validated = Schema.parse(payload);
\`\`\`
`
})

// 3. STOP HERE - User will submit manually
// DO NOT call submit_pending_pull_request_review
// User will review comments and submit via GitHub UI or:
// gh pr review {PR_NUMBER} --approve / --request-changes / --comment
```

**Important Notes:**
- Review ALL files individually, regardless of PR size (even 100+ files)
- Read each file using the Read tool to check against coding rules
- Group files by layer for systematic review (API routes → hooks → domain → pages → UI)
- Always include code examples in suggested fixes
- **DO NOT auto-submit**: Stop after adding all comments, let user review and submit manually
- Provide summary of violations found so user knows what to expect in the pending review

### 1. Initial Analysis
- Read PR description and understand scope
- Identify affected layers (domain, infrastructure, hooks, app, ui)
- Note any breaking changes

### 2. Layer-by-Layer Examination

**Domain Layer** (`src/domain/`):
- Check: No imports from other layers (STRUCT-1)
- Check: Framework-agnostic code only
- Check: Proper `.use-case.ts` and `.types.ts` suffixes (NAME-5)

**Infrastructure Layer** (`src/infrastructure/`):
- Check: Repositories have `.repository.ts` suffix (NAME-5)
- Check: No business logic, data access only (ARCH-5)
- Check: No imports from app/ui layers (STRUCT-2)

**Hooks Layer** (`src/hooks/`):
- Check: Using React Query (`useQuery`/`useMutation`) not manual fetch (STATE-1)
- Check: Explicit return type interfaces (STATE-7, TABLE-2)
- Check: Proper `queryKey` structure (STATE-2)
- Check: Cache invalidation after mutations (STATE-3)
- Check: Using configured Axios client from `@/lib/api/client` (NET-1)

**App Layer** (`src/app/`):
- Check: Pages use custom hooks only, no direct useState/useEffect (STRUCT-3)
- Check: API routes have proper error handling (NET-2)
- Check: API routes use manual DI (instantiate repo → inject to use case) (DI-1, DI-3)
- Check: No business logic in API routes (ARCH-3)

**UI Layer** (`src/ui/`):
- Check: Components receive data via props only (STRUCT-4)
- Check: No API calls or React Query hooks (ARCH-1)
- Check: Using shadcn/ui components (UI-1)
- Check: Semantic color classes (bg-primary) not hardcoded (bg-blue-500) (UI-2)

**Tables**:
- Check: Using TanStack Table, not manual pagination (TABLE-1)
- Check: Type-safe column helper with `createColumnHelper<T>()` (TABLE-3)
- Check: Columns wrapped in `useMemo` (TABLE-4)

**i18n**:
- Check: No hardcoded user-facing text (I18N-1)
- Check: Translation namespaces registered in `src/lib/i18n/request.ts` (I18N-2)
- Check: Correct scoped translation usage (I18N-3)

**Security**:
- Check: All input validated with Zod (SEC-4)
- Check: Environment variables validated on startup (SEC-1)
- Check: Using Keycloak for auth (SEC-7)

### 3. Output Format

Structure feedback by severity:

```markdown
## PR Review: [Title]

### Summary
[Brief assessment and total violations]

### 🔴 CRITICAL ISSUES (Must Fix)

#### [RULE-ID] - [Rule Name]
**Location**: `path/to/file.ts:line`
**Issue**: [Description]
**Impact**: [Why critical]
**Fix**: [Solution with code example]

### 🟡 MAJOR CONCERNS (Should Address)
[Same format]

### 🟢 MINOR SUGGESTIONS (Optional)
[Improvements]

### ✅ POSITIVE OBSERVATIONS
[Good practices]

### VIOLATIONS SUMMARY
| Rule ID | Severity | Count |
|---------|----------|-------|
| STRUCT-3 | 🔴 | 2 |

### RECOMMENDATION
- [ ] Approved
- [ ] Approved with comments  
- [x] Changes requested
- [ ] Needs discussion

### NEXT STEPS
1. [Prioritized action items]
```

## Common Violations

**Most Frequent Critical Violations:**

1. **STRUCT-3**: Pages with direct useState/useEffect
   - Fix: Extract to custom hook in `src/hooks/`

2. **STATE-1**: Manual fetch instead of React Query
   - Fix: Replace with `useQuery` or `useMutation`

3. **TABLE-1**: Manual pagination calculations
   - Fix: Use TanStack Table's `useReactTable`

4. **ARCH-1**: UI components making API calls
   - Fix: Move to custom hook, pass data via props

5. **SEC-4**: Missing input validation
   - Fix: Add Zod schema validation

## Reference Files

For detailed rules, examples, and patterns, read these references as needed:

- **references/structure-architecture.md** - STRUCT-*, ARCH-*, DI-* rules
- **references/state-networking.md** - STATE-*, NET-*, CACHE-* rules  
- **references/tables-forms.md** - TABLE-*, FORM-* rules
- **references/naming-testing.md** - NAME-*, TEST-* rules
- **references/i18n-ui.md** - I18N-*, ROUTE-*, UI-* rules
- **references/security.md** - SEC-* rules
- **references/tech-stack.md** - TECH-* rules with approved/forbidden dependencies

## Tech Stack Context

**Approved**: Next.js App Router, TypeScript strict mode, TanStack Query, Axios (configured client), React Hook Form, Zod, next-intl, shadcn/ui

**Forbidden**: zustand, jotai, redux, valtio, recoil, direct fetch usage

## Key Patterns to Recognize

**✅ Good Custom Hook:**
```typescript
interface UseItemsResult {
  data: Item[];
  isLoading: boolean;
}

export function useItems(): UseItemsResult {
  const { data, isLoading } = useQuery({
    queryKey: ['items'],
    queryFn: () => apiClient.get('/items'),
  });
  return { data: data?.data ?? [], isLoading };
}
```

**✅ Good Page Component:**
```typescript
export default function ItemsPage() {
  const { data, isLoading } = useItems();
  return <ItemsList items={data} loading={isLoading} />;
}
```

**✅ Good API Route:**
```typescript
export async function GET() {
  try {
    const repo = new ItemsRepository();
    const useCase = new ListItemsUseCase(repo);
    const result = await useCase.execute();
    return Response.json({ data: result });
  } catch (error) {
    console.error('API Error:', error);
    return Response.json(
      { error: { message: 'Failed to fetch items' } },
      { status: 500 }
    );
  }
}
```

## When to Use Each Reference

- **Quick structure check**: Just use this SKILL.md
- **Understanding architecture violations**: Read structure-architecture.md
- **State management issues**: Read state-networking.md
- **Table implementation problems**: Read tables-forms.md
- **Naming or testing questions**: Read naming-testing.md
- **i18n or UI violations**: Read i18n-ui.md
- **Security concerns**: Read security.md
- **Dependency questions**: Read tech-stack.md

## Complete Review Example

Here's a complete example of reviewing a PR:

```bash
# Step 1: Get PR info
gh pr view 5 --json title,headRefOid,changedFiles
# Output: {"changedFiles":12,"headRefOid":"abc123...","title":"Add user management"}

# Step 2: Get changed files
gh pr view 5 --json files --jq '.files[].path' | grep -E "src/hooks/"
# Output: src/hooks/use-users.ts

# Step 3: Review the file
Read src/hooks/use-users.ts
# Found violations:
# - Line 25: Missing explicit return type interface (STATE-7)
# - Line 40: Manual fetch instead of apiClient (NET-1)

# Step 4: Create pending review
mcp__github__create_pending_pull_request_review({
  owner: "central-pattana-ex",
  repo: "residence-backoffice",
  pullNumber: 5,
  commitID: "abc123..."
})

# Step 5: Add comments
mcp__github__add_comment_to_pending_review({
  path: "src/hooks/use-users.ts",
  line: 25,
  body: "**[STATE-7] Missing Explicit Return Type**\n\nAdd interface:\n```typescript\ninterface UseUsersResult { data: User[]; isLoading: boolean; }\nexport function useUsers(): UseUsersResult { ... }\n```"
})

mcp__github__add_comment_to_pending_review({
  path: "src/hooks/use-users.ts",
  line: 40,
  body: "**[NET-1] Use Configured Axios Client**\n\nReplace:\n```typescript\nimport { apiClient } from '@/lib/api/client';\nconst response = await apiClient.get('/users');\n```"
})

# Step 6: Inform user about pending review (DO NOT submit)
# Pending review created with 2 comments
# User can now review and submit manually via GitHub UI or:
# gh pr review 5 --request-changes -b "Found 2 violations..."
```

**Summary for user:**
- Pending review created with 2 inline comments
- Review the comments in GitHub UI
- Submit when ready with appropriate status (approve/request-changes/comment)

## Troubleshooting

### GitHub MCP Authentication Issues

If you get "401 Unauthorized" errors:
1. Check if user has configured GitHub MCP server correctly
2. Verify `.mcp.json` has valid GitHub credentials
3. For merged PRs: Inform user that reviews can only be created on open PRs
4. Fallback: Create a comprehensive review report as text instead

### Large PRs (>100 files)

When PR has many files, review ALL of them systematically:
1. Get complete file list: `gh pr view {PR_NUMBER} --json files --jq '.files[].path'`
2. Review by layer for organization: API routes → hooks → domain → pages → UI
3. Read each file individually using the Read tool
4. Document ALL violations found (critical and minor)
5. Add inline comments for each violation in the pending review
6. Provide comprehensive summary of total violations at the end

**Example for 200+ file PR:**
```bash
# Get all 261 files
gh pr view 2 --json files --jq '.files[].path'

# Review systematically - read each file
Read src/app/api/admin-users/route.ts
Read src/app/api/application-users/route.ts
... (continue for all files)

# Add comment for each violation found
# No file limit - review them all!
```

### Diff Too Large

If `gh pr diff` fails with "too large":
1. Use `gh pr view {PR_NUMBER} --json files` to get file list
2. Read files individually from local repository
3. Use `git show {COMMIT_SHA}:path/to/file` to get PR version
4. Review files in chunks (10-20 at a time)
