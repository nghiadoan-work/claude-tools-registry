# Naming & Testing Rules

## Naming Conventions

### NAME-1: Symbol Casing (🟡 Major)
PascalCase for types, classes, components: `AdminUser`, `CreateUserUseCase`

### NAME-2: File/Directory Casing (🟡 Major)
kebab-case for files/directories: `admin-users/`, `create-user-use-case.ts`
Exception: `src/app` router directory structure

### NAME-3: Variable/Function Casing (🟡 Major)
camelCase: `getUsers`, `isLoading`

### NAME-4: Constant Casing (🟡 Major)
SCREAMING_SNAKE_CASE: `API_BASE_URL`, `MAX_RETRIES`

### NAME-5: File Suffixes (🟡 Major)

**Required suffixes:**
- Entities: `.types.ts` or `.entity.ts`
- Use cases: `.use-case.ts`
- Repositories: `.repository.ts`
- Tests: `.test.ts`
- Pages: `page.tsx`
- Layouts: `layout.tsx`
- API routes: `route.ts`

### NAME-6: File and Symbol Names (🟡 Major)
File `use-users-list.ts` MUST export `useUsersList`.
File `list-users.use-case.ts` MUST export `ListUsersUseCase`.

### NAME-7: Generic Names (🟢 Minor)
Avoid vague names like `Manager`, `Helper`, `Service`, `utils.ts`.
Be specific: `date-utils.ts`, `HttpUsersRepository`.

### NAME-8: Language (🟡 Major)
Use English for all names.
Avoid abbreviations unless universally understood (DTO, UI).

## Testing Rules

### TEST-1: Test Focus (Required)
Test business logic and data layers:
- Domain use cases (unit tests)
- Infrastructure repositories (integration tests)
- Custom hooks (integration tests)

### TEST-2: UI Testing (N/A)
UI component testing is OUT OF SCOPE.

### TEST-3: Third-Party Libraries (🟢 Minor)
Do NOT test third-party libraries.

### TEST-4: Implementation Details (🟢 Minor)
Focus on public API and behavior, not internal private methods.

### TEST-5: Test Co-location (🟢 Minor)
Place test files next to source files.

### TEST-6: Test Structure (🟢 Minor)
Use Arrange-Act-Assert pattern.

### TEST-7: Mock Management (🟡 Major)
Reset mocks between tests using `afterEach`.
