# Security Rules

## SEC-1: Environment Variables (🔴 Critical)
ALL environment variables MUST be validated on startup using Zod schema in `src/lib/env.ts`.

**Example:**
```typescript
// src/lib/env.ts
import { z } from 'zod';

const envSchema = z.object({
  DATABASE_URL: z.string().url(),
  API_KEY: z.string().min(1),
  // ... all env vars
});

export const env = envSchema.parse(process.env);
```

## SEC-2: Environment Access (🟡 Major)
Import validated `env` object from `src/lib/env.ts`.
NO direct `process.env` access.

**Example:**
```typescript
// ❌ WRONG
const apiKey = process.env.API_KEY;

// ✅ CORRECT
import { env } from '@/lib/env';
const apiKey = env.API_KEY;
```

## SEC-3: Secrets (🔴 Critical)
NEVER commit secrets to Git.
Use `.env.local` for secrets (git-ignored).

## SEC-4: Input Validation (🔴 Critical)
Validate ALL incoming data with Zod, even if validated on client.

**Example:**
```typescript
// API Route
export async function POST(req: Request) {
  const body = await req.json();
  
  // Validate with Zod
  const validated = schema.parse(body);
  
  await useCase.execute(validated);
}
```

## SEC-5: SQL Injection (🔴 Critical)
Use parameterized queries (ORM like Drizzle).
NO string concatenation for SQL.

**Example:**
```typescript
// ❌ WRONG
const query = `SELECT * FROM users WHERE id = '${userId}'`;

// ✅ CORRECT
const user = await db.query.users.findFirst({
  where: eq(users.id, userId)
});
```

## SEC-6: XSS Prevention (🔴 Critical)
Sanitize user HTML with `DOMPurify`.
NO `dangerouslySetInnerHTML` without sanitization.

## SEC-7: Authentication (🔴 Critical)
Use Keycloak for SSO.
NO custom authentication flows.

## SEC-8: Error Exposure (🔴 Critical)
Log detailed errors server-side.
Return generic messages to users.

**Example:**
```typescript
try {
  // operation
} catch (error) {
  console.error('Detailed error:', error); // Server-side log
  return Response.json(
    { error: { message: 'Operation failed' } }, // Generic to client
    { status: 500 }
  );
}
```

## Security Checklist

- [ ] All env vars validated with Zod on startup
- [ ] All input validated with Zod
- [ ] Using parameterized queries (ORM)
- [ ] HTML sanitized with DOMPurify
- [ ] Using Keycloak for auth
- [ ] Generic error messages to clients
- [ ] No secrets in code or Git
