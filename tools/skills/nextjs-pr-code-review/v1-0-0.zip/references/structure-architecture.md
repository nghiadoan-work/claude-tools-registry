# Structure & Architecture Rules

## STRUCT-1: Domain Layer Imports (🔴 Critical)
Domain MUST NOT import from infrastructure, app, or ui layers.
Domain must be framework-agnostic.

## STRUCT-2: Infrastructure Layer Imports (🔴 Critical)
Infrastructure can ONLY import from domain layer.

## STRUCT-3: Page Components (🔴 Critical)
Pages MUST use custom hooks for ALL state and data fetching.
NO direct useState/useEffect in page components.

**Example:**
```typescript
// ❌ WRONG
export default function UsersPage() {
  const [users, setUsers] = useState([]);
  useEffect(() => { fetch(...) }, []);
}

// ✅ CORRECT
export default function UsersPage() {
  const { users } = useUsersList();
  return <UsersList users={users} />;
}
```

## STRUCT-4: UI Components (🔴 Critical)
UI components MUST receive ALL data via props.
NO API calls or React Query hooks in UI components.
useState ONLY for internal UI state (modals, dropdowns).

## ARCH-1: UI Layer API Calls (🔴 Critical)
ALL API calls MUST be in custom hooks using React Query.

## ARCH-2: Business Logic Location (🔴 Critical)
Business logic belongs in domain use cases, NOT in hooks or components.

## ARCH-3: API Route Responsibilities (🔴 Critical)
API routes should ONLY: parse params, instantiate dependencies, call use cases, return responses.

**Example:**
```typescript
// ✅ CORRECT
export async function GET() {
  try {
    const repository = new UsersRepository();
    const useCase = new ListUsersUseCase(repository);
    const result = await useCase.execute();
    return Response.json({ data: result });
  } catch (error) {
    console.error('API Error:', error);
    return Response.json(
      { error: { message: 'Failed to fetch users' } },
      { status: 500 }
    );
  }
}
```

## ARCH-4: Use Case Dependencies (🔴 Critical)
Repositories MUST be injected into use cases (manual DI).

## ARCH-5: Repository Responsibilities (🔴 Critical)
Repositories ONLY fetch/store raw data. No business logic.

## DI-1: Dependency Injection Pattern (🔴 Critical)
Use manual DI in API routes. NO global DI container.

## DI-2: Repository Instantiation (🔴 Critical)
Use cases MUST NOT instantiate their own repositories.

## DI-3: Explicit Dependencies (🔴 Critical)
All dependencies must be instantiated explicitly at the start of API route handlers.

## Data Flow Pattern

**Required Flow:**
```
UI Component → Custom Hook → API Route → Use Case → Repository
```
