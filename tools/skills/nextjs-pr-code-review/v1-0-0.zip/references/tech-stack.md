# Tech Stack Rules

## TECH-1: Forbidden Dependencies (🔴 Critical)

**Forbidden state management:**
- zustand, jotai, redux, valtio, recoil

**Reason:** Project uses TanStack Query for server state + React Hooks for UI state

**Example:**
```typescript
// ❌ WRONG
import { create } from 'zustand';

// ✅ CORRECT
import { useQuery } from '@tanstack/react-query';
```

## TECH-2: HTTP Client (🟡 Major)

**Required:** Use configured Axios client from `@/lib/api/client`

**Forbidden:** Direct `fetch`, `ky`, `got`, other HTTP libraries

**Example:**
```typescript
// ❌ WRONG
const data = await fetch('/api/users').then(r => r.json());

// ✅ CORRECT
import { apiClient } from '@/lib/api/client';
const response = await apiClient.get('/users');
```

## TECH-3: TypeScript Strict Mode (🔴 Critical)

**Required:** `tsconfig.json` must have `"strict": true`

## Approved Tech Stack

- Next.js App Router
- TypeScript (strict mode)
- TanStack Query (React Query)
- Axios (configured client)
- React Hook Form
- Zod
- next-intl
- shadcn/ui
