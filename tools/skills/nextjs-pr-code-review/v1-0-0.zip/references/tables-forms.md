# Tables & Forms Rules

## TABLE-1: Pagination Pattern (🔴 Critical)
Use TanStack Table (`@tanstack/react-table`).
NO manual pagination logic.

**Forbidden:**
```typescript
// ❌ WRONG
const [page, setPage] = useState(1);
const sliced = items.slice((page-1)*size, page*size);
```

**Required:**
```typescript
// ✅ CORRECT
const table = useReactTable({
  data: items,
  columns,
  getCoreRowModel: getCoreRowModel(),
  getPaginationRowModel: getPaginationRowModel(),
});
```

## TABLE-2: Hook Return Types (🟡 Major)
Data hooks MUST have explicit return type interfaces.

## TABLE-3: Column Definitions (🟡 Major)
Use type-safe column helper:
```typescript
const columnHelper = createColumnHelper<ItemType>();
```

## TABLE-4: Column Memoization (🟡 Major)
Wrap columns in `React.useMemo()`.

## TABLE-5: Table Components (🟡 Major)
Use shadcn/ui Table components: `Table`, `TableHeader`, `TableBody`, `TableRow`, `TableHead`, `TableCell`.

## TABLE-6: Pagination Reset (🟡 Major)
Reset to page 1 when filters change:
```typescript
React.useEffect(() => {
  table.setPageIndex(0);
}, [search, status, table]);
```

## TABLE-7: Table Configuration Location (🔴 Critical)
Column definitions belong in UI layer (page components), NOT in hooks.

## FORM-1: Form State Management (🔴 Critical)
Use `react-hook-form` for form state.

## FORM-2: Validation (🔴 Critical)
Define Zod schema in `domain/entities`.
Use `zodResolver` with `useForm`.

## FORM-3: Server-Side Validation (🔴 Critical)
Re-validate with Zod in Server Actions.

## FORM-4: Form State (🔴 Critical)
Let `react-hook-form` handle form lifecycle.
Do NOT use useState for form state.

## FORM-5: Business Logic (🔴 Critical)
Forms should only collect data and call Server Actions.

## FORM-6: Server Action Responses (🟡 Major)
Return structured objects:
```typescript
// Success
return { ok: true, data };

// Failure
return { ok: false, fieldErrors };
```
