# State Management & Networking Rules

## STATE-1: Data Fetching Pattern (🔴 Critical)
Use `useQuery` for GET requests, `useMutation` for POST/PUT/DELETE.
NO manual useState + useEffect + fetch.

**Example:**
```typescript
// ❌ WRONG
const [data, setData] = useState([]);
useEffect(() => {
  fetch('/api/users').then(r => r.json()).then(setData);
}, []);

// ✅ CORRECT
const { data } = useQuery({
  queryKey: ['users'],
  queryFn: () => apiClient.get('/users'),
});
```

## STATE-2: Query Key Structure (🟡 Major)
Use array format: `['feature-name', params]`
Include all parameters that affect the query.

## STATE-3: Cache Invalidation (🔴 Critical)
MUST invalidate queries after mutations.

**Example:**
```typescript
const createUser = useMutation({
  mutationFn: (data) => apiClient.post('/users', data),
  onSuccess: () => {
    queryClient.invalidateQueries({ queryKey: ['users'] });
  },
});
```

## STATE-4: API Requests (🔴 Critical)
ALL client requests MUST go through `/api/*` routes.
NO direct use case or repository calls from client.

## STATE-5: Server Data Storage (🟡 Major)
Keep fetched data in React Query cache ONLY.
Do NOT store server data in useState.

## STATE-6: Custom Hooks Pattern (🔴 Critical)
Encapsulate state + queries in custom hooks (e.g., `useAdminUsers`).

## STATE-7: Return Type Interfaces (🟡 Major)
ALL custom hooks MUST have explicit return type interfaces.

**Example:**
```typescript
// ✅ CORRECT
interface UseUsersResult {
  data: User[];
  isLoading: boolean;
  error: string | null;
}

export function useUsers(): UseUsersResult {
  // implementation
}
```

## NET-1: HTTP Client (🟡 Major)
Import and use `apiClient` from `@/lib/api/client`.

## NET-2: Error Handling (🔴 Critical)
API routes MUST wrap use case execution in try-catch.

## NET-3: Error Messages (🔴 Critical)
Return user-friendly error messages to clients.
Log detailed errors server-side only.

## NET-4: API Route Logic (🔴 Critical)
NO business logic in API routes.

## NET-5: Response Format (🟡 Major)
Return structured JSON with `data` and optional `meta` fields.

## CACHE-1: Server-Side Caching (🟡 Major)
Use `unstable_cache` for server-side data fetching.

## CACHE-2: Cache Tags (🟡 Major)
Tag cached data with descriptive keys.

## CACHE-3: Cache Revalidation (🔴 Critical)
Use `revalidateTag()` after mutations.
