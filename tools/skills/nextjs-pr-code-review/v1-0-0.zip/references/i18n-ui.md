# i18n, Routing & UI Rules

## Routing Rules

### ROUTE-1: Locale Prefixes (🔴 Critical)
ALL user-facing routes MUST be prefixed with locale.
Example: `/en/dashboard`, `/th/users`

### ROUTE-2: URL Casing (🟡 Major)
Use kebab-case for URL segments: `/admin/user-management`

### ROUTE-3: Query Parameters (🟡 Major)
Use route segments for primary navigation: `/users/123/edit`
NOT query params: `/users/edit?id=123`
Query params acceptable for filters, sorting, pagination.

## Internationalization Rules

### I18N-1: Hardcoded Text (🟡 Major)
NO hardcoded user-facing text.
Use `useTranslations` or `getTranslations` for ALL user text.

**Example:**
```typescript
// ❌ WRONG
<h1>User Management</h1>

// ✅ CORRECT
const t = useTranslations('users');
<h1>{t('title')}</h1>
```

### I18N-2: Namespace Registration (🔴 Critical)
Import and register new translation files in `src/lib/i18n/request.ts`.

**Example:**
```typescript
import dashboardTranslations from './locales/en/dashboard.json';

const messages = {
  common: commonTranslations,
  dashboard: dashboardTranslations, // Register here
};
```

### I18N-3: Translation Keys (🟡 Major)
When using scoped translations, do NOT double namespace.

**Example:**
```typescript
// ❌ WRONG
const t = useTranslations("users");
<h1>{t("users.title")}</h1> // Looks for users.users.title

// ✅ CORRECT
const t = useTranslations("users");
<h1>{t("title")}</h1> // Looks for users.title
```

### I18N-4: Formatting (🟡 Major)
Use `useFormatter` or `getFormatter` for dates, times, numbers.

## UI & Theming Rules

### UI-1: Component Library (🟡 Major)
ALL UI components MUST come from `src/ui` (shadcn/ui).

### UI-2: Color Values (🟡 Major)
Use semantic color classes: `bg-primary`, `text-muted-foreground`
NO hardcoded colors: `bg-blue-500`, `text-gray-700`

**Example:**
```typescript
// ❌ WRONG
<div className="bg-blue-500 text-gray-700">

// ✅ CORRECT
<div className="bg-primary text-muted-foreground">
```

### UI-3: CSS Variables (🟡 Major)
Define colors as CSS variables in `globals.css`.
Map tokens in `tailwind.config.ts`.

### UI-4: Custom Styles (🟡 Major)
Use Tailwind utilities based on design tokens.
NO arbitrary values that break theming.

### UI-5: Icon Libraries (🟢 Minor)
Use single icon library (e.g., `lucide-react`).

### UI-6: Emojis (🟢 Minor)
NO emojis as interface icons.
