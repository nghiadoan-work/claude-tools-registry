---
name: developer-nextjs-multi-zones
description: |
  Implements features in a Next.js Multi-Zone monorepo following clean architecture patterns.
  Use when building features that require: (1) CRUD operations with API calls, (2) Business logic
  with validation, (3) Data fetching and mutations. Enforces layered architecture (UI → Hooks →
  Domain → Infrastructure), zone isolation, and naming conventions. Validates implementation
  via ESLint boundaries rules.
---

# Next.js Multi-Zone Developer

## Architecture Overview

```
Zone (main|staff|parcel)              packages/shared
├── app/                              ├── components/  → Shared UI
│   ├── [locale]/(app)/ → UI Pages    ├── styles/      → Design tokens
│   ├── api/            → API Routes  └── hooks/       → Shared hooks
│   └── actions/        → Server Actions (mutations)
├── src/screens/        → Hooks + Feature Components
├── src/domain/         → Business Logic
└── src/infrastructure/ → Data Access
```

**Data Flow:**
- **GET requests:** `UI → Hooks → API Route → Domain → Infrastructure → External API`
- **Mutations (POST/PUT/DELETE):** `UI → Hooks → Server Action → Domain → Infrastructure → External API`

## When to Apply Full Architecture

Use full layers for:
- CRUD operations with API calls
- Features with business logic validation
- Data fetching, caching, and mutations

Skip layers for:
- Static content pages
- Simple UI-only pages without API interaction

## Implementation Workflow

### 1. Create Domain Layer
Location: `[zone]/src/domain/[feature]/`

```typescript
// [zone]/src/domain/[feature]/[feature].types.ts
export type Entity = { id: string; /* fields */ };
export type CreateInput = { /* fields */ };
export type ListParams = { page: number; limit: number; };

// [zone]/src/domain/[feature]/[action]-[feature].use-case.ts
export class ListFeatureUseCase {
  constructor(private repository: FeatureRepository) {}
  async execute(params: ListParams) { return this.repository.findAll(params); }
}
```

### 2. Create Infrastructure Layer
Location: `[zone]/src/infrastructure/[feature]/`

```typescript
// [zone]/src/infrastructure/[feature]/[feature]-http.repository.ts
export class FeatureHttpRepository {
  async findAll(params) { return axios.get('/api/feature', { params }); }
  async create(input) { return axios.post('/api/feature', input); }
}
export const featureRepository = new FeatureHttpRepository();
```

### 3. Create API Layer

**IMPORTANT: API Route Path for Multi-Zone**

In a multi-zone setup, API routes should be organized under `app/api/[zone]/` to maintain clear separation:

| Zone | API Route Location | URL Path |
|------|-------------------|----------|
| main | `main/app/api/[feature]/route.ts` | `/api/[feature]` |
| staff | `staff/app/api/staff/[feature]/route.ts` | `/api/staff/[feature]` |
| parcel | `parcel/app/api/parcel/[feature]/route.ts` | `/api/parcel/[feature]` |

This convention:
- Keeps API routes organized by zone under the `/api/` path
- Maintains clear namespacing between zones
- Works with the multi-zone rewrite configuration

**GET requests** → API Routes:
```typescript
// For main zone: main/app/api/[feature]/route.ts → /api/[feature]
// For staff zone: staff/app/api/staff/[feature]/route.ts → /api/staff/[feature]
// For parcel zone: parcel/app/api/parcel/[feature]/route.ts → /api/parcel/[feature]

import { NextRequest, NextResponse } from 'next/server';
import { isApiError } from 'packages/shared';

export async function GET(request: NextRequest) {
  try {
    // Get access token from Authorization header
    const authHeader = request.headers.get('authorization');
    const accessToken = authHeader?.replace('Bearer ', '');

    if (!accessToken) {
      return NextResponse.json(
        { error: { message: 'Access token is required', code: 'unauthorized' } },
        { status: 401 }
      );
    }

    // Get locale from Accept-Language header
    const acceptLanguage = request.headers.get('accept-language') || 'en';
    const locale = acceptLanguage.startsWith('th') ? 'th' : 'en';

    const repository = createFeatureRepository(accessToken, locale);
    const useCase = new ListFeatureUseCase(repository);
    const result = await useCase.execute(params);

    return NextResponse.json(result);
  } catch (error) {
    console.error('[API] Error:', error);

    // IMPORTANT: Handle API errors with proper status codes
    // This preserves the actual error (401, 403, 404, etc.) from the backend
    if (isApiError(error)) {
      return NextResponse.json(
        { error: { message: error.message, code: error.error, data: error.data } },
        { status: error.status }
      );
    }

    return NextResponse.json(
      { error: { message: 'internal server error', code: 'internal_server_error' } },
      { status: 500 }
    );
  }
}
```

**API Error Handling (MANDATORY)**

Always use `isApiError` from `packages/shared` to handle errors from backend APIs:

```typescript
import { isApiError } from 'packages/shared';

// In catch block:
if (isApiError(error)) {
  return NextResponse.json(
    { error: { message: error.message, code: error.error, data: error.data } },
    { status: error.status }  // Preserves 401, 403, 404, etc.
  );
}
```

This ensures:
- Backend errors (401 Unauthorized, 403 Forbidden, 404 Not Found) are properly forwarded
- Error details are preserved for debugging
- Consistent error response format across all API routes

**Mutations (POST/PUT/DELETE)** → **ALWAYS use Server Actions**

Server Actions provide better security and automatic revalidation for mutations:

```typescript
// [zone]/app/actions/[feature].actions.ts
'use server';

import { revalidatePath } from 'next/cache';
import type { CreateFeatureInput, UpdateFeatureInput, FeatureResponse } from '@/domain/feature';
import { CreateFeatureUseCase, UpdateFeatureUseCase } from '@/domain/feature';
import { createFeatureRepository } from '@/infrastructure/feature';
import { isApiError } from 'packages/shared';

// Result type for type-safe error handling
export type ActionResult<T> =
  | { success: true; data: T }
  | { success: false; error: { message: string; code: string; data?: unknown } };

// CREATE action
export async function createFeatureAction(
  accessToken: string,
  input: CreateFeatureInput,
  locale: string = 'en'
): Promise<ActionResult<FeatureResponse>> {
  try {
    if (!accessToken) {
      return { success: false, error: { message: 'Access token is required', code: 'unauthorized' } };
    }

    const repository = createFeatureRepository(accessToken, locale);
    const useCase = new CreateFeatureUseCase(repository);
    const result = await useCase.execute(input);

    revalidatePath('/feature');
    return { success: true, data: result };
  } catch (error) {
    console.error('[Action] Error creating feature:', error);

    if (isApiError(error)) {
      return { success: false, error: { message: error.message, code: error.error, data: error.data } };
    }

    if (error instanceof Error) {
      return { success: false, error: { message: error.message, code: 'validation_error' } };
    }

    return { success: false, error: { message: 'internal server error', code: 'internal_server_error' } };
  }
}

// UPDATE action
export async function updateFeatureAction(
  accessToken: string,
  featureId: string,
  input: UpdateFeatureInput,
  locale: string = 'en'
): Promise<ActionResult<FeatureResponse>> {
  try {
    if (!accessToken) {
      return { success: false, error: { message: 'Access token is required', code: 'unauthorized' } };
    }

    const repository = createFeatureRepository(accessToken, locale);
    const useCase = new UpdateFeatureUseCase(repository);
    const result = await useCase.execute(featureId, input);

    revalidatePath('/feature');
    revalidatePath(`/feature/${featureId}`);
    return { success: true, data: result };
  } catch (error) {
    console.error('[Action] Error updating feature:', error);

    if (isApiError(error)) {
      return { success: false, error: { message: error.message, code: error.error, data: error.data } };
    }

    return { success: false, error: { message: 'internal server error', code: 'internal_server_error' } };
  }
}

// DELETE action
export async function deleteFeatureAction(
  accessToken: string,
  featureId: string,
  locale: string = 'en'
): Promise<ActionResult<void>> {
  try {
    if (!accessToken) {
      return { success: false, error: { message: 'Access token is required', code: 'unauthorized' } };
    }

    const repository = createFeatureRepository(accessToken, locale);
    await repository.delete(featureId);

    revalidatePath('/feature');
    return { success: true, data: undefined };
  } catch (error) {
    console.error('[Action] Error deleting feature:', error);

    if (isApiError(error)) {
      return { success: false, error: { message: error.message, code: error.error, data: error.data } };
    }

    return { success: false, error: { message: 'internal server error', code: 'internal_server_error' } };
  }
}
```

**Why Server Actions for Mutations?**
- Security: Actions run on the server, keeping sensitive logic and tokens server-side
- Automatic revalidation: `revalidatePath()` works seamlessly
- Type safety: Full TypeScript support with result types
- Better error handling: Consistent error format across all mutations

### 4. Create Hooks Layer
Location: `[zone]/src/screens/[feature]/hooks/`

```typescript
// use-[feature]-list.ts → Query hook (for GET requests)
// IMPORTANT: Use zone-namespaced API path
// - main zone: fetch('/api/feature', ...)
// - staff zone: fetch('/api/staff/feature', ...)
// - parcel zone: fetch('/api/parcel/feature', ...)

export function useFeatureList(params) {
  return useQuery({ queryKey: ['feature', params], queryFn: () => fetchFeature(params) });
}

// use-create-[feature].ts → Mutation hook (uses Server Action)
import { createFeatureAction } from '../../../../app/actions/feature.actions';

export function useCreateFeature() {
  const { data: session } = useSession();
  const locale = useLocale();
  const queryClient = useQueryClient();

  const accessToken = (session as { accessToken?: string } | null)?.accessToken || '';

  return useMutation({
    mutationFn: async (input: CreateFeatureInput) => {
      const result = await createFeatureAction(accessToken, input, locale);

      if (!result.success) {
        throw new Error(result.error.message);
      }

      return result.data;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['feature'] }),
  });
}

// use-update-[feature].ts → Mutation hook (uses Server Action)
import { updateFeatureAction } from '../../../../app/actions/feature.actions';

export function useUpdateFeature(featureId: string) {
  const { data: session } = useSession();
  const locale = useLocale();
  const queryClient = useQueryClient();

  const accessToken = (session as { accessToken?: string } | null)?.accessToken || '';

  return useMutation({
    mutationFn: async (input: UpdateFeatureInput) => {
      const result = await updateFeatureAction(accessToken, featureId, input, locale);

      if (!result.success) {
        throw new Error(result.error.message);
      }

      return result.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['feature-detail', featureId] });
      queryClient.invalidateQueries({ queryKey: ['feature'] });
    },
  });
}
```

### 5. Create UI Layer
Location: `[zone]/app/[locale]/(app)/[feature]/page.tsx`

```typescript
'use client';
import { useFeatureList } from '@/pages/feature/hooks/use-feature-list';
import { dataTableClasses } from 'packages/shared/styles/dataTable';

export default function FeaturePage() {
  const { data, isLoading } = useFeatureList({ page: 1, limit: 10 });
  return <div test-id="feature-list-container" className={dataTableClasses.pageContainer}>...</div>;
}
```

## Test-ID Requirements (MANDATORY - TAG EVERYTHING)

**CRITICAL: EVERY element in the UI MUST have a `test-id` attribute** for Robot Framework testing. This includes:
- All containers/wrappers (pages, sections, cards, modals)
- All interactive elements (buttons, inputs, links, selects)
- All text content (labels, values, titles, descriptions)
- All table elements (header, body, rows, cells, cell values)
- All list items and their contents
- All form fields and their labels/errors
- All dropdown options
- All state indicators (loading, error, empty states)

### Pattern
```
[page]-[element-type]-[descriptive-name]
[page]-[element-type]-[descriptive-name]-${dynamicId}
```

### Element Type Prefixes (Required)

| Prefix | Element Type | Example |
|--------|-------------|---------|
| `page` | Page containers | `staff-page`, `staff-create-page` |
| `container` | Section containers | `staff-search-container`, `staff-table-container` |
| `btn` | Buttons, clickable actions | `staff-btn-submit`, `staff-btn-filter` |
| `input` | Text inputs, textareas | `staff-input-search`, `staff-input-email` |
| `select` | Dropdowns, select boxes | `staff-select-role`, `staff-items-per-page` |
| `options` | Select dropdown options container | `staff-select-role-options` |
| `option` | Individual select options | `staff-select-role-option-admin` |
| `form` | Form containers | `staff-form-create` |
| `field` | Form field containers | `staff-field-email` |
| `label` | Labels/titles | `staff-label-email`, `staff-th-name` |
| `link` | Navigation links | `staff-link-home`, `staff-link-edit-123` |
| `modal` | Modal/dialog containers | `staff-modal-delete` |
| `sheet` | Bottom sheets, drawers | `staff-sheet-filter` |
| `table` | Table containers | `staff-table` |
| `th` | Table headers | `staff-th-name`, `staff-th-email` |
| `tbody` | Table body | `staff-table-body` |
| `row` | Table/list rows | `staff-row-123` |
| `cell` | Table cells | `staff-cell-name-123`, `staff-cell-email-123` |
| `item` | List items | `staff-item-member-123` |
| `txt` | Static text/values | `staff-txt-total`, `staff-name-123` |
| `badge` | Status badges/chips | `staff-badge-status-123`, `staff-filter-badge-department` |
| `icon` | Icon buttons | `staff-icon-sort`, `header-icon-notification` |
| `tab` | Tab buttons | `parcel-tab-pending` |
| `breadcrumb` | Breadcrumb containers/items | `staff-breadcrumb`, `staff-breadcrumb-home` |
| `pagination` | Pagination elements | `staff-pagination`, `staff-pagination-page-1` |
| `loading` | Loading states | `staff-table-loading`, `staff-loading-text` |
| `error` | Error states/messages | `staff-table-error`, `staff-error-text` |
| `empty` | Empty states | `staff-table-empty`, `staff-empty-text` |
| `dropdown` | Dropdown menus | `staff-dropdown-menu-123` |
| `menu-item` | Menu items | `staff-menu-item-edit-123` |

### Complete Table Pattern (REQUIRED)

```typescript
<div test-id="staff-table-container">
  <table test-id="staff-table">
    {/* Table Header - tag header, row, and each column */}
    <thead test-id="staff-table-header">
      <tr test-id="staff-table-header-row">
        <th test-id="staff-th-checkbox">
          <input type="checkbox" test-id="staff-checkbox-all" />
        </th>
        <th test-id="staff-th-name">{t('table.name')}</th>
        <th test-id="staff-th-email">{t('table.email')}</th>
        <th test-id="staff-th-status">{t('table.status')}</th>
        <th test-id="staff-th-actions"></th>
      </tr>
    </thead>

    {/* Table Body - tag body, each row, each cell, and each value */}
    <tbody test-id="staff-table-body">
      {/* Loading State */}
      {isLoading && (
        <tr test-id="staff-table-loading">
          <td test-id="staff-table-loading-cell" colSpan={5}>
            <span test-id="staff-table-loading-text">{t('loading')}</span>
          </td>
        </tr>
      )}

      {/* Error State */}
      {isError && (
        <tr test-id="staff-table-error">
          <td test-id="staff-table-error-cell" colSpan={5}>
            <span test-id="staff-table-error-text">{t('error')}</span>
          </td>
        </tr>
      )}

      {/* Empty State */}
      {!isLoading && !isError && items.length === 0 && (
        <tr test-id="staff-table-empty">
          <td test-id="staff-table-empty-cell" colSpan={5}>
            <span test-id="staff-table-empty-text">{t('empty')}</span>
          </td>
        </tr>
      )}

      {/* Data Rows - tag row, each cell, and value inside cell */}
      {items.map((item) => (
        <tr key={item.id} test-id={`staff-row-${item.id}`}>
          <td test-id={`staff-cell-checkbox-${item.id}`}>
            <input type="checkbox" test-id={`staff-checkbox-${item.id}`} />
          </td>
          <td test-id={`staff-cell-name-${item.id}`}>
            <span test-id={`staff-name-${item.id}`}>{item.name}</span>
          </td>
          <td test-id={`staff-cell-email-${item.id}`}>
            <span test-id={`staff-email-${item.id}`}>{item.email}</span>
          </td>
          <td test-id={`staff-cell-status-${item.id}`}>
            <span test-id={`staff-badge-status-${item.id}`}>{item.status}</span>
          </td>
          <td test-id={`staff-cell-actions-${item.id}`}>
            <button test-id={`staff-btn-edit-${item.id}`}>Edit</button>
            <button test-id={`staff-btn-delete-${item.id}`}>Delete</button>
          </td>
        </tr>
      ))}
    </tbody>
  </table>
</div>
```

### Complete Form Pattern (REQUIRED)

```typescript
<form test-id="staff-form-create">
  {/* Form Field - tag container, label, input, and error */}
  <div test-id="staff-field-name">
    <label test-id="staff-label-name">{t('fields.name')}</label>
    <input test-id="staff-input-name" />
    {errors.name && <span test-id="staff-error-name">{errors.name}</span>}
  </div>

  {/* Select Field - tag container, label, trigger, options, each option, and error */}
  <div test-id="staff-field-role">
    <label test-id="staff-label-role">{t('fields.role')}</label>
    <select test-id="staff-select-role">
      <SelectTrigger test-id="staff-select-role-trigger" />
      <SelectContent test-id="staff-select-role-options">
        {roles.map((role) => (
          <SelectItem
            key={role.value}
            value={role.value}
            test-id={`staff-select-role-option-${role.value}`}
          >
            {role.label}
          </SelectItem>
        ))}
      </SelectContent>
    </select>
    {errors.role && <span test-id="staff-error-role">{errors.role}</span>}
  </div>

  {/* Action Buttons */}
  <div test-id="staff-form-actions">
    <button test-id="staff-btn-cancel">{t('cancel')}</button>
    <button test-id="staff-btn-submit">{t('submit')}</button>
  </div>
</form>
```

### Complete Filter/Search Pattern (REQUIRED)

```typescript
{/* Search and Filter Bar */}
<div test-id="staff-toolbar">
  <div test-id="staff-search-container">
    <input test-id="staff-input-search" placeholder={t('search')} />
  </div>
  <button test-id="staff-btn-filter">{t('filter')}</button>
</div>

{/* Active Filter Badges - tag container, each badge, badge parts, remove button */}
{hasFilters && (
  <div test-id="staff-active-filters">
    <div test-id="staff-filter-badges-row">
      {filterBadges.map((badge) => (
        <div key={badge.key} test-id={`staff-filter-badge-${badge.key}`}>
          <span test-id={`staff-filter-badge-text-${badge.key}`}>
            <span test-id={`staff-filter-badge-label-${badge.key}`}>{badge.label}</span>
            <span test-id={`staff-filter-badge-value-${badge.key}`}>{badge.value}</span>
          </span>
          <button test-id={`staff-filter-remove-${badge.key}`}>×</button>
        </div>
      ))}
      <button test-id="staff-btn-clear-filters">{t('clearAll')}</button>
    </div>

    {/* Result Count */}
    <div test-id="staff-filter-result-count">
      <span test-id="staff-filter-result-found-label">{t('found')}</span>
      <span test-id="staff-filter-result-count-value">{total}</span>
      <span test-id="staff-filter-result-items-label">{t('items')}</span>
    </div>
  </div>
)}
```

### Complete Pagination Pattern (REQUIRED)

```typescript
<div test-id="staff-pagination">
  <div test-id="staff-pagination-info">
    <span test-id="staff-pagination-show-label">{t('show')}</span>
    <select test-id="staff-items-per-page">
      <SelectContent test-id="staff-items-per-page-options">
        <SelectItem value="20" test-id="staff-items-per-page-20">20</SelectItem>
        <SelectItem value="50" test-id="staff-items-per-page-50">50</SelectItem>
        <SelectItem value="100" test-id="staff-items-per-page-100">100</SelectItem>
      </SelectContent>
    </select>
    <span test-id="staff-pagination-items-label">{t('itemsPerPage')}</span>
    <span test-id="staff-pagination-total">({t('total', { count })})</span>
  </div>

  <div test-id="staff-pagination-nav">
    <button test-id="staff-pagination-prev">{t('previous')}</button>
    {pages.map((page, index) => (
      typeof page === 'number' ? (
        <button key={page} test-id={`staff-pagination-page-${page}`}>{page}</button>
      ) : (
        <span key={index} test-id={`staff-pagination-ellipsis-${index}`}>...</span>
      )
    ))}
    <button test-id="staff-pagination-next">{t('next')}</button>
  </div>
</div>
```

### Complete Breadcrumb Pattern (REQUIRED)

```typescript
<div test-id="staff-breadcrumb">
  <span test-id="staff-breadcrumb-home">{t('home')}</span>
  <ChevronRight />
  <span test-id="staff-breadcrumb-list">{t('staffList')}</span>
  <ChevronRight />
  <span test-id="staff-breadcrumb-current">{t('create')}</span>
</div>
```

### Complete Modal Pattern (REQUIRED)

```typescript
<div test-id="staff-modal-delete">
  <div test-id="staff-modal-delete-backdrop" onClick={onClose} />
  <div test-id="staff-modal-delete-content">
    <h2 test-id="staff-modal-delete-title">{t('title')}</h2>
    <p test-id="staff-modal-delete-description">{t('description')}</p>
    <div test-id="staff-modal-delete-actions">
      <button test-id="staff-modal-delete-cancel">{t('cancel')}</button>
      <button test-id="staff-modal-delete-confirm">{t('confirm')}</button>
    </div>
  </div>
</div>
```

### Reusable Component Props (REQUIRED)

All reusable components MUST accept and propagate `test-id`:

```typescript
interface FormFieldProps {
  label: string;
  error?: string;
  'test-id'?: string;  // REQUIRED prop
}

function FormField({ label, error, 'test-id': testId }: FormFieldProps) {
  return (
    <div test-id={testId}>
      <label test-id={testId ? `${testId}-label` : undefined}>{label}</label>
      <input test-id={testId ? `${testId}-input` : undefined} />
      {error && <span test-id={testId ? `${testId}-error` : undefined}>{error}</span>}
    </div>
  );
}
```

See [references/test-id.md](references/test-id.md) for complete patterns.

## Key Rules

### Layer Dependencies
- **UI** → imports only from Hooks, Shared
- **Hooks** → imports only from Domain, Shared
- **Domain** → imports only from Infrastructure
- **Infrastructure** → no layer dependencies
- **Zones** → cannot import from other zones

### Naming Conventions
| Type | Convention | Example |
|------|------------|---------|
| Files (domain/infra) | kebab-case | `users.types.ts`, `list-users.use-case.ts` |
| Types/Classes | PascalCase | `User`, `ListUsersUseCase` |
| Functions/hooks | camelCase | `useUsersList`, `createUser` |
| Hooks | `use` prefix | `use-users-list.ts` → `useUsersList` |

### File Suffixes
| Layer | Suffix | Example |
|-------|--------|---------|
| Domain types | `.types.ts` | `users.types.ts` |
| Use cases | `.use-case.ts` | `list-users.use-case.ts` |
| Repositories | `.repository.ts` | `users-http.repository.ts` |

### Test-ID (MANDATORY - TAG EVERYTHING)
- **EVERY** element MUST have `test-id` attribute - not just interactive elements
- This includes: containers, text content, labels, values, table cells, list items, dropdown options, etc.
- Pattern: `[page]-[type]-[name]` (kebab-case)
- Dynamic IDs: `[page]-[type]-[name]-${id}` for list items
- Reusable components MUST accept `test-id` prop and propagate to child elements
- See Test-ID Requirements section above for complete patterns

## Shared Package Usage

Import shared components and styles:
```typescript
import { Button, Input, Table } from 'packages/shared/components/shadcn';
import { dataTableClasses } from 'packages/shared/styles/dataTable';
import { UnifiedSidebar } from 'packages/shared/components/UnifiedSidebar';
```

## Cross-Zone State

Zones cannot share React context. Use:
- **Cookies** → Auth tokens, user preferences
- **localStorage** → UI state, sidebar collapsed
- **URL params** → Search filters, pagination

See [references/cross-zone-state.md](references/cross-zone-state.md) for patterns.

## Validation

Run after implementation:
```bash
pnpm lint:architecture  # Validates layer dependencies and zone isolation
pnpm lint               # Full lint including naming conventions

# Or use the validation script
./scripts/validate-architecture.sh         # Validate all zones
./scripts/validate-architecture.sh staff   # Validate specific zone
```

The validation script checks:
- Layer dependencies (ESLint boundaries)
- Zone isolation (no cross-zone imports)
- File naming conventions (kebab-case, proper suffixes)
- Hook naming (`use-` prefix)

## References

- [references/layers.md](references/layers.md) - Detailed layer descriptions
- [references/examples.md](references/examples.md) - Complete feature implementation
- [references/naming.md](references/naming.md) - Naming patterns and rules
- [references/cross-zone-state.md](references/cross-zone-state.md) - State sharing patterns
- [references/test-id.md](references/test-id.md) - Test-ID conventions (MANDATORY)
