#!/bin/bash
#
# Architecture Validation Script
#
# This script validates that the implementation follows the layered architecture:
# - Layer dependencies (UI → Hooks → Domain → Infrastructure)
# - Zone isolation (zones cannot import from each other)
# - Naming conventions (kebab-case for domain/infra files)
#
# Usage:
#   ./validate-architecture.sh [zone]
#
# Examples:
#   ./validate-architecture.sh           # Validate all zones
#   ./validate-architecture.sh staff     # Validate staff zone only
#
# Exit codes:
#   0 - All validations passed
#   1 - Validation errors found
#

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

ZONE=${1:-""}
ERRORS=0

echo "🔍 Architecture Validation"
echo "=========================="

# Find project root (where .eslintrc.cjs is located)
find_project_root() {
  local dir="$PWD"
  while [[ "$dir" != "/" ]]; do
    if [[ -f "$dir/.eslintrc.cjs" ]] || [[ -f "$dir/pnpm-workspace.yaml" ]]; then
      echo "$dir"
      return 0
    fi
    dir="$(dirname "$dir")"
  done
  echo "$PWD"
}

PROJECT_ROOT=$(find_project_root)
cd "$PROJECT_ROOT"

echo "Project root: $PROJECT_ROOT"
echo ""

# 1. Run ESLint architecture validation
echo "📋 Running ESLint boundary checks..."
if [[ -n "$ZONE" ]]; then
  LINT_PATH="$ZONE"
else
  LINT_PATH="."
fi

if pnpm eslint "$LINT_PATH" --ext .ts,.tsx --rule 'boundaries/element-types: error' 2>/dev/null; then
  echo -e "${GREEN}✓ Layer dependencies and zone isolation: PASSED${NC}"
else
  echo -e "${RED}✗ Layer dependencies or zone isolation violations found${NC}"
  ERRORS=$((ERRORS + 1))
fi
echo ""

# 2. Check file naming in domain layer
echo "📋 Checking domain layer file naming..."
DOMAIN_ISSUES=0

for zone_dir in main staff parcel; do
  if [[ -d "$zone_dir/src/domain" ]]; then
    while IFS= read -r -d '' file; do
      filename=$(basename "$file")
      # Check if file ends with proper suffix
      if [[ ! "$filename" =~ \.types\.ts$ ]] && [[ ! "$filename" =~ \.use-case\.ts$ ]] && [[ "$filename" != "index.ts" ]]; then
        echo -e "${YELLOW}  Warning: $file - missing proper suffix (.types.ts or .use-case.ts)${NC}"
        DOMAIN_ISSUES=$((DOMAIN_ISSUES + 1))
      fi
      # Check kebab-case
      if [[ "$filename" =~ [A-Z] ]]; then
        echo -e "${RED}  Error: $file - should be kebab-case${NC}"
        DOMAIN_ISSUES=$((DOMAIN_ISSUES + 1))
      fi
    done < <(find "$zone_dir/src/domain" -name "*.ts" -type f -print0 2>/dev/null)
  fi
done

if [[ $DOMAIN_ISSUES -eq 0 ]]; then
  echo -e "${GREEN}✓ Domain layer naming: PASSED${NC}"
else
  echo -e "${YELLOW}⚠ Domain layer naming: $DOMAIN_ISSUES issues found${NC}"
fi
echo ""

# 3. Check file naming in infrastructure layer
echo "📋 Checking infrastructure layer file naming..."
INFRA_ISSUES=0

for zone_dir in main staff parcel; do
  if [[ -d "$zone_dir/src/infrastructure" ]]; then
    while IFS= read -r -d '' file; do
      filename=$(basename "$file")
      # Check if file ends with proper suffix
      if [[ ! "$filename" =~ \.repository\.ts$ ]] && [[ ! "$filename" =~ \.config\.ts$ ]] && [[ "$filename" != "index.ts" ]]; then
        echo -e "${YELLOW}  Warning: $file - missing proper suffix (.repository.ts or .config.ts)${NC}"
        INFRA_ISSUES=$((INFRA_ISSUES + 1))
      fi
      # Check kebab-case
      if [[ "$filename" =~ [A-Z] ]]; then
        echo -e "${RED}  Error: $file - should be kebab-case${NC}"
        INFRA_ISSUES=$((INFRA_ISSUES + 1))
      fi
    done < <(find "$zone_dir/src/infrastructure" -name "*.ts" -type f -print0 2>/dev/null)
  fi
done

if [[ $INFRA_ISSUES -eq 0 ]]; then
  echo -e "${GREEN}✓ Infrastructure layer naming: PASSED${NC}"
else
  echo -e "${YELLOW}⚠ Infrastructure layer naming: $INFRA_ISSUES issues found${NC}"
fi
echo ""

# 4. Check hooks naming
echo "📋 Checking hooks layer naming..."
HOOKS_ISSUES=0

for zone_dir in main staff parcel; do
  if [[ -d "$zone_dir/src/pages" ]]; then
    while IFS= read -r -d '' file; do
      filename=$(basename "$file")
      # Check if hook files start with use-
      if [[ ! "$filename" =~ ^use- ]] && [[ "$filename" != "index.ts" ]]; then
        echo -e "${YELLOW}  Warning: $file - hook files should start with 'use-'${NC}"
        HOOKS_ISSUES=$((HOOKS_ISSUES + 1))
      fi
    done < <(find "$zone_dir/src/pages" -path "*/hooks/*.ts" -type f -print0 2>/dev/null)
  fi
done

if [[ $HOOKS_ISSUES -eq 0 ]]; then
  echo -e "${GREEN}✓ Hooks layer naming: PASSED${NC}"
else
  echo -e "${YELLOW}⚠ Hooks layer naming: $HOOKS_ISSUES issues found${NC}"
fi
echo ""

# 5. Check for cross-zone imports (additional check)
echo "📋 Checking for cross-zone imports..."
CROSS_ZONE_ISSUES=0

for zone_dir in main staff parcel; do
  if [[ -d "$zone_dir" ]]; then
    for other_zone in main staff parcel; do
      if [[ "$zone_dir" != "$other_zone" ]]; then
        # Check for imports from other zones
        if grep -r "from.*['\"].*\.\.\/${other_zone}/" "$zone_dir" --include="*.ts" --include="*.tsx" 2>/dev/null | grep -v node_modules; then
          echo -e "${RED}  Error: $zone_dir imports from $other_zone${NC}"
          CROSS_ZONE_ISSUES=$((CROSS_ZONE_ISSUES + 1))
        fi
      fi
    done
  fi
done

if [[ $CROSS_ZONE_ISSUES -eq 0 ]]; then
  echo -e "${GREEN}✓ Cross-zone imports: PASSED${NC}"
else
  echo -e "${RED}✗ Cross-zone imports: $CROSS_ZONE_ISSUES violations found${NC}"
  ERRORS=$((ERRORS + 1))
fi
echo ""

# Summary
echo "=========================="
if [[ $ERRORS -eq 0 ]]; then
  echo -e "${GREEN}✅ All architecture validations passed!${NC}"
  exit 0
else
  echo -e "${RED}❌ $ERRORS validation errors found${NC}"
  echo ""
  echo "Fix the errors above and run validation again."
  exit 1
fi
