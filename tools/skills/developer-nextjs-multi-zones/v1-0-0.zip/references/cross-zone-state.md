# Cross-Zone State Sharing

## Table of Contents
- [The Problem](#the-problem)
- [Solutions Overview](#solutions-overview)
- [Cookies](#1-cookies)
- [localStorage](#2-localstorage)
- [URL Parameters](#3-url-parameters)
- [Server Session](#4-server-session)
- [Comparison Table](#comparison-table)
- [Recommended Approach](#recommended-approach)

---

## The Problem

Multi-zone Next.js applications run as **separate processes** with **separate React instances**. You cannot share React Context or Providers as singletons because:

1. Each zone has its own JavaScript runtime
2. Navigating between zones triggers a full page reload
3. React context state is lost on page navigation

---

## Solutions Overview

| Method | Best For | Persistence |
|--------|----------|-------------|
| Cookies | Auth tokens, user preferences | Yes |
| localStorage | UI state, client-side caching | Yes |
| URL params | Search filters, shareable state | No |
| Server session | Authentication, sensitive data | Yes |

---

## 1. Cookies

**Best for:** Auth tokens, user preferences, theme selection

### Implementation

```typescript
// packages/shared/src/lib/cookies.ts
'use client';

export function setCookie(name: string, value: string, days = 365) {
  const expires = new Date();
  expires.setTime(expires.getTime() + days * 24 * 60 * 60 * 1000);
  document.cookie = `${name}=${value};expires=${expires.toUTCString()};path=/`;
}

export function getCookie(name: string): string | null {
  const nameEQ = name + '=';
  const ca = document.cookie.split(';');
  for (let i = 0; i < ca.length; i++) {
    let c = ca[i];
    while (c.charAt(0) === ' ') c = c.substring(1, c.length);
    if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length);
  }
  return null;
}
```

### Usage

```typescript
// Theme preference that persists across zones
const [theme, setTheme] = useState(() => getCookie('ui-theme') || 'light');

const updateTheme = (newTheme: string) => {
  setTheme(newTheme);
  setCookie('ui-theme', newTheme);
};
```

**Pros:** ✅ Persists across zones, ✅ Works server-side and client-side, ✅ Private
**Cons:** ❌ Size limit (~4KB), ❌ Sent with every request

---

## 2. localStorage

**Best for:** UI state (sidebar collapsed), draft content, client-side caching

### Implementation

```typescript
// packages/shared/src/hooks/use-persisted-state.ts
'use client';

import { useState, useEffect } from 'react';

export function usePersistedState<T>(key: string, defaultValue: T) {
  const [state, setState] = useState<T>(() => {
    if (typeof window === 'undefined') return defaultValue;

    try {
      const item = window.localStorage.getItem(key);
      return item ? JSON.parse(item) : defaultValue;
    } catch (error) {
      console.error(`Error loading ${key} from localStorage:`, error);
      return defaultValue;
    }
  });

  useEffect(() => {
    try {
      window.localStorage.setItem(key, JSON.stringify(state));
    } catch (error) {
      console.error(`Error saving ${key} to localStorage:`, error);
    }
  }, [key, state]);

  return [state, setState] as const;
}
```

### Usage

```typescript
// Sidebar state that persists across zones
const [sidebarCollapsed, setSidebarCollapsed] = usePersistedState(
  'ui-sidebar-collapsed',
  false
);
```

**Pros:** ✅ Persists across zones, ✅ Larger size limit (~5-10MB), ✅ Not sent with requests
**Cons:** ❌ Client-side only, ❌ Not accessible in Server Components

---

## 3. URL Parameters

**Best for:** Search filters, pagination, shareable state

### Implementation

```typescript
// packages/shared/src/hooks/use-shared-theme.ts
'use client';

import { useSearchParams } from 'next/navigation';

export function useSharedTheme() {
  const searchParams = useSearchParams();
  const theme = searchParams.get('theme') || 'light';

  const createUrlWithTheme = (href: string, newTheme?: string) => {
    const url = new URL(href, window.location.origin);
    url.searchParams.set('theme', newTheme || theme);
    return url.toString();
  };

  return { theme, createUrlWithTheme };
}
```

### Usage in Cross-Zone Navigation

```typescript
function NavLink({ href, targetZone }: NavLinkProps) {
  const { theme, createUrlWithTheme } = useSharedTheme();
  const isSameZone = currentZone === targetZone;

  if (isSameZone) {
    return <Link href={href}>...</Link>;
  }

  // Cross-zone: preserve state in URL
  return <a href={createUrlWithTheme(href)}>...</a>;
}
```

**Pros:** ✅ Works across zones, ✅ Shareable links preserve state, ✅ No server setup
**Cons:** ❌ Exposes state in URL, ❌ Limited to serializable data

---

## 4. Server Session

**Best for:** Authentication, user identity, sensitive data

### Implementation with NextAuth.js

```typescript
// packages/shared/src/lib/auth.ts
import { getServerSession } from 'next-auth';

export async function getSharedSession() {
  return await getServerSession();
}
```

### Usage in Server Components

```typescript
// main/app/page.tsx
import { getSharedSession } from 'packages/shared/lib/auth';

export default async function HomePage() {
  const session = await getSharedSession();

  return (
    <div>
      {session ? `Welcome, ${session.user.name}` : 'Please log in'}
    </div>
  );
}
```

**Pros:** ✅ Secure (server-side), ✅ Works across zones, ✅ Handles authentication properly
**Cons:** ❌ Requires server setup, ❌ More complex

---

## Comparison Table

| Method | Persistence | Size Limit | Server Access | Security | Complexity |
|--------|------------|------------|---------------|----------|------------|
| URL Params | No | ~2KB | ✅ Yes | ⚠️ Public | ⭐ Low |
| Cookies | Yes | ~4KB | ✅ Yes | ✅ Private | ⭐⭐ Medium |
| localStorage | Yes | ~5-10MB | ❌ No | ✅ Private | ⭐ Low |
| Server Session | Yes | Unlimited | ✅ Yes | ✅✅ Secure | ⭐⭐⭐ High |

---

## Recommended Approach

For most use cases, use a **combination**:

1. **Cookies** for:
   - Theme preferences
   - Language selection
   - Simple user preferences

2. **localStorage** for:
   - UI state (sidebar collapsed, etc.)
   - Draft content
   - Client-side caching

3. **Server Session** for:
   - Authentication
   - User identity
   - Sensitive data

4. **URL Params** for:
   - Search filters
   - Pagination
   - Shareable state

---

## Combined Example

```typescript
// packages/shared/src/context/UIConfigContext.tsx
'use client';

import { createContext, useContext, ReactNode } from 'react';
import { usePersistedState } from '../hooks/use-persisted-state';
import { getCookie, setCookie } from '../lib/cookies';

interface UIConfig {
  theme: string;
  sidebarCollapsed: boolean;
  updateTheme: (theme: string) => void;
  setSidebarCollapsed: (collapsed: boolean) => void;
}

const UIConfigContext = createContext<UIConfig | null>(null);

export function UIConfigProvider({ children, config }: { children: ReactNode; config: Partial<UIConfig> }) {
  // Theme from cookie (persists across zones, accessible server-side)
  const [theme, setTheme] = usePersistedState(
    'ui-theme',
    getCookie('ui-theme') || config.theme || 'light'
  );

  // Sidebar state from localStorage (persists across zones)
  const [sidebarCollapsed, setSidebarCollapsed] = usePersistedState(
    'ui-sidebar-collapsed',
    false
  );

  const updateTheme = (newTheme: string) => {
    setTheme(newTheme);
    setCookie('ui-theme', newTheme); // Also save to cookie for server access
  };

  return (
    <UIConfigContext.Provider value={{
      theme,
      sidebarCollapsed,
      updateTheme,
      setSidebarCollapsed,
    }}>
      {children}
    </UIConfigContext.Provider>
  );
}

export function useUIConfig() {
  const context = useContext(UIConfigContext);
  if (!context) {
    throw new Error('useUIConfig must be used within UIConfigProvider');
  }
  return context;
}
```

---

## Key Takeaway

**You cannot share React Context instances between zones**, but you can:
- ✅ Share the same **Context Provider code** (`packages/shared`)
- ✅ Persist **state** using cookies/localStorage
- ✅ Initialize each zone's context from shared storage
- ✅ Keep state synchronized across zone navigation

Each zone has its own Context instance, but they read/write to the same shared storage.
