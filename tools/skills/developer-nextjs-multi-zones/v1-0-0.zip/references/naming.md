# Naming Conventions

## Table of Contents
- [ESLint Enforcement](#eslint-enforcement)
- [General Rules](#general-rules)
- [File Naming Suffixes](#file-naming-suffixes)
- [Naming Patterns](#naming-patterns)
- [File-Symbol Matching](#file-symbol-matching)
- [Do's and Don'ts](#dos-and-donts)
- [Examples](#examples)

---

## ESLint Enforcement

These conventions are enforced via ESLint (see `/.eslintrc.cjs`):

| Convention | Enforcement | Scope |
|------------|-------------|-------|
| Symbol Naming (PascalCase/camelCase) | `@typescript-eslint/naming-convention` | All files |
| File Naming (kebab-case) | `check-file/filename-naming-convention` | `src/domain/`, `src/infrastructure/`, hooks |
| Folder Naming (kebab-case) | `check-file/folder-naming-convention` | `src/domain/`, `src/infrastructure/`, `src/pages/` |
| File Suffixes | Code Review | Not auto-enforced |

**Note:** React component files/folders conventionally use PascalCase and are not enforced to be kebab-case.

---

## General Rules

| Type | Convention | Example |
|------|------------|---------|
| Symbols (Types, Classes, Components) | `PascalCase` | `AdminUser`, `CreateUserUseCase` |
| Files & Directories | `kebab-case` | `admin-users`, `create-user-use-case.ts` |
| Variables & Functions | `camelCase` | `getUsers`, `isLoading` |
| Constants | `SCREAMING_SNAKE_CASE` | `API_ENDPOINTS`, `CACHE_TAGS` |

**Language:** Use English for all names. Avoid abbreviations unless universally understood (e.g., `DTO`, `UI`, `API`).

---

## File Naming Suffixes

All files **MUST** use a semantic suffix to indicate their purpose and layer.

| Layer | Type | Suffix | Example |
|-------|------|--------|---------|
| **Domain** | Entity / Types | `.types.ts` | `users.types.ts` |
| | Use Case | `.use-case.ts` | `list-users.use-case.ts` |
| **Infrastructure** | Repository | `.repository.ts` | `users-http.repository.ts` |
| **UI (app)** | Page | `page.tsx` | `app/users/page.tsx` |
| | Layout | `layout.tsx` | `app/users/layout.tsx` |
| | API Route | `route.ts` | `app/api/users/route.ts` |
| **Hooks** | Custom Hook | `.ts` | `use-users-list.ts` |
| **Testing** | Test File | `.test.ts` | `list-users.use-case.test.ts` |

---

## Naming Patterns

### Functions

Use **Verb-Noun** pattern:

```typescript
// ✅ Good
function createUser() {}
function validateEmail() {}
function formatCurrency() {}
function getUserById() {}

// ❌ Bad
function user() {}
function emailValidation() {}
function currency() {}
```

### Custom Hooks

Use **useFeature** pattern:

```typescript
// ✅ Good
function useUsersList() {}
function useAuthSession() {}
function useCreateUser() {}

// ❌ Bad
function usersListHook() {}
function authHook() {}
```

### Collections

Use **plural nouns**:

```typescript
// ✅ Good
const users = getUsers();
const departments = fetchDepartments();

// ❌ Bad
const userList = getUsers();
const departmentData = fetchDepartments();
```

### Types and Interfaces

Use **PascalCase** with descriptive names:

```typescript
// ✅ Good
type User = { ... };
type CreateUserInput = { ... };
type ListUsersParams = { ... };
type UserResponse = { ... };

// ❌ Bad
type IUser = { ... };        // No 'I' prefix
type UserInterface = { ... }; // No 'Interface' suffix
type userData = { ... };      // Should be PascalCase
```

### Classes

Use **PascalCase** with specific names:

```typescript
// ✅ Good
class UsersHttpRepository {}
class ListUsersUseCase {}
class CreateUserUseCase {}

// ❌ Bad
class UsersService {}    // Too generic
class ApiService {}      // Too generic
class Manager {}         // Too generic
```

---

## File-Symbol Matching

File names should match their exported symbols:

| File Name | Export |
|-----------|--------|
| `use-users-list.ts` | `useUsersList` |
| `list-users.use-case.ts` | `ListUsersUseCase` |
| `users-http.repository.ts` | `UsersHttpRepository` |
| `users.types.ts` | `User`, `CreateUserInput`, etc. |

---

## Do's and Don'ts

### ✅ Do

- Use verb-noun for functions: `createUser`, `validateEmail`
- Use `useFeature` for custom hooks: `useUsersList`, `useAuthSession`
- Use plural nouns for collections: `const users = getUsers()`
- Be specific: `HttpUsersRepository` > `ApiService`
- Match file and symbol names

### ❌ Don't

- Use generic names: `Manager`, `Helper`, `Service`, `utils.ts`
- Use technical prefixes in domain: `IUserEntity`, `UserInterface`
- Use abbreviations: `usr`, `dept`, `btn` (unless universal)
- Mix naming conventions in the same file

---

## Examples

### Feature: Users Management (in Staff Zone)

```
staff/
├── src/
│   ├── domain/
│   │   └── users/
│   │       ├── users.types.ts           → User, CreateUserInput
│   │       ├── list-users.use-case.ts   → ListUsersUseCase
│   │       └── create-user.use-case.ts  → CreateUserUseCase
│   │
│   ├── infrastructure/
│   │   └── users/
│   │       └── users-http.repository.ts → UsersHttpRepository
│   │
│   └── pages/
│       └── users/
│           ├── components/
│           │   ├── user-table.tsx       → UserTable
│           │   └── user-form.tsx        → UserForm
│           └── hooks/
│               ├── use-users-list.ts    → useUsersList
│               └── use-create-user.ts   → useCreateUser
│
└── app/
    └── [locale]/
        └── (app)/
            └── users/
                └── page.tsx             → UsersPage (default export)
```

> **Note:** Replace `staff/` with your zone name (e.g., `main/`, `parcel/`) when implementing in other zones.
