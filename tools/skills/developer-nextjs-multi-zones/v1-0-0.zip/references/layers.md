# Layer Guide

## Table of Contents
- [Multi-Zone Context](#multi-zone-context)
- [UI Layer](#1-ui-layer)
- [Hooks Layer](#2-hooks-layer)
- [Server Actions Layer](#3-server-actions-layer)
- [Domain Layer](#4-domain-layer)
- [Infrastructure Layer](#5-infrastructure-layer)
- [Shared Package](#6-shared-package)
- [Layer Communication](#layer-communication)

---

## Multi-Zone Context

Each zone (main, blog, staff, parcel) is an independent Next.js application that follows the same layered architecture. Shared code lives in `packages/shared`.

```
┌─────────────────────────────────────────────────────────────────┐
│                          Zone (e.g., staff/)                     │
├─────────────────────────────────────────────────────────────────┤
│  app/                                                            │
│    ├── [locale]/(app)/  → UI Layer (Pages, Layouts)             │
│    ├── api/             → API Routes (GET only)                  │
│    └── actions/         → Server Actions (POST/PUT/DELETE)       │
│  src/screens/           → Hooks Layer + Feature Components       │
│  src/domain/            → Domain Layer (Types, Use Cases)        │
│  src/infrastructure/    → Infrastructure Layer (Repositories)   │
├─────────────────────────────────────────────────────────────────┤
│                     packages/shared/                             │
│  (Shared Components, Styles, Hooks, Utils)                      │
└─────────────────────────────────────────────────────────────────┘
```

### Multi-Zone API Routes

**IMPORTANT:** In a multi-zone setup, API routes should be organized under `app/api/[zone]/` for clear separation:

| Zone | API Route Location | URL Path |
|------|-------------------|----------|
| main | `main/app/api/[feature]/route.ts` | `/api/[feature]` |
| staff | `staff/app/api/staff/[feature]/route.ts` | `/api/staff/[feature]` |
| parcel | `parcel/app/api/parcel/[feature]/route.ts` | `/api/parcel/[feature]` |

This convention keeps API routes organized by zone under the `/api/` path and maintains clear namespacing between zones.

### API Error Handling (MANDATORY)

All API routes MUST handle errors from backend APIs with proper status codes using `isApiError`:

```typescript
import { NextRequest, NextResponse } from 'next/server';
import { isApiError } from 'packages/shared';

export async function GET(request: NextRequest) {
  try {
    // ... route logic
  } catch (error) {
    console.error('[API] Error:', error);

    // IMPORTANT: Preserve actual error status (401, 403, 404, etc.)
    if (isApiError(error)) {
      return NextResponse.json(
        { error: { message: error.message, code: error.error, data: error.data } },
        { status: error.status }
      );
    }

    return NextResponse.json(
      { error: { message: 'internal server error', code: 'internal_server_error' } },
      { status: 500 }
    );
  }
}
```

This ensures backend errors (401 Unauthorized, 403 Forbidden, 404 Not Found) are properly forwarded to the client.

---

## 1. UI Layer

**Zone Location:** `[zone]/app/[locale]/(app)/[feature]/`
**Shared Location:** `packages/shared/src/components/`

The user-facing part of the application. Pages use Next.js App Router.

### Responsibilities
- Render UI components
- Handle user interactions
- Call custom hooks for data and state
- Display loading and error states

### Files

| Type | Location | Example |
|------|----------|---------|
| Page | `[zone]/app/[locale]/(app)/[feature]/page.tsx` | `staff/app/[locale]/(app)/staff/page.tsx` |
| Layout | `[zone]/app/[locale]/(app)/layout.tsx` | `staff/app/[locale]/(app)/layout.tsx` |
| Zone Component | `[zone]/components/` | `staff/components/StaffLayout.tsx` |
| Feature Component | `[zone]/src/screens/[feature]/components/` | `staff/src/screens/users/components/user-table.tsx` |

### Using Shared Components

```typescript
// Import from packages/shared
import { Button, Input, Table } from 'packages/shared/components/shadcn';
import { dataTableClasses } from 'packages/shared/styles/dataTable';

// Use in zone pages
export default function StaffPage() {
  return (
    <div className={dataTableClasses.pageContainer}>
      <Button>Click me</Button>
    </div>
  );
}
```

### Guidelines
- Use shared components from `packages/shared` for consistency
- Use shared styles from `packages/shared/src/styles/`
- Keep zone-specific components in `[zone]/components/`
- Use translations from zone's `i18n/locales/`

---

## 2. Hooks Layer

**Zone Location:** `[zone]/src/screens/[feature]/hooks/`
**Shared Location:** `packages/shared/src/hooks/`

The client-side hub for state and data fetching orchestration.

### Responsibilities
- Manage component state (`useState`)
- Handle side effects (`useEffect`)
- Orchestrate data fetching with TanStack Query
- Transform data for UI consumption

### Files

| Type | Location | Example |
|------|----------|---------|
| Query Hook | `[zone]/src/screens/[feature]/hooks/use-[feature]-list.ts` | `use-users-list.ts` |
| Mutation Hook | `[zone]/src/screens/[feature]/hooks/use-[action]-[feature].ts` | `use-create-user.ts` |
| Shared Hook | `packages/shared/src/hooks/` | `use-persisted-state.ts` |

### Patterns

**Data Fetching (GET)**
```typescript
// staff/src/screens/users/hooks/use-users-list.ts
import { useQuery } from '@tanstack/react-query';

// IMPORTANT: Use zone-namespaced API path
// - main zone: '/api/users'
// - staff zone: '/api/staff/users'
// - parcel zone: '/api/parcel/users'

export function useUsersList() {
  return useQuery({
    queryKey: ['users'],
    queryFn: () => fetch('/api/staff/users').then(res => res.json()),
  });
}
```

**Mutations (POST/PUT/DELETE) - ALWAYS use Server Actions**
```typescript
// staff/src/screens/users/hooks/use-create-user.ts
'use client';

import { useSession } from 'next-auth/react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useLocale } from 'packages/shared';
import type { CreateUserInput } from '@/domain/users';
import { createUserAction } from '../../../../app/actions/users.actions';

export function useCreateUser() {
  const { data: session } = useSession();
  const locale = useLocale();
  const queryClient = useQueryClient();

  const accessToken = (session as { accessToken?: string } | null)?.accessToken || '';

  return useMutation({
    mutationFn: async (input: CreateUserInput) => {
      const result = await createUserAction(accessToken, input, locale);

      if (!result.success) {
        throw new Error(result.error.message);
      }

      return result.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['users'] });
    },
  });
}

// staff/src/screens/users/hooks/use-update-user.ts
import { updateUserAction } from '../../../../app/actions/users.actions';

export function useUpdateUser(userId: string) {
  const { data: session } = useSession();
  const locale = useLocale();
  const queryClient = useQueryClient();

  const accessToken = (session as { accessToken?: string } | null)?.accessToken || '';

  return useMutation({
    mutationFn: async (input: UpdateUserInput) => {
      const result = await updateUserAction(accessToken, userId, input, locale);

      if (!result.success) {
        throw new Error(result.error.message);
      }

      return result.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['user-detail', userId] });
      queryClient.invalidateQueries({ queryKey: ['users'] });
    },
  });
}
```

---

## 3. Server Actions Layer

**Zone Location:** `[zone]/app/actions/`

Server Actions handle all mutations (POST, PUT, DELETE). They run on the server and provide better security than client-side API calls.

### Responsibilities
- Handle create, update, delete operations
- Validate authentication (access token)
- Call domain use cases
- Revalidate cached data after mutations
- Return typed success/error results

### Files

| Type | Location | Example |
|------|----------|---------|
| Feature Actions | `[zone]/app/actions/[feature].actions.ts` | `staff/app/actions/staff.actions.ts` |

### Patterns

**Action Result Type**
```typescript
// Typed result for consistent error handling
export type ActionResult<T> =
  | { success: true; data: T }
  | { success: false; error: { message: string; code: string; data?: unknown } };
```

**Create Action**
```typescript
// staff/app/actions/users.actions.ts
'use server';

import { revalidatePath } from 'next/cache';
import type { CreateUserInput, UserResponse } from '@/domain/users';
import { CreateUserUseCase } from '@/domain/users';
import { createUserRepository } from '@/infrastructure/users';
import { isApiError } from 'packages/shared';

export type CreateUserResult = ActionResult<UserResponse>;

export async function createUserAction(
  accessToken: string,
  input: CreateUserInput,
  locale: string = 'en'
): Promise<CreateUserResult> {
  try {
    if (!accessToken) {
      return {
        success: false,
        error: { message: 'Access token is required', code: 'unauthorized' },
      };
    }

    const repository = createUserRepository(accessToken, locale);
    const useCase = new CreateUserUseCase(repository);
    const result = await useCase.execute(input);

    // Revalidate list page
    revalidatePath('/staff');

    return { success: true, data: result };
  } catch (error) {
    console.error('[Action] Error creating user:', error);

    if (isApiError(error)) {
      return {
        success: false,
        error: { message: error.message, code: error.error, data: error.data },
      };
    }

    if (error instanceof Error) {
      return {
        success: false,
        error: { message: error.message, code: 'validation_error' },
      };
    }

    return {
      success: false,
      error: { message: 'internal server error', code: 'internal_server_error' },
    };
  }
}
```

**Update Action**
```typescript
export async function updateUserAction(
  accessToken: string,
  userId: string,
  input: UpdateUserInput,
  locale: string = 'en'
): Promise<UpdateUserResult> {
  try {
    if (!accessToken) {
      return {
        success: false,
        error: { message: 'Access token is required', code: 'unauthorized' },
      };
    }

    if (!userId) {
      return {
        success: false,
        error: { message: 'User ID is required', code: 'bad_request' },
      };
    }

    const repository = createUserRepository(accessToken, locale);
    const useCase = new UpdateUserUseCase(repository);
    const result = await useCase.execute(userId, input);

    // Revalidate both list and detail pages
    revalidatePath('/staff');
    revalidatePath(`/staff/${userId}`);

    return { success: true, data: result };
  } catch (error) {
    // ... error handling same as create
  }
}
```

**Delete Action**
```typescript
export async function deleteUserAction(
  accessToken: string,
  userId: string,
  locale: string = 'en'
): Promise<DeleteUserResult> {
  try {
    if (!accessToken) {
      return {
        success: false,
        error: { message: 'Access token is required', code: 'unauthorized' },
      };
    }

    const repository = createUserRepository(accessToken, locale);
    await repository.delete(userId);

    revalidatePath('/staff');

    return { success: true, data: undefined };
  } catch (error) {
    // ... error handling
  }
}
```

### Guidelines
- ALWAYS use Server Actions for POST, PUT, DELETE operations
- Use API Routes ONLY for GET requests
- Always validate access token at the start
- Use `revalidatePath()` to invalidate cached data
- Return typed results with `success` boolean for consistent error handling
- Log errors with `[Action]` prefix for debugging

---

## 4. Domain Layer

**Zone Location:** `[zone]/src/domain/[feature]/`

The core business logic of the application. This layer is zone-specific.

### Responsibilities
- Define business entities and types
- Implement use cases (business operations)
- Validate business rules
- Keep logic framework-agnostic

### Files

| Type | Suffix | Example |
|------|--------|---------|
| Types | `.types.ts` | `staff/src/domain/users/users.types.ts` |
| Use Case | `.use-case.ts` | `staff/src/domain/users/list-users.use-case.ts` |

### Patterns

**Types Definition**
```typescript
// staff/src/domain/users/users.types.ts
export type User = {
  id: string;
  name: string;
  email: string;
  accountType: string;
  department: string;
  isActive: boolean;
  lastUpdated: Date;
};

export type CreateUserInput = {
  name: string;
  email: string;
  accountType: string;
  department: string;
};

export type ListUsersParams = {
  page: number;
  limit: number;
  search?: string;
};
```

**Use Case**
```typescript
// staff/src/domain/users/list-users.use-case.ts
import { UsersRepository } from '@/infrastructure/users/users-http.repository';
import type { ListUsersParams, User } from './users.types';

export class ListUsersUseCase {
  constructor(private repository: UsersRepository) {}

  async execute(params: ListUsersParams): Promise<User[]> {
    return this.repository.findAll(params);
  }
}
```

---

## 5. Infrastructure Layer

**Zone Location:** `[zone]/src/infrastructure/[feature]/`
**Shared Location:** `packages/shared/src/lib/` (utilities like auth)

The concrete implementation of data access.

### Responsibilities
- Implement repository interfaces
- Handle HTTP requests with Axios
- Transform API responses to domain entities
- Handle API errors

### Files

| Type | Suffix | Example |
|------|--------|---------|
| Repository | `.repository.ts` | `staff/src/infrastructure/users/users-http.repository.ts` |
| Config | `.config.ts` | `main/src/infrastructure/auth/next-auth.config.ts` |

### Patterns

**Repository Implementation**
```typescript
// staff/src/infrastructure/users/users-http.repository.ts
import axios from 'axios';
import type { User, CreateUserInput, ListUsersParams } from '@/domain/users/users.types';

const API_BASE = process.env.NEXT_PUBLIC_API_URL;

export class UsersHttpRepository {
  async findAll(params: ListUsersParams): Promise<User[]> {
    const response = await axios.get(`${API_BASE}/users`, { params });
    return response.data;
  }

  async findById(id: string): Promise<User> {
    const response = await axios.get(`${API_BASE}/users/${id}`);
    return response.data;
  }

  async create(input: CreateUserInput): Promise<User> {
    const response = await axios.post(`${API_BASE}/users`, input);
    return response.data;
  }

  async update(id: string, input: Partial<CreateUserInput>): Promise<User> {
    const response = await axios.put(`${API_BASE}/users/${id}`, input);
    return response.data;
  }

  async delete(id: string): Promise<void> {
    await axios.delete(`${API_BASE}/users/${id}`);
  }
}
```

---

## 6. Shared Package

**Location:** `packages/shared/`

Code shared across all zones.

### What Goes in Shared

| Type | Location | Example |
|------|----------|---------|
| UI Components | `src/components/shadcn/` | `button.tsx`, `table.tsx` |
| Layouts | `src/components/` | `UnifiedSidebar/`, `UnifiedHeader/` |
| Design Tokens | `src/styles/` | `dataTable.ts`, `sidebar.ts` |
| Shared Hooks | `src/hooks/` | `use-persisted-state.ts` |
| Utilities | `src/lib/` | `auth.ts`, `utils.ts` |
| i18n | `src/i18n/` | Providers, shared translations |

### Importing from Shared

```typescript
// Components
import { Button, Input } from 'packages/shared/components/shadcn';
import { UnifiedSidebar } from 'packages/shared/components/UnifiedSidebar';

// Styles
import { dataTableClasses } from 'packages/shared/styles/dataTable';
import { sidebarClasses } from 'packages/shared/styles/sidebar';

// Hooks
import { usePersistedState } from 'packages/shared/hooks';

// Utils
import { cn } from 'packages/shared/lib/utils';
```

### What NOT to Put in Shared
- Zone-specific business logic
- Zone-specific types (put in zone's `src/domain/`)
- Zone-specific API integrations

---

## Layer Communication

**GET Request Flow:**
```
┌──────────────┐     ┌──────────────┐     ┌──────────────┐     ┌──────────────┐     ┌──────────────┐
│     UI       │────▶│    Hooks     │────▶│  API Route   │────▶│   Domain     │────▶│Infrastructure│
│  (page.tsx)  │     │ (useQuery)   │     │  (route.ts)  │     │ (Use Case)   │     │ (Repository) │
└──────────────┘     └──────────────┘     └──────────────┘     └──────────────┘     └──────────────┘
```

**Mutation Flow (POST/PUT/DELETE):**
```
┌──────────────┐     ┌──────────────┐     ┌──────────────┐     ┌──────────────┐     ┌──────────────┐
│     UI       │────▶│    Hooks     │────▶│Server Action │────▶│   Domain     │────▶│Infrastructure│
│  (page.tsx)  │     │(useMutation) │     │(.actions.ts) │     │ (Use Case)   │     │ (Repository) │
└──────────────┘     └──────────────┘     └──────────────┘     └──────────────┘     └──────────────┘
```

### Rules
1. **UI only calls Hooks** - Never directly calls Domain or Infrastructure
2. **Hooks call API Routes for GET** - Via fetch with useQuery
3. **Hooks call Server Actions for mutations** - Via useMutation (POST, PUT, DELETE)
4. **API Routes/Server Actions call Domain** - Use cases for business logic
5. **Domain calls Infrastructure** - Repositories for data access
6. **Infrastructure has no dependencies** - On other layers
7. **Shared is imported by all** - But doesn't import from zones

### Why Server Actions for Mutations?
- **Security**: Sensitive logic runs on server, not exposed to client
- **Automatic revalidation**: `revalidatePath()` works seamlessly
- **Type safety**: Full TypeScript support with result types
- **Error handling**: Consistent error format across all mutations
- **Better DX**: No need to create separate API route handlers for mutations
