# Code Examples

## Table of Contents
- [Complete Feature: Users Management](#complete-feature-users-management)
- [Domain Layer](#1-domain-layer)
- [Infrastructure Layer](#2-infrastructure-layer)
- [API Routes](#3-api-routes)
- [Hooks Layer](#4-hooks-layer)
- [UI Layer](#5-ui-layer)

---

## Complete Feature: Users Management

This example shows how to implement a users list feature across all layers in the **staff zone**.

> **Note:** Replace `staff/` with your zone name (e.g., `main/`, `parcel/`) when implementing in other zones.

---

## 1. Domain Layer

### Types Definition

```typescript
// staff/src/domain/users/users.types.ts

export type User = {
  id: string;
  name: string;
  email: string;
  phone: string;
  accountType: string;
  department: string;
  isActive: boolean;
  lastUpdated: Date;
};

export type CreateUserInput = {
  name: string;
  email: string;
  phone: string;
  accountType: string;
  department: string;
};

export type UpdateUserInput = Partial<CreateUserInput> & {
  isActive?: boolean;
};

export type ListUsersParams = {
  page: number;
  limit: number;
  search?: string;
  sortBy?: keyof User;
  sortOrder?: 'asc' | 'desc';
};

export type PaginatedResponse<T> = {
  data: T[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
};
```

### Use Cases

```typescript
// staff/src/domain/users/list-users.use-case.ts

import type { ListUsersParams, PaginatedResponse, User } from './users.types';

export interface UsersRepository {
  findAll(params: ListUsersParams): Promise<PaginatedResponse<User>>;
}

export class ListUsersUseCase {
  constructor(private repository: UsersRepository) {}

  async execute(params: ListUsersParams): Promise<PaginatedResponse<User>> {
    // Business logic / validation can go here
    if (params.limit > 100) {
      params.limit = 100; // Max limit
    }

    return this.repository.findAll(params);
  }
}
```

```typescript
// staff/src/domain/users/create-user.use-case.ts

import type { CreateUserInput, User } from './users.types';

export interface UsersRepository {
  create(input: CreateUserInput): Promise<User>;
  findByEmail(email: string): Promise<User | null>;
}

export class CreateUserUseCase {
  constructor(private repository: UsersRepository) {}

  async execute(input: CreateUserInput): Promise<User> {
    // Business validation
    const existing = await this.repository.findByEmail(input.email);
    if (existing) {
      throw new Error('User with this email already exists');
    }

    return this.repository.create(input);
  }
}
```

---

## 2. Infrastructure Layer

### Repository

```typescript
// staff/src/infrastructure/users/users-http.repository.ts

import axios from 'axios';
import type {
  User,
  CreateUserInput,
  UpdateUserInput,
  ListUsersParams,
  PaginatedResponse,
} from '@/domain/users/users.types';

const API_BASE = process.env.NEXT_PUBLIC_API_URL;

export class UsersHttpRepository {
  private client = axios.create({
    baseURL: `${API_BASE}/users`,
  });

  async findAll(params: ListUsersParams): Promise<PaginatedResponse<User>> {
    const response = await this.client.get('/', { params });
    return response.data;
  }

  async findById(id: string): Promise<User> {
    const response = await this.client.get(`/${id}`);
    return response.data;
  }

  async findByEmail(email: string): Promise<User | null> {
    try {
      const response = await this.client.get('/by-email', { params: { email } });
      return response.data;
    } catch {
      return null;
    }
  }

  async create(input: CreateUserInput): Promise<User> {
    const response = await this.client.post('/', input);
    return response.data;
  }

  async update(id: string, input: UpdateUserInput): Promise<User> {
    const response = await this.client.put(`/${id}`, input);
    return response.data;
  }

  async delete(id: string): Promise<void> {
    await this.client.delete(`/${id}`);
  }

  async toggleActive(id: string, isActive: boolean): Promise<User> {
    const response = await this.client.patch(`/${id}/status`, { isActive });
    return response.data;
  }
}

// Singleton instance
export const usersRepository = new UsersHttpRepository();
```

---

## 3. API Routes

**IMPORTANT: Multi-Zone API Route Paths**

In a multi-zone setup, API routes should be organized under `app/api/[zone]/`:

| Zone | API Route Location | URL Path |
|------|-------------------|----------|
| main | `main/app/api/users/route.ts` | `/api/users` |
| staff | `staff/app/api/staff/users/route.ts` | `/api/staff/users` |
| parcel | `parcel/app/api/parcel/users/route.ts` | `/api/parcel/users` |

### GET Route

```typescript
// staff/app/api/staff/users/route.ts
// URL: /api/staff/users

import { NextRequest, NextResponse } from 'next/server';
import { ListUsersUseCase } from '@/domain/users/list-users.use-case';
import { createUsersRepository } from '@/infrastructure/users/users-http.repository';
import { isApiError } from 'packages/shared';

export async function GET(request: NextRequest) {
  try {
    // Get access token from Authorization header
    const authHeader = request.headers.get('authorization');
    const accessToken = authHeader?.replace('Bearer ', '');

    if (!accessToken) {
      return NextResponse.json(
        { error: { message: 'Access token is required', code: 'unauthorized' } },
        { status: 401 }
      );
    }

    // Get locale from Accept-Language header
    const acceptLanguage = request.headers.get('accept-language') || 'en';
    const locale = acceptLanguage.startsWith('th') ? 'th' : 'en';

    const searchParams = request.nextUrl.searchParams;
    const params = {
      page: Number(searchParams.get('page')) || 1,
      limit: Number(searchParams.get('limit')) || 10,
      search: searchParams.get('search') || undefined,
    };

    const repository = createUsersRepository(accessToken, locale);
    const useCase = new ListUsersUseCase(repository);
    const result = await useCase.execute(params);

    return NextResponse.json(result);
  } catch (error) {
    console.error('[API] Error fetching users:', error);

    // IMPORTANT: Handle API errors with proper status codes
    // This preserves 401, 403, 404, etc. from the backend
    if (isApiError(error)) {
      return NextResponse.json(
        { error: { message: error.message, code: error.error, data: error.data } },
        { status: error.status }
      );
    }

    return NextResponse.json(
      { error: { message: 'internal server error', code: 'internal_server_error' } },
      { status: 500 }
    );
  }
}
```

### Server Action (Mutations)

```typescript
// staff/app/actions/users.actions.ts
'use server';

import { revalidatePath } from 'next/cache';
import { CreateUserUseCase } from '@/domain/users/create-user.use-case';
import { usersRepository } from '@/infrastructure/users/users-http.repository';
import type { CreateUserInput } from '@/domain/users/users.types';

export async function createUserAction(input: CreateUserInput) {
  try {
    const useCase = new CreateUserUseCase(usersRepository);
    const user = await useCase.execute(input);

    revalidatePath('/users');

    return { success: true, data: user };
  } catch (error) {
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Failed to create user',
    };
  }
}

export async function toggleUserActiveAction(id: string, isActive: boolean) {
  try {
    const user = await usersRepository.toggleActive(id, isActive);
    revalidatePath('/users');
    return { success: true, data: user };
  } catch (error) {
    return { success: false, error: 'Failed to update user status' };
  }
}

export async function deleteUserAction(id: string) {
  try {
    await usersRepository.delete(id);
    revalidatePath('/users');
    return { success: true };
  } catch (error) {
    return { success: false, error: 'Failed to delete user' };
  }
}
```

---

## 4. Hooks Layer

### List Hook (Query)

```typescript
// staff/src/screens/users/hooks/use-users-list.ts

import { useQuery } from '@tanstack/react-query';
import type { ListUsersParams, PaginatedResponse, User } from '@/domain/users/users.types';

// IMPORTANT: Use zone-namespaced API path
// - main zone: '/api/users'
// - staff zone: '/api/staff/users'
// - parcel zone: '/api/parcel/users'

async function fetchUsers(params: ListUsersParams): Promise<PaginatedResponse<User>> {
  const searchParams = new URLSearchParams({
    page: params.page.toString(),
    limit: params.limit.toString(),
    ...(params.search && { search: params.search }),
  });

  const response = await fetch(`/api/staff/users?${searchParams}`);
  if (!response.ok) throw new Error('Failed to fetch users');
  return response.json();
}

export function useUsersList(params: ListUsersParams) {
  return useQuery({
    queryKey: ['users', params],
    queryFn: () => fetchUsers(params),
    staleTime: 5 * 60 * 1000, // 5 minutes
  });
}
```

### Create Hook (Mutation)

```typescript
// staff/src/screens/users/hooks/use-create-user.ts

import { useMutation, useQueryClient } from '@tanstack/react-query';
import { createUserAction } from '@/app/actions/users.actions';
import type { CreateUserInput } from '@/domain/users/users.types';

export function useCreateUser() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (input: CreateUserInput) => createUserAction(input),
    onSuccess: (result) => {
      if (result.success) {
        queryClient.invalidateQueries({ queryKey: ['users'] });
      }
    },
  });
}
```

### Toggle Active Hook

```typescript
// staff/src/screens/users/hooks/use-toggle-user-active.ts

import { useMutation, useQueryClient } from '@tanstack/react-query';
import { toggleUserActiveAction } from '@/app/actions/users.actions';

export function useToggleUserActive() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ id, isActive }: { id: string; isActive: boolean }) =>
      toggleUserActiveAction(id, isActive),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['users'] });
    },
  });
}
```

---

## 5. UI Layer

### Page Component

```typescript
// staff/app/[locale]/(app)/users/page.tsx
'use client';

import { useState } from 'react';
import { useUsersList } from '@/pages/users/hooks/use-users-list';
import { useToggleUserActive } from '@/pages/users/hooks/use-toggle-user-active';
import { UserTable } from '@/pages/users/components/user-table';
import { UserFilters } from '@/pages/users/components/user-filters';
import { dataTableClasses } from 'packages/shared/styles/dataTable';

export default function UsersPage() {
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');

  const { data, isLoading, error } = useUsersList({
    page,
    limit: 10,
    search: search || undefined,
  });

  const toggleActive = useToggleUserActive();

  if (error) return <div>Error loading users</div>;

  return (
    <div className={dataTableClasses.pageContainer}>
      <div className={dataTableClasses.pageHeader}>
        <h1 className={dataTableClasses.pageTitle}>Users</h1>
      </div>

      <UserFilters
        search={search}
        onSearchChange={setSearch}
      />

      <UserTable
        users={data?.data ?? []}
        isLoading={isLoading}
        onToggleActive={(id, isActive) =>
          toggleActive.mutate({ id, isActive })
        }
      />

      {/* Pagination */}
      {data && (
        <div className={dataTableClasses.pagination}>
          <span>Page {data.page} of {data.totalPages}</span>
          <div>
            <button
              onClick={() => setPage(p => Math.max(1, p - 1))}
              disabled={page === 1}
            >
              Previous
            </button>
            <button
              onClick={() => setPage(p => p + 1)}
              disabled={page >= data.totalPages}
            >
              Next
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
```

### Form with Validation

```typescript
// staff/src/screens/users/components/user-form.tsx
'use client';

import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useCreateUser } from '@/pages/users/hooks/use-create-user';
import { Input } from 'packages/shared/components/shadcn';
import { Button } from 'packages/shared/components/shadcn';

const schema = z.object({
  name: z.string().min(1, 'Name is required'),
  email: z.string().email('Invalid email'),
  phone: z.string().min(10, 'Phone must be at least 10 digits'),
  accountType: z.string().min(1, 'Account type is required'),
  department: z.string().min(1, 'Department is required'),
});

type FormData = z.infer<typeof schema>;

export function UserForm({ onSuccess }: { onSuccess?: () => void }) {
  const createUser = useCreateUser();

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm<FormData>({
    resolver: zodResolver(schema),
  });

  const onSubmit = async (data: FormData) => {
    const result = await createUser.mutateAsync(data);
    if (result.success) {
      reset();
      onSuccess?.();
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <div>
        <Input {...register('name')} placeholder="Name" />
        {errors.name && <span className="text-red-500">{errors.name.message}</span>}
      </div>

      <div>
        <Input {...register('email')} placeholder="Email" type="email" />
        {errors.email && <span className="text-red-500">{errors.email.message}</span>}
      </div>

      <div>
        <Input {...register('phone')} placeholder="Phone" />
        {errors.phone && <span className="text-red-500">{errors.phone.message}</span>}
      </div>

      <Button type="submit" disabled={createUser.isPending}>
        {createUser.isPending ? 'Creating...' : 'Create User'}
      </Button>

      {createUser.data?.error && (
        <div className="text-red-500">{createUser.data.error}</div>
      )}
    </form>
  );
}
```

---

## Summary

| Layer | Responsibility | Key Pattern |
|-------|---------------|-------------|
| Domain | Types, Use Cases | Business logic |
| Infrastructure | Repository | HTTP requests |
| API | Routes, Actions | GET routes, Server Actions |
| Hooks | Data fetching | TanStack Query |
| UI | Components | React + Shadcn |
