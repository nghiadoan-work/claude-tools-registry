# Test-ID Convention (MANDATORY)

This document defines the **mandatory** test-id naming convention for all UI components. Every interactive and significant UI element MUST have a `test-id` attribute for Robot Framework testing.

## Pattern

```
[page]-[type]-[descriptive-name]
```

- **page**: The page or component context (e.g., `staff`, `login`, `parcel`, `sidebar`, `header`)
- **type**: Element type prefix (see table below)
- **descriptive-name**: Kebab-case description of the element's purpose

## Element Type Prefixes

| Prefix | Element Type | Example |
|--------|-------------|---------|
| `btn` | Buttons, clickable actions | `login-btn-submit`, `staff-btn-filter` |
| `input` | Text inputs, textareas | `login-input-email`, `staff-input-search` |
| `select` | Dropdowns, select boxes | `staff-select-role`, `parcel-select-status` |
| `form` | Form containers | `login-form-main`, `staff-form-create` |
| `link` | Navigation links | `sidebar-link-home`, `staff-link-detail` |
| `modal` | Modal/dialog containers | `staff-modal-create`, `parcel-modal-confirm` |
| `card` | Card containers | `parcel-card-123`, `staff-card-member` |
| `list` | Lists/tables | `staff-list-members`, `parcel-list-items` |
| `row` | Table rows | `staff-row-123`, `parcel-row-456` |
| `cell` | Table cells | `staff-cell-name-123`, `staff-cell-role-123` |
| `item` | List items (non-table) | `staff-item-member-123` |
| `txt` | Static text/labels to verify | `staff-txt-total`, `login-txt-error` |
| `img` | Images | `login-img-logo`, `staff-img-avatar-123` |
| `sheet` | Bottom sheets, drawers | `staff-sheet-filter`, `parcel-sheet-details` |
| `tab` | Tab buttons | `parcel-tab-pending`, `staff-tab-active` |
| `badge` | Status badges | `staff-badge-status-123`, `parcel-badge-priority` |
| `icon` | Icon buttons | `header-icon-notification`, `staff-icon-edit-123` |
| `section` | Page sections | `staff-section-filters`, `parcel-section-summary` |
| `nav` | Navigation containers | `sidebar-nav-main`, `header-nav-user` |
| `th` | Table headers | `staff-th-name`, `staff-th-role` |
| `thead` | Table head | `staff-list-thead` |
| `tbody` | Table body | `staff-list-tbody` |

## Dynamic IDs for Lists

When elements are part of a list, append the item's unique ID:

```typescript
// Pattern: [page]-[type]-[name]-${id}
<tr test-id={`staff-row-${member.id}`}>
  <td test-id={`staff-cell-name-${member.id}`}>{member.name}</td>
  <td test-id={`staff-cell-role-${member.id}`}>{member.role}</td>
  <td>
    <span test-id={`staff-badge-status-${member.id}`}>{member.status}</span>
  </td>
  <td>
    <button test-id={`staff-btn-edit-${member.id}`}>Edit</button>
    <button test-id={`staff-btn-delete-${member.id}`}>Delete</button>
  </td>
</tr>
```

## Complete Examples

### Login Page

```tsx
export default function LoginPage() {
  return (
    <div test-id="login-page-container">
      <form test-id="login-form-main">
        <img test-id="login-img-logo" src="/logo.png" alt="Logo" />

        <div test-id="login-section-inputs">
          <input test-id="login-input-email" type="email" />
          <input test-id="login-input-password" type="password" />
        </div>

        <span test-id="login-txt-error">{error}</span>

        <button test-id="login-btn-submit" type="submit">
          Login
        </button>

        <a test-id="login-link-forgot-password" href="/forgot">
          Forgot Password?
        </a>
      </form>

      <p test-id="login-txt-version">v{version}</p>
    </div>
  );
}
```

### Staff List Page

```tsx
export default function StaffPage() {
  const { data, isLoading } = useStaffList();

  return (
    <div test-id="staff-list-container">
      {/* Header Controls */}
      <div test-id="staff-list-header">
        <input test-id="staff-input-search" placeholder="Search..." />
        <button test-id="staff-btn-filter">Filter</button>
        <button test-id="staff-btn-create">Create New</button>
        <span test-id="staff-txt-total">Total: {data?.total}</span>
      </div>

      {/* Loading State */}
      {isLoading && (
        <div test-id="staff-list-loading">
          <span test-id="staff-txt-loading">Loading...</span>
        </div>
      )}

      {/* Empty State */}
      {!isLoading && data?.items.length === 0 && (
        <div test-id="staff-list-empty">
          <img test-id="staff-img-empty" src="/empty.svg" />
          <span test-id="staff-txt-empty">No members found</span>
          <button test-id="staff-btn-create-first">Create First Member</button>
        </div>
      )}

      {/* Data Table */}
      {!isLoading && data?.items.length > 0 && (
        <table test-id="staff-list-table">
          <thead test-id="staff-list-thead">
            <tr>
              <th test-id="staff-th-name">Name</th>
              <th test-id="staff-th-email">Email</th>
              <th test-id="staff-th-role">Role</th>
              <th test-id="staff-th-status">Status</th>
              <th test-id="staff-th-actions">Actions</th>
            </tr>
          </thead>
          <tbody test-id="staff-list-tbody">
            {data.items.map((member) => (
              <tr test-id={`staff-row-${member.id}`} key={member.id}>
                <td test-id={`staff-cell-name-${member.id}`}>
                  <img test-id={`staff-img-avatar-${member.id}`} src={member.avatar} />
                  {member.name}
                </td>
                <td test-id={`staff-cell-email-${member.id}`}>{member.email}</td>
                <td test-id={`staff-cell-role-${member.id}`}>{member.role}</td>
                <td>
                  <span test-id={`staff-badge-status-${member.id}`}>
                    {member.status}
                  </span>
                </td>
                <td>
                  <button test-id={`staff-btn-view-${member.id}`}>View</button>
                  <button test-id={`staff-btn-edit-${member.id}`}>Edit</button>
                  <button test-id={`staff-btn-delete-${member.id}`}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {/* Pagination */}
      <div test-id="staff-list-pagination">
        <button test-id="staff-btn-prev-page" disabled={page === 1}>
          Previous
        </button>
        <span test-id="staff-txt-current-page">Page {page} of {totalPages}</span>
        <button test-id="staff-btn-next-page" disabled={page === totalPages}>
          Next
        </button>
      </div>
    </div>
  );
}
```

### Staff Create/Edit Form

```tsx
export default function StaffFormPage() {
  return (
    <div test-id="staff-form-container">
      <h1 test-id="staff-txt-form-title">{isEdit ? 'Edit' : 'Create'} Staff</h1>

      <form test-id="staff-form-main" onSubmit={handleSubmit}>
        <div test-id="staff-section-personal">
          <label test-id="staff-txt-label-name">Name</label>
          <input test-id="staff-input-name" {...register('name')} />
          <span test-id="staff-txt-error-name">{errors.name?.message}</span>

          <label test-id="staff-txt-label-email">Email</label>
          <input test-id="staff-input-email" {...register('email')} />
          <span test-id="staff-txt-error-email">{errors.email?.message}</span>
        </div>

        <div test-id="staff-section-role">
          <label test-id="staff-txt-label-role">Role</label>
          <select test-id="staff-select-role" {...register('role')}>
            <option value="admin">Admin</option>
            <option value="staff">Staff</option>
          </select>
          <span test-id="staff-txt-error-role">{errors.role?.message}</span>
        </div>

        <div test-id="staff-form-actions">
          <button test-id="staff-btn-cancel" type="button">Cancel</button>
          <button test-id="staff-btn-submit" type="submit">
            {isEdit ? 'Update' : 'Create'}
          </button>
        </div>
      </form>
    </div>
  );
}
```

### Filter Sheet/Drawer

```tsx
<Sheet test-id="staff-sheet-filter">
  <SheetTrigger test-id="staff-btn-open-filter">
    Filter
  </SheetTrigger>

  <SheetContent test-id="staff-sheet-filter-content">
    <h2 test-id="staff-txt-filter-title">Filter Staff</h2>

    <div test-id="staff-section-filter-role">
      <label test-id="staff-txt-label-filter-role">Role</label>
      <select test-id="staff-select-filter-role">
        <option value="">All</option>
        <option value="admin">Admin</option>
        <option value="staff">Staff</option>
      </select>
    </div>

    <div test-id="staff-section-filter-status">
      <label test-id="staff-txt-label-filter-status">Status</label>
      <select test-id="staff-select-filter-status">
        <option value="">All</option>
        <option value="active">Active</option>
        <option value="inactive">Inactive</option>
      </select>
    </div>

    <div test-id="staff-sheet-filter-actions">
      <button test-id="staff-btn-clear-filter">Clear</button>
      <button test-id="staff-btn-apply-filter">Apply</button>
    </div>
  </SheetContent>
</Sheet>
```

### Modal/Dialog

```tsx
<Dialog test-id="staff-modal-delete">
  <DialogContent test-id="staff-modal-delete-content">
    <h2 test-id="staff-txt-modal-title">Confirm Delete</h2>
    <p test-id="staff-txt-modal-message">
      Are you sure you want to delete {member.name}?
    </p>

    <div test-id="staff-modal-delete-actions">
      <button test-id="staff-btn-modal-cancel">Cancel</button>
      <button test-id="staff-btn-modal-confirm">Delete</button>
    </div>
  </DialogContent>
</Dialog>
```

### Card Grid Layout

```tsx
<div test-id="parcel-list-container">
  <div test-id="parcel-list-grid">
    {parcels.map((parcel) => (
      <div test-id={`parcel-card-${parcel.id}`} key={parcel.id}>
        <img test-id={`parcel-img-${parcel.id}`} src={parcel.image} />
        <h3 test-id={`parcel-txt-title-${parcel.id}`}>{parcel.title}</h3>
        <p test-id={`parcel-txt-tracking-${parcel.id}`}>{parcel.trackingNo}</p>
        <span test-id={`parcel-badge-status-${parcel.id}`}>{parcel.status}</span>

        <div test-id={`parcel-card-actions-${parcel.id}`}>
          <button test-id={`parcel-btn-view-${parcel.id}`}>View</button>
          <button test-id={`parcel-btn-deliver-${parcel.id}`}>Deliver</button>
        </div>
      </div>
    ))}
  </div>
</div>
```

### Tabs Component

```tsx
<Tabs test-id="parcel-tabs-container" defaultValue="pending">
  <TabsList test-id="parcel-tabs-list">
    <TabsTrigger test-id="parcel-tab-pending" value="pending">
      Pending
      <span test-id="parcel-badge-count-pending">{counts.pending}</span>
    </TabsTrigger>
    <TabsTrigger test-id="parcel-tab-delivered" value="delivered">
      Delivered
      <span test-id="parcel-badge-count-delivered">{counts.delivered}</span>
    </TabsTrigger>
    <TabsTrigger test-id="parcel-tab-returned" value="returned">
      Returned
      <span test-id="parcel-badge-count-returned">{counts.returned}</span>
    </TabsTrigger>
  </TabsList>

  <TabsContent test-id="parcel-tabs-content-pending" value="pending">
    {/* Pending parcels list */}
  </TabsContent>
  <TabsContent test-id="parcel-tabs-content-delivered" value="delivered">
    {/* Delivered parcels list */}
  </TabsContent>
</Tabs>
```

### Shared Components

#### Sidebar

```tsx
<nav test-id="sidebar-nav-main">
  <div test-id="sidebar-section-logo">
    <img test-id="sidebar-img-logo" src="/logo.png" />
  </div>

  <ul test-id="sidebar-list-menu">
    <li>
      <a test-id="sidebar-link-home" href="/">Home</a>
    </li>
    <li>
      <a test-id="sidebar-link-staff" href="/staff">Staff</a>
    </li>
    <li>
      <a test-id="sidebar-link-parcel" href="/parcel">Parcel</a>
    </li>
  </ul>

  <button test-id="sidebar-btn-collapse">
    {collapsed ? 'Expand' : 'Collapse'}
  </button>
</nav>
```

#### Header

```tsx
<header test-id="header-container">
  <div test-id="header-section-breadcrumb">
    <span test-id="header-txt-breadcrumb">{breadcrumb}</span>
  </div>

  <div test-id="header-section-actions">
    <button test-id="header-btn-notifications">
      <span test-id="header-badge-notification-count">{count}</span>
    </button>
    <button test-id="header-btn-language">{locale}</button>
    <div test-id="header-nav-user">
      <img test-id="header-img-user-avatar" src={user.avatar} />
      <span test-id="header-txt-username">{user.name}</span>
      <button test-id="header-btn-logout">Logout</button>
    </div>
  </div>
</header>
```

## Robot Framework Usage Examples

```robot
*** Test Cases ***
User Can Login Successfully
    Input Text    test-id:login-input-email    user@example.com
    Input Text    test-id:login-input-password    secret123
    Click Element    test-id:login-btn-submit
    Wait Until Element Is Visible    test-id:sidebar-nav-main

Verify Staff List Displays Members
    Wait Until Element Is Visible    test-id:staff-list-table
    Element Should Be Visible    test-id:staff-row-123
    Element Text Should Be    test-id:staff-cell-name-123    John Doe
    Element Text Should Be    test-id:staff-badge-status-123    Active

Edit Specific Staff Member
    Click Element    test-id:staff-btn-edit-123
    Wait Until Element Is Visible    test-id:staff-form-main
    Input Text    test-id:staff-input-name    Updated Name
    Click Element    test-id:staff-btn-submit

Filter Staff By Role
    Click Element    test-id:staff-btn-filter
    Wait Until Element Is Visible    test-id:staff-sheet-filter
    Select From List By Value    test-id:staff-select-filter-role    admin
    Click Element    test-id:staff-btn-apply-filter

Verify Empty State When No Results
    Input Text    test-id:staff-input-search    nonexistent
    Wait Until Element Is Visible    test-id:staff-list-empty
    Element Should Be Visible    test-id:staff-txt-empty

Navigate Pagination
    Click Element    test-id:staff-btn-next-page
    Element Text Should Contain    test-id:staff-txt-current-page    Page 2
```

## Summary Table

| Element | Pattern | Example |
|---------|---------|---------|
| Page container | `{page}-{type}-container` | `staff-list-container` |
| List/Table | `{page}-list-{type}` | `staff-list-table`, `parcel-list-grid` |
| Row/Card | `{page}-{row\|card}-{id}` | `staff-row-123`, `parcel-card-456` |
| Cell/Field | `{page}-cell-{field}-{id}` | `staff-cell-name-123` |
| Row action | `{page}-btn-{action}-{id}` | `staff-btn-edit-123` |
| Form input | `{page}-input-{field}` | `staff-input-email` |
| Form select | `{page}-select-{field}` | `staff-select-role` |
| Form error | `{page}-txt-error-{field}` | `staff-txt-error-email` |
| Submit button | `{page}-btn-submit` | `staff-btn-submit` |
| Empty state | `{page}-list-empty` | `staff-list-empty` |
| Loading state | `{page}-list-loading` | `staff-list-loading` |
| Pagination | `{page}-btn-{prev\|next}-page` | `staff-btn-next-page` |
| Modal | `{page}-modal-{action}` | `staff-modal-delete` |
| Sheet/Drawer | `{page}-sheet-{purpose}` | `staff-sheet-filter` |
