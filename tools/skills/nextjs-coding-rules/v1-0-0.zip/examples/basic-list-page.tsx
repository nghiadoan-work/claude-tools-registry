/**
 * Example: Complete List Page with TanStack Table
 *
 * This demonstrates a complete list page implementation following all architectural patterns:
 * - Custom hook for data fetching (TanStack Query + useState)
 * - TanStack Table for table state management
 * - Type-safe column definitions with createColumnHelper
 * - shadcn/ui components for UI
 * - Proper separation of concerns (hooks, page, UI components)
 *
 * File Location: src/app/[locale]/(app)/items/page.tsx
 */

'use client';

import React from 'react';
import {
  createColumnHelper,
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  useReactTable,
} from '@tanstack/react-table';
import { useTranslations } from 'next-intl';
import { Search, X, Plus } from 'lucide-react';

// UI Components (from shadcn/ui)
import { Button } from '@/ui/components/ui/button';
import { Input } from '@/ui/components/ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/ui/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/ui/components/ui/select';
import { Badge } from '@/ui/components/ui/badge';

// Custom Hook (would be in src/hooks/use-items.ts)
import { useItems } from '@/hooks/use-items';

// Types (would be in src/domain/entities/item.types.ts)
interface Item {
  id: string;
  name: string;
  description: string;
  status: 'active' | 'inactive' | 'pending';
  createdAt: string;
  updatedAt: string;
}

// ============================================================================
// COLUMN HELPER (Type-safe column definitions)
// ============================================================================

const columnHelper = createColumnHelper<Item>();

// ============================================================================
// PAGE COMPONENT
// ============================================================================

export default function ItemsPage() {
  const t = useTranslations('items');

  // ==========================================================================
  // DATA FETCHING (Custom Hook)
  // ==========================================================================

  const {
    data: items,
    isLoading,
    error,
    search,
    setSearch,
    status,
    setStatus,
    clearFilters,
  } = useItems();

  // ==========================================================================
  // TABLE COLUMNS (TanStack Table)
  // ==========================================================================

  /**
   * Column definitions wrapped in useMemo for performance
   * Only recreate columns if dependencies change
   */
  const columns = React.useMemo(
    () => [
      // Simple accessor column
      columnHelper.accessor('name', {
        id: 'name',
        header: () => t('table.name'),
        cell: (info) => (
          <div className="font-medium">{info.getValue()}</div>
        ),
      }),

      // Accessor with custom rendering
      columnHelper.accessor('description', {
        id: 'description',
        header: () => t('table.description'),
        cell: (info) => (
          <div className="text-sm text-muted-foreground max-w-md truncate">
            {info.getValue()}
          </div>
        ),
      }),

      // Accessor with component rendering (Badge)
      columnHelper.accessor('status', {
        id: 'status',
        header: () => t('table.status'),
        cell: (info) => {
          const status = info.getValue();
          return (
            <Badge
              variant={
                status === 'active'
                  ? 'default'
                  : status === 'inactive'
                  ? 'secondary'
                  : 'outline'
              }
            >
              {t(`status.${status}`)}
            </Badge>
          );
        },
      }),

      // Accessor with date formatting
      columnHelper.accessor('createdAt', {
        id: 'createdAt',
        header: () => t('table.createdAt'),
        cell: (info) => {
          const date = new Date(info.getValue());
          return (
            <div className="text-sm">
              {date.toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'short',
                day: 'numeric',
              })}
            </div>
          );
        },
      }),

      // Display column (actions)
      columnHelper.display({
        id: 'actions',
        header: () => t('table.actions'),
        cell: (info) => (
          <div className="flex gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => handleView(info.row.original.id)}
            >
              {t('actions.view')}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => handleEdit(info.row.original.id)}
            >
              {t('actions.edit')}
            </Button>
          </div>
        ),
      }),
    ],
    [t]
  );

  // ==========================================================================
  // TABLE INITIALIZATION (TanStack Table)
  // ==========================================================================

  const table = useReactTable({
    data: items,
    columns,
    getCoreRowModel: getCoreRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    initialState: {
      pagination: {
        pageSize: 10,
        pageIndex: 0,
      },
    },
  });

  // ==========================================================================
  // EFFECTS
  // ==========================================================================

  /**
   * Reset pagination when filters change
   * Critical for good UX - prevents empty pages
   */
  React.useEffect(() => {
    table.setPageIndex(0);
  }, [search, status, table]);

  // ==========================================================================
  // EVENT HANDLERS
  // ==========================================================================

  const handleView = (id: string) => {
    console.log('View item:', id);
    // Navigate to detail page or open modal
  };

  const handleEdit = (id: string) => {
    console.log('Edit item:', id);
    // Navigate to edit page or open modal
  };

  const handleCreate = () => {
    console.log('Create new item');
    // Navigate to create page or open modal
  };

  // ==========================================================================
  // RENDER
  // ==========================================================================

  return (
    <div className="space-y-6 p-6">
      {/* ======================================================================
          HEADER
      ====================================================================== */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">{t('title')}</h1>
          <p className="text-muted-foreground">{t('description')}</p>
        </div>
        <Button onClick={handleCreate}>
          <Plus className="mr-2 h-4 w-4" />
          {t('actions.create')}
        </Button>
      </div>

      {/* ======================================================================
          FILTERS
      ====================================================================== */}
      <div className="flex gap-4 items-center">
        {/* Search Input */}
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder={t('filters.searchPlaceholder')}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>

        {/* Status Filter */}
        <Select value={status} onValueChange={setStatus}>
          <SelectTrigger className="w-[200px]">
            <SelectValue placeholder={t('filters.statusPlaceholder')} />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{t('filters.allStatuses')}</SelectItem>
            <SelectItem value="active">{t('status.active')}</SelectItem>
            <SelectItem value="inactive">{t('status.inactive')}</SelectItem>
            <SelectItem value="pending">{t('status.pending')}</SelectItem>
          </SelectContent>
        </Select>

        {/* Clear Filters */}
        {(search || status) && (
          <Button variant="ghost" onClick={clearFilters}>
            <X className="mr-2 h-4 w-4" />
            {t('filters.clear')}
          </Button>
        )}
      </div>

      {/* ======================================================================
          TABLE
      ====================================================================== */}
      <div className="rounded-md border">
        <Table>
          {/* Table Header */}
          <TableHeader>
            {table.getHeaderGroups().map((headerGroup) => (
              <TableRow key={headerGroup.id}>
                {headerGroup.headers.map((header) => (
                  <TableHead key={header.id}>
                    {header.isPlaceholder
                      ? null
                      : flexRender(
                          header.column.columnDef.header,
                          header.getContext()
                        )}
                  </TableHead>
                ))}
              </TableRow>
            ))}
          </TableHeader>

          {/* Table Body */}
          <TableBody>
            {isLoading ? (
              <TableRow>
                <TableCell colSpan={columns.length} className="h-24 text-center">
                  {t('loading')}
                </TableCell>
              </TableRow>
            ) : error ? (
              <TableRow>
                <TableCell colSpan={columns.length} className="h-24 text-center">
                  <div className="text-destructive">{error}</div>
                </TableCell>
              </TableRow>
            ) : table.getRowModel().rows.length === 0 ? (
              <TableRow>
                <TableCell colSpan={columns.length} className="h-24 text-center">
                  {t('noResults')}
                </TableCell>
              </TableRow>
            ) : (
              table.getRowModel().rows.map((row) => (
                <TableRow
                  key={row.id}
                  data-state={row.getIsSelected() && 'selected'}
                >
                  {row.getVisibleCells().map((cell) => (
                    <TableCell key={cell.id}>
                      {flexRender(
                        cell.column.columnDef.cell,
                        cell.getContext()
                      )}
                    </TableCell>
                  ))}
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      {/* ======================================================================
          PAGINATION
      ====================================================================== */}
      <div className="flex items-center justify-between">
        {/* Results Info */}
        <div className="text-sm text-muted-foreground">
          {t('pagination.showing', {
            from: table.getState().pagination.pageIndex *
              table.getState().pagination.pageSize + 1,
            to: Math.min(
              (table.getState().pagination.pageIndex + 1) *
                table.getState().pagination.pageSize,
              items.length
            ),
            total: items.length,
          })}
        </div>

        {/* Pagination Controls */}
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => table.setPageIndex(0)}
            disabled={!table.getCanPreviousPage()}
          >
            {t('pagination.first')}
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => table.previousPage()}
            disabled={!table.getCanPreviousPage()}
          >
            {t('pagination.previous')}
          </Button>

          <div className="flex items-center gap-1">
            <span className="text-sm">
              {t('pagination.page')}{' '}
              <span className="font-medium">
                {table.getState().pagination.pageIndex + 1}
              </span>{' '}
              {t('pagination.of')}{' '}
              <span className="font-medium">{table.getPageCount()}</span>
            </span>
          </div>

          <Button
            variant="outline"
            size="sm"
            onClick={() => table.nextPage()}
            disabled={!table.getCanNextPage()}
          >
            {t('pagination.next')}
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => table.setPageIndex(table.getPageCount() - 1)}
            disabled={!table.getCanNextPage()}
          >
            {t('pagination.last')}
          </Button>
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// KEY PRINCIPLES DEMONSTRATED
// ============================================================================

/*
1. Clean Architecture
   - Custom hook (src/hooks/use-items.ts) for data fetching
   - Page component orchestrates and configures table
   - UI components (Button, Table, etc.) are presentational

2. TanStack Table
   - createColumnHelper<Item>() for type-safe columns
   - Columns wrapped in useMemo for performance
   - useReactTable manages table state
   - flexRender renders headers and cells
   - NO manual pagination calculations

3. State Management
   - TanStack Query in custom hook for server state
   - useState in custom hook for UI state (filters)
   - Table state managed by useReactTable
   - Pagination reset when filters change

4. Internationalization
   - useTranslations('items') for scoped translations
   - All user-facing text from translation keys
   - ICU format for dynamic values in pagination

5. Type Safety
   - Explicit types for Item interface
   - Type inference from createColumnHelper
   - No type casts needed

6. shadcn/ui Components
   - Token-based theming (text-muted-foreground, etc.)
   - Consistent component usage
   - Accessible by default

7. UX Best Practices
   - Loading states
   - Error states
   - Empty states
   - Clear filters button
   - Pagination reset on filter change
   - Responsive design
*/
