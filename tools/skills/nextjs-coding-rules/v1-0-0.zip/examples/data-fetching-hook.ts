/**
 * Example: Custom Hook with TanStack Query + useState
 *
 * This demonstrates the complete pattern for data fetching in the Residence Backoffice.
 *
 * Key Features:
 * - Explicit return type interface (UseItemsResult)
 * - TanStack Query for server state
 * - useState for UI state (filters, pagination)
 * - Axios client for HTTP requests
 * - Automatic pagination reset when filters change
 * - Cache invalidation with queryClient
 */

'use client';

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiClient } from '@/lib/api/client';

// ============================================================================
// TYPES
// ============================================================================

interface Item {
  id: string;
  name: string;
  status: 'active' | 'inactive' | 'pending';
  createdAt: string;
}

interface ListItemsParams {
  page: number;
  pageSize: number;
  search?: string;
  status?: string;
}

interface ListItemsResponse {
  data: Item[];
  meta: {
    total: number;
    page: number;
    pageSize: number;
  };
}

// ============================================================================
// HOOK RETURN TYPE (EXPLICIT - REQUIRED)
// ============================================================================

/**
 * Explicit return type interface ensures proper type inference
 * without needing type casts in consuming components
 */
interface UseItemsResult {
  // Server state (from React Query)
  data: Item[];
  total: number;
  isLoading: boolean;
  error: string | null;

  // UI state
  page: number;
  pageSize: number;
  search: string;
  status: string | undefined;

  // UI state setters
  setPage: (page: number) => void;
  setPageSize: (pageSize: number) => void;
  setSearch: (search: string) => void;
  setStatus: (status?: string) => void;

  // Actions
  refresh: () => void;
  clearFilters: () => void;
}

// ============================================================================
// API FUNCTION
// ============================================================================

/**
 * Separate API function for better organization and testability
 */
async function fetchItems(params: ListItemsParams): Promise<ListItemsResponse> {
  const queryParams = new URLSearchParams();
  queryParams.set('page', params.page.toString());
  queryParams.set('pageSize', params.pageSize.toString());

  if (params.search) {
    queryParams.set('search', params.search);
  }

  if (params.status) {
    queryParams.set('status', params.status);
  }

  const response = await apiClient.get<ListItemsResponse>(
    `/items?${queryParams.toString()}`
  );

  return response.data;
}

// ============================================================================
// CUSTOM HOOK
// ============================================================================

/**
 * Custom hook for items list with filtering and pagination
 *
 * @param options - Optional initial values for state
 * @returns {UseItemsResult} - Data, state, and actions
 */
export function useItems(options?: {
  initialPage?: number;
  initialPageSize?: number;
  initialSearch?: string;
  initialStatus?: string;
}): UseItemsResult {
  // ============================================================================
  // UI STATE (useState)
  // ============================================================================

  const [page, setPage] = useState(options?.initialPage ?? 1);
  const [pageSize, setPageSize] = useState(options?.initialPageSize ?? 20);
  const [search, setSearch] = useState(options?.initialSearch ?? '');
  const [status, setStatus] = useState<string | undefined>(options?.initialStatus);

  // ============================================================================
  // SERVER STATE (TanStack Query)
  // ============================================================================

  const queryResult = useQuery({
    // Query key includes all parameters that affect the query
    queryKey: ['items', { page, pageSize, search, status }],

    // Query function fetches data
    queryFn: () => fetchItems({ page, pageSize, search, status }),

    // Optional: Configure caching behavior
    staleTime: 60 * 1000, // 1 minute
    gcTime: 10 * 60 * 1000, // 10 minutes
  });

  // ============================================================================
  // RETURN INTERFACE (EXPLICIT TYPE)
  // ============================================================================

  return {
    // Server state
    data: queryResult.data?.data ?? [],
    total: queryResult.data?.meta.total ?? 0,
    isLoading: queryResult.isLoading,
    error: queryResult.error?.message ?? null,

    // UI state
    page,
    pageSize,
    search,
    status,

    // UI state setters (with side effects)
    setPage: (newPage: number) => {
      setPage(newPage);
    },

    setPageSize: (newPageSize: number) => {
      setPageSize(newPageSize);
      setPage(1); // Reset to page 1 when changing page size
    },

    setSearch: (newSearch: string) => {
      setSearch(newSearch);
      setPage(1); // Reset to page 1 when searching
    },

    setStatus: (newStatus?: string) => {
      setStatus(newStatus);
      setPage(1); // Reset to page 1 when filtering
    },

    // Actions
    refresh: () => {
      queryResult.refetch();
    },

    clearFilters: () => {
      setSearch('');
      setStatus(undefined);
      setPage(1);
    },
  };
}

// ============================================================================
// MUTATION EXAMPLE (for create/update/delete)
// ============================================================================

interface UseCreateItemResult {
  createItem: (data: Partial<Item>) => Promise<Item>;
  isCreating: boolean;
  error: string | null;
}

export function useCreateItem(): UseCreateItemResult {
  const queryClient = useQueryClient();

  const mutation = useMutation({
    mutationFn: async (data: Partial<Item>) => {
      const response = await apiClient.post<{ data: Item }>('/items', data);
      return response.data.data;
    },

    onSuccess: () => {
      // Invalidate and refetch items list
      queryClient.invalidateQueries({ queryKey: ['items'] });
    },
  });

  return {
    createItem: (data: Partial<Item>) => mutation.mutateAsync(data),
    isCreating: mutation.isPending,
    error: mutation.error?.message ?? null,
  };
}

// ============================================================================
// USAGE EXAMPLE IN PAGE COMPONENT
// ============================================================================

/*
'use client';

import { useItems } from '@/hooks/use-items';
import { ItemTable } from '@/ui/items/item-table';
import { ItemFilters } from '@/ui/items/item-filters';

export default function ItemsPage() {
  // Hook encapsulates ALL state and data fetching
  const {
    data: items,
    isLoading,
    error,
    search,
    setSearch,
    status,
    setStatus,
    clearFilters,
  } = useItems();

  return (
    <div>
      <ItemFilters
        search={search}
        onSearchChange={setSearch}
        status={status}
        onStatusChange={setStatus}
        onClearFilters={clearFilters}
      />

      <ItemTable
        items={items}
        isLoading={isLoading}
        error={error}
      />
    </div>
  );
}
*/
