/**
 * Example: API Route as Composition Root
 *
 * This demonstrates the manual dependency injection pattern for Next.js API routes.
 *
 * Key Features:
 * - Manual dependency composition (Composition Root pattern)
 * - Repository instantiation and injection into use cases
 * - Input validation with Zod
 * - Structured JSON responses
 * - Error handling with user-friendly messages
 * - Per-request dependency instantiation (no singletons)
 */

import { NextRequest } from 'next/server';
import { z } from 'zod';

// ============================================================================
// DOMAIN LAYER (would be in src/domain/)
// ============================================================================

// Types
interface Item {
  id: string;
  name: string;
  status: 'active' | 'inactive' | 'pending';
  createdAt: string;
}

interface ListItemsParams {
  page: number;
  pageSize: number;
  search?: string;
  status?: string;
}

interface ListItemsResult {
  data: Item[];
  total: number;
  page: number;
  pageSize: number;
}

// Repository interface (defines contract)
interface ItemsRepository {
  list(params: ListItemsParams): Promise<ListItemsResult>;
  findById(id: string): Promise<Item | null>;
  create(data: Partial<Item>): Promise<Item>;
  update(id: string, data: Partial<Item>): Promise<Item>;
  delete(id: string): Promise<void>;
}

// Use Case
class ListItemsUseCase {
  constructor(private repository: ItemsRepository) {}

  async execute(params: ListItemsParams): Promise<ListItemsResult> {
    // Business logic goes here
    // Validation, authorization, business rules, etc.

    return this.repository.list(params);
  }
}

class CreateItemUseCase {
  constructor(private repository: ItemsRepository) {}

  async execute(data: Partial<Item>): Promise<Item> {
    // Business logic and validation

    return this.repository.create(data);
  }
}

// ============================================================================
// INFRASTRUCTURE LAYER (would be in src/infrastructure/)
// ============================================================================

class ItemsHttpRepository implements ItemsRepository {
  constructor(private ctx: any) {
    // ctx would contain auth tokens, locale, etc.
  }

  async list(params: ListItemsParams): Promise<ListItemsResult> {
    // Make HTTP request to upstream API
    // This is just a mock for example purposes
    return {
      data: [],
      total: 0,
      page: params.page,
      pageSize: params.pageSize,
    };
  }

  async findById(id: string): Promise<Item | null> {
    // Implementation
    return null;
  }

  async create(data: Partial<Item>): Promise<Item> {
    // Implementation
    return data as Item;
  }

  async update(id: string, data: Partial<Item>): Promise<Item> {
    // Implementation
    return data as Item;
  }

  async delete(id: string): Promise<void> {
    // Implementation
  }
}

// ============================================================================
// VALIDATION SCHEMAS (Zod)
// ============================================================================

const listItemsParamsSchema = z.object({
  page: z.number().min(1).default(1),
  pageSize: z.number().min(1).max(100).default(20),
  search: z.string().optional(),
  status: z.enum(['active', 'inactive', 'pending']).optional(),
});

const createItemSchema = z.object({
  name: z.string().min(1, 'Name is required'),
  status: z.enum(['active', 'inactive', 'pending']).default('active'),
});

// ============================================================================
// API ROUTE HANDLER (GET)
// ============================================================================

/**
 * GET /api/items - List items with filtering and pagination
 *
 * Query Parameters:
 * - page: number (default: 1)
 * - pageSize: number (default: 20, max: 100)
 * - search: string (optional)
 * - status: 'active' | 'inactive' | 'pending' (optional)
 */
export async function GET(req: NextRequest) {
  try {
    // ========================================================================
    // 1. PARSE AND VALIDATE INPUT
    // ========================================================================

    const { searchParams } = new URL(req.url);

    const rawParams = {
      page: Number(searchParams.get('page') || '1'),
      pageSize: Number(searchParams.get('pageSize') || '20'),
      search: searchParams.get('search') || undefined,
      status: searchParams.get('status') || undefined,
    };

    // Validate with Zod
    const validationResult = listItemsParamsSchema.safeParse(rawParams);

    if (!validationResult.success) {
      return Response.json(
        {
          error: {
            message: 'Invalid parameters',
            details: validationResult.error.flatten().fieldErrors,
          },
        },
        { status: 400 }
      );
    }

    const params = validationResult.data;

    // ========================================================================
    // 2. COMPOSITION ROOT - Instantiate dependencies
    // ========================================================================

    // Get context (auth, locale, etc.)
    // const ctx = await getContext(req);
    const ctx = {}; // Mock for example

    // Instantiate repository
    const repository = new ItemsHttpRepository(ctx);

    // Inject repository into use case
    const useCase = new ListItemsUseCase(repository);

    // ========================================================================
    // 3. EXECUTE USE CASE
    // ========================================================================

    const result = await useCase.execute(params);

    // ========================================================================
    // 4. RETURN STRUCTURED RESPONSE
    // ========================================================================

    return Response.json({
      data: result.data,
      meta: {
        total: result.total,
        page: result.page,
        pageSize: result.pageSize,
        totalPages: Math.ceil(result.total / result.pageSize),
      },
    });

  } catch (error: any) {
    // ========================================================================
    // 5. ERROR HANDLING
    // ========================================================================

    console.error('API Error:', error);

    // Determine status code
    const status = error.status || error.statusCode || 500;

    // Return user-friendly error
    return Response.json(
      {
        error: {
          message: error.message || 'Failed to fetch items',
          code: error.code,
        },
      },
      { status }
    );
  }
}

// ============================================================================
// API ROUTE HANDLER (POST)
// ============================================================================

/**
 * POST /api/items - Create a new item
 *
 * Request Body:
 * - name: string (required)
 * - status: 'active' | 'inactive' | 'pending' (default: 'active')
 */
export async function POST(req: NextRequest) {
  try {
    // ========================================================================
    // 1. PARSE AND VALIDATE INPUT
    // ========================================================================

    const body = await req.json();

    const validationResult = createItemSchema.safeParse(body);

    if (!validationResult.success) {
      return Response.json(
        {
          error: {
            message: 'Invalid input',
            fieldErrors: validationResult.error.flatten().fieldErrors,
          },
        },
        { status: 400 }
      );
    }

    const data = validationResult.data;

    // ========================================================================
    // 2. COMPOSITION ROOT
    // ========================================================================

    const ctx = {}; // Mock for example
    const repository = new ItemsHttpRepository(ctx);
    const useCase = new CreateItemUseCase(repository);

    // ========================================================================
    // 3. EXECUTE USE CASE
    // ========================================================================

    const result = await useCase.execute(data);

    // ========================================================================
    // 4. RETURN STRUCTURED RESPONSE (201 Created)
    // ========================================================================

    return Response.json(
      { data: result },
      { status: 201 }
    );

  } catch (error: any) {
    console.error('API Error:', error);

    const status = error.status || error.statusCode || 500;

    return Response.json(
      {
        error: {
          message: error.message || 'Failed to create item',
          code: error.code,
        },
      },
      { status }
    );
  }
}

// ============================================================================
// API ROUTE HANDLER (PUT)
// ============================================================================

/**
 * PUT /api/items/[id] - Update an existing item
 *
 * Dynamic route example: app/api/items/[id]/route.ts
 */
export async function PUT(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const id = params.id;
    const body = await req.json();

    // Validate...
    // Instantiate dependencies...
    // Execute use case...

    return Response.json({ data: { id, ...body } });

  } catch (error: any) {
    console.error('API Error:', error);

    return Response.json(
      { error: { message: error.message || 'Failed to update item' } },
      { status: error.status || 500 }
    );
  }
}

// ============================================================================
// KEY PRINCIPLES
// ============================================================================

/*
1. API Route = Composition Root
   - Instantiate repositories
   - Inject into use cases
   - No global/singleton dependencies

2. Manual Dependency Injection
   - Clear dependency graph
   - Easy to test
   - Per-request composition

3. Structured Responses
   - Success: { data, meta }
   - Error: { error: { message, code, fieldErrors } }
   - Consistent HTTP status codes

4. Input Validation
   - Validate with Zod schemas
   - Return 400 for invalid input
   - Include field-level errors

5. Error Handling
   - Catch all errors
   - Log for debugging
   - Return user-friendly messages
   - Don't expose internal errors

6. Use Cases Contain Business Logic
   - API routes are thin
   - Logic belongs in domain layer
   - API route = orchestration only
*/
