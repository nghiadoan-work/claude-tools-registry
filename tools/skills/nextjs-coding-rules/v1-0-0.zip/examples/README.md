# Next.js Coding Rules Examples

This directory contains working code examples demonstrating the architectural patterns and coding standards for the Residence Backoffice Next.js application.

## Examples Index

- **data-fetching-hook.ts** - Complete custom hook pattern with TanStack Query + useState
- **api-route-pattern.ts** - API route as composition root with dependency injection
- **form-with-validation.tsx** - React Hook Form + Zod + Server Action pattern
- **table-with-pagination.tsx** - TanStack Table with type-safe columns and pagination
- **basic-list-page.tsx** - Complete list page with hook, table, and filters

## Pattern Overview

### Data Flow
```
UI Component → Custom Hook (TanStack Query + useState) → API Route → Use Case → Repository
```

### Layer Responsibilities
- **Hooks**: Data fetching (React Query) + UI state (useState)
- **Pages**: Table configuration + column definitions + data orchestration
- **UI Components**: Presentational only, receive data via props
- **API Routes**: Dependency composition + use case execution

## Key Principles

1. **Custom Hooks for Data**: ALL state and data-fetching logic must be in custom hooks
2. **Explicit Return Types**: Define `UseFeatureResult` interface for all hooks
3. **TanStack Table for Tables**: Use `createColumnHelper<T>()` and `useReactTable`, no manual pagination
4. **Props-Only UI Components**: UI components receive data via props, never use React Query
5. **Single Zod Schema**: Same schema for client validation (React Hook Form) and server validation (Server Actions)

## Running Examples

These are TypeScript code examples meant for reference. To see them in action:

1. Review the pattern in the example file
2. Adapt the pattern to your feature requirements
3. Follow the coding rules in `command-center/coding-rules/`
4. Verify with `pnpm type-check` and `pnpm lint`

## Related Documentation

- `../SKILL.md` - Complete skill documentation
- `/command-center/coding-rules/` - Detailed coding rules
- `/CLAUDE.md` - Constitutional principles
