---
name: nextjs-coding-rules
description: Next.js 15 Clean Architecture patterns with TanStack Query, React Hook Form, shadcn/ui, and constitutional compliance for Residence Backoffice
---

# Next.js Coding Rules - Residence Backoffice

Architectural patterns and coding standards for building Next.js 15 applications following Clean Architecture, TanStack Query state management, and constitutional principles.

## Quick Start

This skill provides the complete architectural blueprint for the Residence Backoffice Next.js application.

Use this skill when you need to:
- Implement features following Clean Architecture (Domain, Infrastructure, Hooks, UI layers)
- Build data-fetching hooks with TanStack Query + useState patterns
- Create forms with React Hook Form + Zod + Server Actions
- Implement tables with TanStack Table and pagination
- Follow naming conventions, i18n patterns, and security best practices
- Ensure constitutional compliance across all 14 core principles

**Quick Example:**
See `./examples/basic-list-page.tsx` for a complete list page with custom hook, table, and filters.

**Detailed Reference:**
All detailed documentation is in `./reference/` - start with `./reference/00-INDEX.md`

## Implementation Workflow

### Step 1: Understand the Layer Architecture
Review `./reference/03-clean-architecture.md` for the four-layer architecture:
- **Domain Layer**: Pure business logic (framework-agnostic)
- **Infrastructure Layer**: Repositories, external services
- **Hooks Layer**: TanStack Query + useState
- **UI Layer**: Pages and presentational components

**Dependency Rule**: UI → Hooks → Infrastructure → Domain (dependencies flow inward only)

### Step 2: Implement Data Fetching Pattern
See `./reference/05-state-management.md` and `./examples/data-fetching-hook.ts`:
1. Create custom hook with explicit return type interface
2. Use TanStack Query for server state
3. Use `useState` for UI state
4. Call API routes via Axios client
5. Return all state and callbacks

### Step 3: Build UI Components
See `./reference/01-project-structure.md` and `./examples/basic-list-page.tsx`:
- **Pages**: Call hooks, configure tables, pass props to UI components
- **UI Components**: Receive data via props, no data fetching

### Step 4: Implement Forms
See `./reference/09-forms.md` and `./examples/form-with-validation.tsx`:
1. Define Zod schema (single source of truth)
2. Use React Hook Form with `zodResolver`
3. Create Server Action with server-side validation
4. Return structured responses: `{ ok, data }` or `{ ok: false, fieldErrors }`

### Step 5: Implement Tables
See `./reference/14-tables-pagination.md` and `./examples/table-with-pagination.tsx`:
1. Create data hook with explicit return type
2. Use `createColumnHelper<T>()` for columns
3. Initialize with `useReactTable`
4. Render with `flexRender` + shadcn/ui
5. Reset pagination when filters change

### Step 6: Add Internationalization
See `./reference/04-routing-i18n.md`:
1. Create translation files in `messages/[locale]/`
2. Register namespace in `src/lib/i18n/request.ts`
3. Use `useTranslations('namespace')` in client components
4. Use `getTranslations('namespace')` in server components

### Step 7: Validate and Test
See `./reference/11-testing.md`:
1. Run `pnpm type-check`
2. Run `pnpm lint`
3. Test Domain and Infrastructure layers (NOT UI)
4. Verify constitutional compliance

## Knowledge Areas

For detailed documentation, see `./reference/` folder (start with `00-INDEX.md`).

- **Clean Architecture**: Four-layer separation, dependency rule, data flow (`03-clean-architecture.md`)
- **Project Structure**: Directory organization, file naming conventions (`01-project-structure.md`)
- **State Management**: TanStack Query for server state, useState for UI state (`05-state-management.md`)
- **Data Fetching**: React Query + Axios patterns, API routes as composition roots (`07-server-networking.md`)
- **Forms**: React Hook Form + Zod integration, Server Actions (`09-forms.md`)
- **Tables & Pagination**: TanStack Table state management, column definitions (`14-tables-pagination.md`)
- **Routing & i18n**: Locale-prefixed routes, translation patterns (`04-routing-i18n.md`)
- **Naming Conventions**: KEBAB_CASE files, PascalCase types, camelCase functions (`10-naming-conventions.md`)
- **Security**: Environment validation, input sanitization, Keycloak SSO (`12-security-environment.md`)
- **UI & Theming**: Token-based design system, shadcn/ui components (`13-ui-theming-shadcn.md`)
- **Dependency Injection**: Manual injection in API routes, composition root (`06-dependency-injection.md`)
- **Caching**: TanStack Query configuration, cache invalidation (`08-caching.md`)
- **Testing**: Layer-specific testing strategies (`11-testing.md`)
- **Tech Stack**: Approved libraries and forbidden dependencies (`02-tech-stack.md`)

## Best Practices

1. **Always Use Custom Hooks for Data**: Encapsulate ALL state and data-fetching logic in custom hooks. Never use `useState`/`useEffect` directly in page components.

2. **Explicit Return Type Interfaces**: Define `UseFeatureResult` interface for all hooks to enable proper type inference without casts.

3. **Single Source of Truth for Validation**: Use same Zod schema on client (React Hook Form) and server (Server Actions).

4. **Layer Boundary Enforcement**: Domain MUST NOT import from Infrastructure/Hooks/UI. UI MUST NOT import from Domain/Infrastructure.

5. **Structured API Responses**: `{ data, meta }` for success, `{ error: { message, field } }` for failures.

6. **Proper Query Keys**: `['feature-name', params]` including ALL parameters that affect the query.

7. **TanStack Table for All Tables**: Use `createColumnHelper<T>()`, `useReactTable`, and shadcn/ui. NO manual pagination.

8. **Register Translation Namespaces**: Import and register all translation files in `src/lib/i18n/request.ts`.

9. **Token-Based Theming Only**: Use semantic CSS variables (`bg-primary`, `text-muted-foreground`). NO hardcoded colors.

10. **Security-First Forms**: ALWAYS re-validate Server Action inputs with Zod, even if client-validated.

## Patterns

### Pattern 1: Custom Hook with TanStack Query

Complete data-fetching hook with server state + UI state.

**Implementation:**
See `./examples/data-fetching-hook.ts` and `./reference/05-state-management.md`

```typescript
// src/hooks/use-items.ts
'use client';
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { apiClient } from '@/lib/api/client';

interface UseItemsResult {
  data: Item[];
  isLoading: boolean;
  search: string;
  setSearch: (value: string) => void;
}

export function useItems(): UseItemsResult {
  const [search, setSearch] = useState('');

  const { data, isLoading } = useQuery({
    queryKey: ['items', { search }],
    queryFn: () => apiClient.get('/items', { params: { search } }),
  });

  return {
    data: data?.data ?? [],
    isLoading,
    search,
    setSearch,
  };
}
```

---

### Pattern 2: API Route as Composition Root

Manual dependency injection in Next.js API routes.

**Implementation:**
See `./examples/api-route-pattern.ts` and `./reference/06-dependency-injection.md`

```typescript
// app/api/items/route.ts
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);

  // Composition Root: Instantiate dependencies
  const repository = new ItemsRepository(ctx);
  const useCase = new ListItemsUseCase(repository);

  const result = await useCase.execute(params);
  return Response.json({ data: result.data, meta: result.meta });
}
```

---

### Pattern 3: Form with React Hook Form + Zod

Client and server validation with Server Actions.

**Implementation:**
See `./examples/form-with-validation.tsx` and `./reference/09-forms.md`

```typescript
// 1. Zod schema (single source of truth)
const schema = z.object({
  name: z.string().min(1),
  email: z.string().email(),
});

// 2. Server Action with validation
'use server';
export async function createAction(formData: FormData) {
  const result = schema.safeParse(Object.fromEntries(formData));
  if (!result.success) {
    return { ok: false, fieldErrors: result.error.flatten().fieldErrors };
  }
  // Business logic...
  return { ok: true, data: result.data };
}

// 3. Form component
const form = useForm({ resolver: zodResolver(schema) });
```

---

### Pattern 4: TanStack Table with Pagination

Type-safe columns and pagination management.

**Implementation:**
See `./examples/table-with-pagination.tsx` and `./reference/14-tables-pagination.md`

```typescript
const columnHelper = createColumnHelper<Item>();

const columns = React.useMemo(() => [
  columnHelper.accessor('name', {
    header: () => 'Name',
    cell: (info) => info.getValue(),
  }),
], []);

const table = useReactTable({
  data: items,
  columns,
  getCoreRowModel: getCoreRowModel(),
  getPaginationRowModel: getPaginationRowModel(),
});
```

## Common Pitfalls

- **Using React Query in UI Components**: React Query hooks MUST only be used in custom hooks → Receive data via props instead

- **Manual Pagination State**: Don't use `useState` for `currentPage` and `.slice()` → Use TanStack Table's `useReactTable`

- **Missing Explicit Return Types**: Hooks without explicit return type interfaces require casts → Define `UseFeatureResult` interface

- **Forgetting i18n Namespace Registration**: New translation files not registered cause `MISSING_MESSAGE` → Register in `src/lib/i18n/request.ts`

- **Client-Only Validation**: Trusting client-side validation is a security risk → ALWAYS re-validate in Server Actions

- **Hardcoded Colors**: Using `bg-blue-500` violates token-based theming → Use semantic classes from `globals.css`

- **Direct `fetch` in Hooks**: Bypasses error handling and interceptors → Use Axios client from `@/lib/api/client`

- **Layer Boundary Violations**: Importing UI in Domain or repositories from client → Respect dependency rule

- **Incorrect Translation Scopes**: Using `t("namespace.key")` when already scoped → Use `t("key")` with scoped hook

- **Forgetting Pagination Reset**: Not resetting on filter changes causes empty pages → Add `useEffect` to reset `table.setPageIndex(0)`

- **Using Context for Server State**: Creating Context for API data → Use React Query, Context only for rare global UI state

- **Missing Query Key Dependencies**: Not including filters in `queryKey` breaks cache → Include ALL query parameters

## Resources

### Detailed Reference Documentation
Start here: **`./reference/00-INDEX.md`** - Complete index of all reference docs

Key references:
- `./reference/03-clean-architecture.md` - Architecture layers and data flow
- `./reference/05-state-management.md` - TanStack Query patterns with examples
- `./reference/14-tables-pagination.md` - TanStack Table implementation guide
- `./reference/09-forms.md` - Form validation patterns
- `./reference/EXAMPLES.md` - Architecture examples with code

### Working Code Examples
- `./examples/data-fetching-hook.ts` - Complete custom hook pattern
- `./examples/api-route-pattern.ts` - API route with dependency injection
- `./examples/basic-list-page.tsx` - Full list page with table and filters
- `./examples/form-with-validation.tsx` - Form with Zod + Server Action (referenced in SKILL.md)

### Official Documentation
- [Next.js 15 App Router](https://nextjs.org/docs) - Framework documentation
- [TanStack Query](https://tanstack.com/query/latest) - React Query documentation
- [TanStack Table](https://tanstack.com/table/latest) - Table state management
- [React Hook Form](https://react-hook-form.com/) - Form library
- [Zod](https://zod.dev/) - Schema validation
- [shadcn/ui](https://ui.shadcn.com/) - Component library
- [next-intl](https://next-intl-docs.vercel.app/) - Internationalization

### Project Files
- `/CLAUDE.md` - Constitutional principles (14 core principles)
- `/command-center/coding-rules/` - Original coding rules documentation

### Related Skills
- `task-check-list-worker` - Execute implementation checklists systematically
- `pr-code-review` - Review code for constitutional compliance
- `nextjs-developer` - Build Next.js features with Clean Architecture
