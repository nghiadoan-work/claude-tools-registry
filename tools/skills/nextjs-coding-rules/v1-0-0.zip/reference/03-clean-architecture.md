# 03 — Clean Architecture

This document defines the project's implementation of a client-centric architecture. The goal is to separate concerns, with the UI layer driving the application's data requests.

## Data Request Flow

The flow of control for a data request starts at the UI and flows down to the domain.

`UI Component` → `Custom Hook (useState/useEffect)` → `API Route` → `Use Case` → `Repository`

## Layer Guide

### 1. UI Layer (`src/app` and `src/ui`)
*The user-facing part of the application.*

#### Page Components (`src/app/**/page.tsx`)
*Orchestrate state and coordinate child components.*

##### ✅ Do
-   Create custom hooks (in `src/hooks/`) to encapsulate ALL state and data fetching for the page.
-   Call these hooks in the page component and pass data/callbacks down to UI components as props.
-   Keep page components simple - they should compose UI components and manage data flow.

##### ❌ Don't
-   Do NOT use `useState`/`useEffect` directly - create custom hooks instead.
-   Do NOT allow child UI components to make API calls.

#### UI Components (`src/ui/**`)
*Presentational components that receive data via props.*

##### ✅ Do
-   Accept ALL data and callbacks via props from parent components.
-   Use `useState` ONLY for internal UI state (e.g., modal open/close, input focus, dropdown open).
-   Design components to be reusable and testable in isolation.

##### ❌ Don't
-   Do NOT import or use React Query hooks (`useQuery`, `useMutation`).
-   Do NOT make API calls or fetch data - receive all data via props.
-   Do NOT manage business logic or page-level state.

### 2. Hooks Layer (`src/hooks`)
*The client-side hub for state and data fetching orchestration.*

#### ✅ Do
-   Create custom hooks (`useFeature.ts`) to encapsulate all state and logic for a feature.
-   Use `useState` to manage state variables (e.g., `page`, `data`, `status`).
-   Use `useEffect` to trigger API calls to Next.js API Routes when state variables change.
-   Expose state values and setter functions for the UI component to consume.

### 3. Domain Layer (`src/domain`)
*The core business logic of the application.*

#### ✅ Do
-   Define core business entities and validation schemas (`*.entity.ts` or `*.types.ts`).
-   Encapsulate business operations in use cases (`*.usecase.ts`).
-   A use case can orchestrate logic and call a repository to get the data it needs.

#### ❌ Don't
-   Do not handle UI concerns or framework-specific code.

### 4. Infrastructure/Data Layer (`src/infrastructure`)
*The concrete implementation of data access.*

#### ✅ Do
-   Implement repositories that interact directly with a database or external API.
-   Define repository interfaces that the use cases will depend on.
-   In API Routes, manually instantiate the repository and inject it into the use case.

#### ❌ Don't
-   Do not contain business logic. Its only job is to fetch and store raw data.
