# Tables and Pagination

## Overview

All tables with pagination in this project MUST use TanStack Table (`@tanstack/react-table`) for state management. Manual pagination logic is forbidden.

## Required Package

```json
{
  "@tanstack/react-table": "^8.21.3"
}
```

## Architecture Pattern

### Layer Responsibilities

**Hooks Layer** (`@/hooks/*`):
- Data fetching via TanStack Query
- Server-side filtering (query parameters to API)
- Explicit return type interfaces
- NO table rendering logic

**UI Layer** (`@/app/*`):
- TanStack Table configuration
- Column definitions with `createColumnHelper`
- Table state management (`useReactTable`)
- Rendering with shadcn/ui Table components

## Implementation Pattern

### 1. Hook: Data Fetching with Explicit Types

```typescript
// src/hooks/use-items.ts
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import type { Item } from "@/domain/entities/item.types";

// ✅ REQUIRED: Explicit return type interface
interface UseItemsResult {
  data: Item[];
  search: string;
  status: string | undefined;
  isLoading: boolean;
  error: string | null;
  setSearch: (value: string) => void;
  setStatus: (value?: string) => void;
  clearFilters: () => void;
}

export function useItems(): UseItemsResult {
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState<string | undefined>();

  const queryResult = useQuery({
    queryKey: ["items", { search, status }],
    queryFn: () => fetchItems({ search, status }),
  });

  return {
    data: queryResult.data?.data ?? [],
    search,
    status,
    isLoading: queryResult.isLoading,
    error: queryResult.error?.message ?? null,
    setSearch,
    setStatus,
    clearFilters: () => {
      setSearch("");
      setStatus(undefined);
    },
  };
}
```

### 2. Page Component: TanStack Table Configuration

```typescript
// src/app/[locale]/(app)/items/page.tsx
"use client";

import {
  createColumnHelper,
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  useReactTable,
} from "@tanstack/react-table";
import React from "react";
import type { Item } from "@/domain/entities/item.types";
import { useItems } from "@/hooks/use-items";

// ✅ Create column helper with type safety
const columnHelper = createColumnHelper<Item>();

export default function ItemsPage() {
  const { data: items, isLoading, search, setSearch, clearFilters } = useItems();

  // ✅ Define columns with useMemo for performance
  const columns = React.useMemo(
    () => [
      columnHelper.accessor("name", {
        id: "name",
        header: () => "Name",
        cell: (info) => info.getValue(),
      }),
      columnHelper.accessor("status", {
        id: "status",
        header: () => "Status",
        cell: (info) => <StatusBadge status={info.getValue()} />,
      }),
      columnHelper.display({
        id: "actions",
        header: () => "Actions",
        cell: (info) => (
          <Button onClick={() => handleAction(info.row.original.id)}>
            View
          </Button>
        ),
      }),
    ],
    []
  );

  // ✅ Initialize TanStack Table
  const table = useReactTable({
    data: items,
    columns,
    getCoreRowModel: getCoreRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    initialState: {
      pagination: {
        pageSize: 10,
        pageIndex: 0,
      },
    },
  });

  // ✅ Reset pagination when filters change
  React.useEffect(() => {
    table.setPageIndex(0);
  }, [search, table]);

  return (
    <div>
      {/* Filters */}
      <Input value={search} onChange={(e) => setSearch(e.target.value)} />
      <Button onClick={clearFilters}>Clear Filters</Button>

      {/* Table */}
      <Table>
        <TableHeader>
          {table.getHeaderGroups().map((headerGroup) => (
            <TableRow key={headerGroup.id}>
              {headerGroup.headers.map((header) => (
                <TableHead key={header.id}>
                  {flexRender(header.column.columnDef.header, header.getContext())}
                </TableHead>
              ))}
            </TableRow>
          ))}
        </TableHeader>
        <TableBody>
          {table.getRowModel().rows.map((row) => (
            <TableRow key={row.id}>
              {row.getVisibleCells().map((cell) => (
                <TableCell key={cell.id}>
                  {flexRender(cell.column.columnDef.cell, cell.getContext())}
                </TableCell>
              ))}
            </TableRow>
          ))}
        </TableBody>
      </Table>

      {/* Pagination */}
      <Pagination
        currentPage={table.getState().pagination.pageIndex + 1}
        totalPages={table.getPageCount()}
        totalItems={items.length}
        pageSize={table.getState().pagination.pageSize}
        onPageChange={(page) => table.setPageIndex(page - 1)}
      />
    </div>
  );
}
```

## Rules and Requirements

### ✅ REQUIRED

1. **Use TanStack Table for all paginated tables**
   - No manual pagination calculations
   - No manual slice/filter logic

2. **Explicit return type interfaces for hooks**
   ```typescript
   // ✅ CORRECT
   export function useItems(): UseItemsResult { ... }

   // ❌ WRONG
   export function useItems() { ... }
   ```

3. **Type-safe column definitions**
   ```typescript
   const columnHelper = createColumnHelper<ItemType>();
   ```

4. **Wrap columns in useMemo**
   ```typescript
   const columns = React.useMemo(() => [...], [dependencies]);
   ```

5. **Use shadcn/ui Table components**
   - `Table`, `TableHeader`, `TableBody`, `TableRow`, `TableHead`, `TableCell`
   - TanStack Table handles state, shadcn/ui handles styling

6. **Reset pagination on filter changes**
   ```typescript
   React.useEffect(() => {
     table.setPageIndex(0);
   }, [search, status, table]);
   ```

### ❌ FORBIDDEN

1. **Manual pagination state**
   ```typescript
   // ❌ WRONG
   const [currentPage, setCurrentPage] = useState(1);
   const [pageSize] = useState(10);
   ```

2. **Manual pagination calculations**
   ```typescript
   // ❌ WRONG
   const startIndex = (currentPage - 1) * pageSize;
   const endIndex = startIndex + pageSize;
   const paginatedItems = items.slice(startIndex, endIndex);
   ```

3. **Type casts for well-typed data**
   ```typescript
   // ❌ WRONG
   setStatus(item.status as StatusType);

   // ✅ CORRECT (with explicit return types)
   setStatus(item.status);
   ```

4. **Table configuration in hooks**
   - Column definitions belong in UI layer, not hooks layer
   - Hooks should only handle data fetching

## Column Definition Patterns

### Accessor Columns

```typescript
// Simple accessor
columnHelper.accessor("fieldName", {
  id: "fieldName",
  header: () => t("table.fieldName"),
  cell: (info) => info.getValue(),
});

// Accessor with transformation
columnHelper.accessor("submittedAt", {
  id: "submittedAt",
  header: () => t("table.dateSubmitted"),
  cell: (info) =>
    format.dateTime(new Date(info.getValue()), {
      year: "numeric",
      month: "short",
      day: "numeric",
    }),
});

// Accessor with component rendering
columnHelper.accessor("status", {
  id: "status",
  header: () => t("table.status"),
  cell: (info) => <StatusBadge status={info.getValue()} />,
});
```

### Display Columns

```typescript
// Actions column
columnHelper.display({
  id: "actions",
  header: () => t("table.actions"),
  cell: (info) => (
    <Link href={`/${locale}/items/${info.row.original.id}`}>
      <Button variant="ghost" size="sm">
        {t("actions.view")}
      </Button>
    </Link>
  ),
});
```

## State Management Integration

### Server-Side Filtering

```typescript
// Hook handles server-side filtering
export function useItems() {
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState<string | undefined>();

  // Filters sent to API as query parameters
  const queryResult = useQuery({
    queryKey: ["items", { search, status }],
    queryFn: () => fetchItems({ search, status }),
  });

  return { data: queryResult.data?.data ?? [], search, setSearch, ... };
}
```

### Client-Side Pagination

```typescript
// TanStack Table handles client-side pagination of filtered results
const table = useReactTable({
  data: items, // Already filtered by server
  columns,
  getCoreRowModel: getCoreRowModel(),
  getPaginationRowModel: getPaginationRowModel(),
  initialState: {
    pagination: { pageSize: 10, pageIndex: 0 },
  },
});
```

## Documentation Requirements

Add inline comments explaining:
- Column helper instantiation
- Table configuration (row models)
- Pagination reset logic

```typescript
/**
 * TanStack Table column helper for Item type
 * Provides type-safe column definitions
 */
const columnHelper = createColumnHelper<Item>();

/**
 * Initialize TanStack Table with:
 * - Core row model for basic table functionality
 * - Pagination row model for client-side pagination
 * - Filtered row model for client-side filtering
 */
const table = useReactTable({ ... });
```

## Testing

All table functionality must be tested:
- ✅ Pagination navigation (next, previous, page numbers)
- ✅ Filter application and clearing
- ✅ Search functionality
- ✅ Row actions (view, edit, delete)
- ✅ Loading states
- ✅ Empty states

## Reference Implementation

See the Contact Us feature for a complete reference implementation:
- Hook: `src/hooks/use-contact-submissions.ts`
- Page: `src/app/[locale]/(app)/contact-us/page.tsx`
- Spec: `openspec/specs/contact-us-management/spec.md`

## Migration Checklist

When migrating existing manual pagination to TanStack Table:

- [ ] Install `@tanstack/react-table`
- [ ] Add explicit return type interface to data hook
- [ ] Remove manual pagination state (`currentPage`, `pageSize`)
- [ ] Remove manual pagination calculations
- [ ] Create column definitions with `createColumnHelper`
- [ ] Initialize table with `useReactTable`
- [ ] Update table rendering to use `table.getHeaderGroups()` and `table.getRowModel().rows`
- [ ] Update pagination component to use `table.getState().pagination` and `table.setPageIndex()`
- [ ] Add pagination reset effect for filter changes
- [ ] Test all functionality
- [ ] Run `pnpm type-check` and `pnpm lint`

## Benefits

- **Type Safety**: Full TypeScript support with type inference
- **Maintainability**: Declarative column definitions
- **Extensibility**: Easy to add sorting, filtering, column visibility
- **Performance**: Optimized row rendering
- **Consistency**: Standardized pattern across all tables
