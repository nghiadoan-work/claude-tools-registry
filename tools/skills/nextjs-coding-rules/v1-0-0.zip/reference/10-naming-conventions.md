# 10 — Naming Conventions

This document defines the mandatory naming conventions for files, directories, and symbols to ensure the codebase is self-descriptive and easy to navigate.

## General Rules

-   **Symbols (Types, Classes, Components)**: `PascalCase` (e.g., `AdminUser`, `CreateUserUseCase`).
-   **Files & Directories**: `KEBAB_CASE` (e.g., `admin-users`, `create-user-use-case.ts`).
-   **Variables & Functions**: `camelCase` (e.g., `getUsers`, `isLoading`).
-   **Constants**: `SCREAMING_SNAKE_CASE` (e.g., `API_ENDPOINTS`, `CACHE_TAGS`).
-   **Language**: Use English for all names. Avoid abbreviations unless they are universally understood (e.g., `DTO`, `UI`).

> **Note**: The ESLint configuration enforces `KEBAB_CASE` for all files and folders in the `src/` directory (except the `src/app` router directory structure).

---

## File Naming Suffixes

All files **MUST** use a semantic suffix to clearly indicate their purpose and architectural layer.

| Layer          | Type                 | Suffix           | Example                        |
|----------------|----------------------|------------------|--------------------------------|
| **Domain**     | Entity / Types       | `.types.ts`      | `list-users.types.ts`          |
|                | Use Case             | `.use-case.ts`   | `list-users.use-case.ts`       |
| **Infrastructure**| Repository           | `.repository.ts` | `users-http.repository.ts`     |
| **UI (app)**   | Page / API Route     | `page.tsx`/`route.ts` | `app/users/page.tsx`       |
|                | Layout               | `layout.tsx`     | `app/users/layout.tsx`         |
| **Hooks**      | Custom Hook          | `.ts`            | `use-users-list.ts`            |
| **Testing**    | Test File            | `.test.ts`       | `list-users.use-case.test.ts`  |

---

## Naming Guide

### ✅ Do
-   **Use Verb-Noun for functions**: `createUser`, `validateEmail`, `formatCurrency`.
-   **Use `useFeature` for custom hooks**: `useUsersList`, `useAuthSession`.
-   **Use Plural nouns for collections**: `const users = getUsers()`.
-   **Be Specific**: `HttpUsersRepository` is better than `ApiService`. `ListUsersUseCase` is better than `ListUsers`.
-   **Match File and Symbol Names**: A file named `use-users-list.ts` should export a hook named `useUsersList`. A file named `list-users.use-case.ts` should export `ListUsersUseCase`.

### ❌ Don't
-   **Avoid Generic Names**: Do not use vague names like `Manager`, `Helper`, `Service`, or `utils.ts`. Be specific about the file's purpose (e.g., `date-utils.ts`).
-   **Avoid Technical Prefixes/Suffixes in Domain**: Domain layer names should reflect the business, not the technology. For example, use `type User` not `interface IUserEntity`.