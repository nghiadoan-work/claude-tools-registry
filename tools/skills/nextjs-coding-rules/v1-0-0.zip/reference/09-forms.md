# 09 — Forms Handling

This document defines the standard pattern for building forms using React Hook Form, Zod, and Server Actions.

## Form Architecture

-   **State Management**: `react-hook-form` manages form state on the client.
-   **Validation**: `zod` defines the validation schema.
-   **Submission**: Form submission is primarily handled by client-side async actions that call domain use cases. Server Actions can be used as a secondary option for simple cases.
-   **UI**: Components from `shadcn/ui` are used to build the form.

---

## Implementation Guide

### ✅ Do
1.  **Define a Zod Schema**: In your `domain/entities` directory, create a Zod schema that defines the shape and validation rules for your form data. Export the inferred `type` for use in your components.
2.  **Create a Form Component**: Build your form as a Client Component (`*.client.tsx`).
3.  **Use `useForm` with `zodResolver`**: Initialize `react-hook-form` and connect it to your Zod schema using `@hookform/resolvers/zod`.
4.  **Build the UI with `shadcn/ui`**: Use the `Form`, `FormField`, `FormItem`, `FormLabel`, `FormControl`, and `FormMessage` components from `shadcn/ui` to construct an accessible form.
5.  **Create a Server Action**: Define a Server Action in `infrastructure/server/actions/` to handle the form submission.
6.  **Validate on the Server**: Inside the Server Action, parse the incoming `FormData` and validate it again using the same Zod schema. This is a critical security step.
7.  **Return Structured Responses**: The Server Action **MUST** return a structured object indicating success or failure (e.g., `{ ok: true, data: ... }` or `{ ok: false, fieldErrors: { ... } }`).
8.  **Handle Response in the Client**: In the form component's `onSubmit` handler, call the Server Action and use the returned result to update the UI (e.g., display a success toast or set form errors with `form.setError`).

### ❌ Don't
-   **Do not trust client-side validation alone**. Always re-validate all data on the server within your Server Action.
-   **Do not perform business logic in the form component**. The component's only job is to collect data and call the Server Action.
-   **Do not use `useState` to manage form state**. Let `react-hook-form` handle the entire form lifecycle.
-   **Do not mix validation logic**. The Zod schema should be the single source of truth for all validation rules.
