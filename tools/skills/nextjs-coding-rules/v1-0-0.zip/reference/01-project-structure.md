# 01 — Project Structure

This document defines the mandatory file organization and folder conventions. Adhering to this structure is critical for maintaining separation of concerns.

## Core Directory Structure

The project is organized into distinct layers, each with a specific responsibility.

```
src/
├── app/             # Next.js App Router: routing and pages ONLY, sub UI components MUST BE in ui folder.
├── domain/          # Core business logic, entities, and use cases. Framework-agnostic.
├── infrastructure/  # Implements external services (APIs, DBs, repositories).
├── hooks/           # Custom React hooks containing UI state and data-fetching logic.
├── lib/             # Shared utilities and configurations.
├── styles/          # Global styles and theme definitions.
└── ui/              # Themed base UI components from shadcn/ui and pages ui will be in folder with feature name.
```

---

## Layer-Specific Rules

### 1. Domain Layer (`src/domain`)
Contains the core, framework-agnostic business logic.

#### ✅ Do
-   Define business entities and type definitions (`*.types.ts` or `*.entity.ts`).
-   Encapsulate business operations and rules in use cases (`*.usecase.ts`).

#### ❌ Don't
-   Do not import from any other layer (`infrastructure`, `app`, etc.).
-   Do not contain any framework-specific code (e.g., no React, Next.js, or browser APIs).

### 2. Infrastructure/Data Layer (`src/infrastructure`)
Implements the logic for interacting with external systems. This corresponds to the `/data` folder in the conceptual example.

#### ✅ Do
-   Implement repository classes that access databases or external APIs (`*.repository.ts`).
-   Define repository interfaces to decouple the domain from the implementation.
-   Import from the `domain` layer to use entities and types.

#### ❌ Don't
-   Do not contain business logic; this belongs in the domain layer.
-   Do not import from the `app` or `ui` layers.

### 3. UI Layer (`src/app` and `src/ui`)

#### Page Components (`src/app/**/page.tsx`)
Top-level route components that orchestrate the page's state and UI.

##### ✅ Do
-   Use `page.tsx` files as Client Components (`'use client'`) that manage page-level state.
-   Create a custom hook (e.g., `useUsersList`) to encapsulate ALL state and data-fetching logic.
-   Pass state and callbacks as props to child UI components.
-   Keep the page component simple - it should orchestrate hooks and pass data down.

##### ❌ Don't
-   Do not use `useState`/`useEffect` directly in page components - create custom hooks instead.
-   Do not allow sub-components to make API calls - all API logic should be in page-level hooks.

#### UI Components (`src/ui/**`)
Reusable, presentational components that receive data via props.

##### ✅ Do
-   Accept all data and callbacks via props from parent/page components.
-   Use `useState` ONLY for internal component UI state (e.g., modal open/close, input focus, local toggles).
-   Keep components focused on presentation and user interaction.
-   Design components to be reusable across different pages.

##### ❌ Don't
-   Do NOT make API calls or use React Query hooks in UI components.
-   Do NOT use `useEffect` for data fetching - receive data via props instead.
-   Do NOT manage page-level or business state - this belongs in page hooks.

