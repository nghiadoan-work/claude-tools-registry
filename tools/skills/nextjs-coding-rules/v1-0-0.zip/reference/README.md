# Coding Rules

This directory contains the official coding rules and guidelines for the Residence Back Office application. These rules are the single source of truth for architecture, styling, and conventions.

## Core Principles

## Core Principles

-   **Clean Architecture**: A separation of concerns between UI, state management, application logic, and data access.
-   **Client-Centric**: Data requests are initiated from the client-side state management layer, which calls domain use cases to fetch or mutate data.
-   **Token-Based Design**: All UI styling (colors, fonts, spacing) is managed through a centralized, token-based system in `globals.css` and consumed via Tailwind CSS.
-   **Strict State Management**: Client-side state is managed exclusively with `useState`.

## Rule Categories

-   [**01 - Project Structure**](./01-project-structure.md): File organization, folder conventions, and layer boundaries.
-   [**02 - Tech Stack**](./02-tech-stack.md): Approved libraries, versions, and forbidden dependencies.
-   [**03 - Clean Architecture**](./03-clean-architecture.md): Layer definitions, the dependency rule, and data request flow.
-   [**04 - Routing & i18n**](./04-routing-i18n.md): App Router conventions, locale handling, and translation patterns.
-   [**05 - State Management**](./05-state-management.md): The `userState`-only rule, context patterns, and server state handling.
-   [**06 - Dependency Injection**](./06-dependency-injection.md): Per-request containers and service composition.
-   [**07 - Server Networking**](./07-server-networking.md): Server-only data fetching and the gateway pattern.
-   [**08 - Caching**](./08-caching.md): Next.js and TanStack Query caching strategies.
-   [**09 - Forms**](./09-forms.md): `react-hook-form` and `zod` patterns with Server Actions.
-   [**10 - Naming Conventions**](./10-naming-conventions.md): Rules for files, directories, and symbols.
-   [**11 - Testing**](./11-testing.md): Testing strategies for each architectural layer.
-   [**12 - Security & Environment**](./12-security-environment.md): Secrets management, authentication, and data security.
-   [**13 - UI & Theming**](./13-ui-theming-shadcn.md): `shadcn/ui` standards and token-based theming.

## How to Use
-   Treat these rules as the definitive guide for all development.
-   When in doubt, refer to the relevant document before implementing a new feature or refactoring.
-   These rules are enforced through ESLint, TypeScript, and code reviews.
