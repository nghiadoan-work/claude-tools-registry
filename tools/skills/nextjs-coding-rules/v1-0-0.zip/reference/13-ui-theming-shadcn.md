# 13 — UI & Theming

This document outlines the standards for using `shadcn/ui` and a token-based theming system to ensure a consistent and brand-aligned user interface.

## Core Principles

-   **Single Source of Truth**: All design tokens (colors, fonts, spacing, radii) are defined as CSS variables in `src/styles/globals.css`.
-   **Component Library**: `shadcn/ui` is the exclusive component library. Components are added to `src/ui` and are styled using the central theme file.
-   **Utility-First with Tokens**: Styling is applied via Tailwind CSS utility classes that are mapped to the CSS design tokens.

---

## Theming Guide

### ✅ Do
-   **Define All Colors as CSS Variables**: In `globals.css`, define all brand colors under `:root` for the light theme and `.dark` for the dark theme. Use the `--color-<role>-<scale>` naming convention (e.g., `--color-primary`, `--color-neutral-500`).
-   **Map Tokens in `tailwind.config.ts`**: Configure your Tailwind theme to use the CSS variables. For example, the `primary` color in Tailwind should be mapped to `rgb(var(--color-primary) / <alpha-value>)`.
-   **Use Semantic Color Classes**: Apply colors using semantic utility classes like `bg-primary`, `text-destructive`, or `border-border-subtle`.
-   **Use `ThemeProvider`**: Use a theme provider (like `next-themes`) to manage the application of the `.dark` class to the `<html>` element.

### ❌ Don't
-   **Do not use hardcoded color classes** like `bg-blue-500` or `text-gray-700`. This breaks the theming system and creates inconsistencies.
-   **Do not write custom CSS for component styling** where a Tailwind utility class based on a token can be used.

---

## Component Usage Guide

### ✅ Do
-   **Use `shadcn/ui` Components**: All UI elements like buttons, inputs, cards, and dialogs **MUST** be sourced from the `src/ui` directory, which contains the project's `shadcn/ui` components.
-   **Use Component Variants**: Leverage the built-in variants for styling (e.g., `<Button variant="destructive">`).
-   **Compose Components**: Build complex UI elements by composing smaller, single-purpose `shadcn/ui` components.
-   **Ensure Accessibility**: Use associated `<Label>` components for form inputs and provide `aria-label` attributes for icon-only buttons.

### ❌ Don't
-   **Do not create one-off, custom-styled components** in `src/components/shared/` if a `shadcn/ui` equivalent exists.
-   **Do not override component styles with arbitrary values**. If a style variation is needed, create a new variant in that component's `cva` definition.

---

## Iconography Guide

### ✅ Do
-   **Use a Single Icon Library**: Standardize on one icon library (e.g., `lucide-react`) for all icons to ensure a consistent visual style (stroke width, line caps, etc.).
-   **Use `text-muted-foreground` for Icons**: By default, icons should use a neutral, muted color and inherit their color from parent elements where appropriate.

### ❌ Don't
-   **Do not use emojis as icons**.
-   **Do not mix different icon styles** (e.g., filled and line-art icons) in the same interface.
-   **Do not embed raw SVGs** directly in components; convert them to React components or use an icon library.
