# 07 — Data Fetching & Networking

This document defines the client-centric data fetching pattern using **React Query + Axios**.

## Data Flow: React Query in Custom Hooks

All data fetching is initiated from custom hooks using **React Query** on the client.

### ✅ Do
-   **Use React Query (`useQuery`)**: All data fetching **MUST** use TanStack Query's `useQuery` hook within custom hooks (e.g., `useAdminUsers`).
-   **Use Axios for HTTP requests**: Call API routes using the configured Axios client from `@/lib/api/client`.
-   **Call API Routes only**: All client requests must go through Next.js API Routes (e.g., `/api/admin-users`).
-   **Define proper `queryKey`**: Use structured keys like `['admin-users', { page, search }]` for automatic cache management.
-   **Handle dependencies in queryKey**: Include all parameters that affect the query in the `queryKey` array.

### ❌ Don't
-   **Do not use manual `useEffect` + `fetch`**. React Query provides better caching, error handling, and loading states.
-   **Do not call use cases or repositories directly from the client**. All requests must go through API Routes.
-   **Do not use `fetch` directly in hooks**. Use the Axios client for consistent error handling and interceptors.

---

## Client-Side Data Fetching

### Axios Client Configuration

The Axios client is configured in `src/lib/api/client.ts`:

```ts
import axios from 'axios';

export const apiClient = axios.create({
  baseURL: '/api',
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Response interceptor for error handling
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    const message = error.response?.data?.error?.message || error.message;
    const apiError = new Error(message);
    (apiError as any).status = error.response?.status;
    return Promise.reject(apiError);
  }
);
```

### React Query Hook Pattern

```ts
// hooks/use-admin-users.ts
'use client';

import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { apiClient } from '@/lib/api/client';

interface ListParams {
  page: number;
  pageSize: number;
  search?: string;
}

async function fetchAdminUsers(params: ListParams) {
  const query = new URLSearchParams();
  query.set('page', params.page.toString());
  query.set('pageSize', params.pageSize.toString());
  if (params.search) query.set('search', params.search);

  const response = await apiClient.get(`/admin-users?${query.toString()}`);
  return response.data;
}

export function useAdminUsers(options?: {
  initialPage?: number;
  initialPageSize?: number;
}) {
  const [page, setPage] = useState(options?.initialPage ?? 1);
  const [pageSize, setPageSize] = useState(options?.initialPageSize ?? 20);
  const [search, setSearch] = useState('');

  const queryResult = useQuery({
    queryKey: ['admin-users', { page, pageSize, search }],
    queryFn: () => fetchAdminUsers({ page, pageSize, search }),
  });

  return {
    data: queryResult.data?.data ?? [],
    total: queryResult.data?.total ?? 0,
    isLoading: queryResult.isLoading,
    error: queryResult.error?.message ?? null,
    page,
    pageSize,
    search,
    setPage,
    setPageSize,
    setSearch,
    refresh: () => {
      queryResult.refetch();
    },
  };
}
```

### Mutations (POST, PUT, DELETE)

For create/update/delete operations, use `useMutation`:

```ts
// hooks/use-create-admin-user.ts
'use client';

import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiClient } from '@/lib/api/client';

export function useCreateAdminUser() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (data: CreateAdminUserInput) => {
      const response = await apiClient.post('/admin-users', data);
      return response.data.data;
    },
    onSuccess: () => {
      // Invalidate and refetch list queries
      queryClient.invalidateQueries({ queryKey: ['admin-users'] });
    },
  });
}

// Usage in component
function CreateUserForm() {
  const createUser = useCreateAdminUser();

  const handleSubmit = async (formData) => {
    try {
      await createUser.mutateAsync(formData);
      toast.success('User created successfully!');
      router.push('/admin-users');
    } catch (error) {
      toast.error(createUser.error?.message ?? 'Failed to create user');
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      {/* form fields */}
      <button disabled={createUser.isPending}>
        {createUser.isPending ? 'Creating...' : 'Create User'}
      </button>
    </form>
  );
}
```

---

## API Route Responsibilities

API Routes (`app/api/**`) bridge the client and server-side domain logic.

### ✅ Do
-   **Parse request parameters**: Read and validate incoming query/body parameters.
-   **Instantiate dependencies**: Create instances of repositories and use cases.
-   **Execute the use case**: Call the use case with validated parameters.
-   **Return JSON response**: Return structured JSON with `data` and optional `meta` fields.
-   **Handle errors gracefully**: Catch errors and return appropriate HTTP status codes.

### ❌ Don't
-   **Do not place business logic in API routes**. Logic belongs in domain use cases.
-   **Do not expose internal errors to clients**. Return user-friendly error messages.

### Example API Route

```ts
// app/api/admin-users/route.ts
import { NextRequest } from 'next/server';
import { AdminUsersMockRepository } from '@/infrastructure/repositories/admin-users.mock.repository';
import { ListAdminUsersUseCase } from '@/domain/use-cases/list-admin-users.usecase';

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);

    const params = {
      page: Number(searchParams.get('page') ?? '1'),
      pageSize: Number(searchParams.get('pageSize') ?? '20'),
      search: searchParams.get('search') ?? undefined,
      role: searchParams.get('role') ?? undefined,
      status: searchParams.get('status') ?? undefined,
    };

    // Instantiate dependencies
    const repository = new AdminUsersMockRepository();
    const useCase = new ListAdminUsersUseCase(repository);

    // Execute use case
    const result = await useCase.execute(params);

    return Response.json({
      data: result.data,
      meta: {
        total: result.total,
        page: result.page,
        pageSize: result.pageSize,
      },
    });
  } catch (error: any) {
    console.error('API Error:', error);
    return Response.json(
      {
        error: {
          message: error.message ?? 'Failed to fetch admin users',
          field: error.field,
        }
      },
      { status: error.status ?? 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();

    // Validate input
    // ... validation logic

    const repository = new AdminUsersMockRepository();
    const useCase = new CreateAdminUserUseCase(repository);

    const result = await useCase.execute(body);

    return Response.json(
      { data: result },
      { status: 201 }
    );
  } catch (error: any) {
    return Response.json(
      { error: { message: error.message ?? 'Failed to create admin user' } },
      { status: error.status ?? 500 }
    );
  }
}
```

---

## Server-Side HTTP Requests (Repositories)

For server-side HTTP requests (in repositories), use the server-side Axios instance with proper configuration.

### ✅ Do
-   **Use server-side Axios client**: Configured in `@/infrastructure/http/axios.ts`
-   **Include authentication**: Add bearer tokens via interceptors
-   **Set locale headers**: Include `X-Locale` for internationalization
-   **Add request IDs**: For tracing and debugging
-   **Implement retry logic**: For idempotent requests (GET)

### Example Repository

```ts
// infrastructure/repositories/admin-users.http.repository.ts
import 'server-only';
import { createApi, type UpstreamCtx } from '@/infrastructure/http/axios';
import type { AdminUser, ListAdminUsersParams } from '@/domain/entities/admin-user.types';

export class AdminUsersHttpRepository {
  private api;

  constructor(ctx: UpstreamCtx) {
    this.api = createApi(ctx);
  }

  async list(params: ListAdminUsersParams) {
    const response = await this.api.get('/admin-users', { params });
    return response.data;
  }

  async findById(id: string) {
    const response = await this.api.get(`/admin-users/${id}`);
    return response.data;
  }

  async create(data: Partial<AdminUser>) {
    const response = await this.api.post('/admin-users', data);
    return response.data;
  }

  async update(id: string, data: Partial<AdminUser>) {
    const response = await this.api.put(`/admin-users/${id}`, data);
    return response.data;
  }
}
```

---

## Error Handling

### Client-Side (React Query)

React Query automatically handles:
- Loading states (`isLoading`, `isPending`)
- Error states (`error`, `isError`)
- Retry logic (configurable)

```ts
const { data, isLoading, error } = useQuery({
  queryKey: ['admin-users'],
  queryFn: fetchAdminUsers,
  retry: 2, // Retry failed requests 2 times
});

if (error) {
  return <ErrorMessage message={error.message} />;
}
```

### Server-Side (API Routes)

```ts
try {
  const result = await useCase.execute(params);
  return Response.json({ data: result });
} catch (error: any) {
  // Log for debugging
  console.error('API Error:', error);

  // Return user-friendly error
  return Response.json(
    {
      error: {
        message: error.message ?? 'An error occurred',
        code: error.code,
      }
    },
    { status: error.status ?? 500 }
  );
}
```

---

## Benefits of React Query + Axios

✅ **Automatic Caching**: Reduces network requests, improves performance
✅ **Request Deduplication**: Multiple components requesting same data = single request
✅ **Background Refetching**: Keeps data fresh automatically
✅ **Retry Logic**: Built-in retry on failure
✅ **Optimistic Updates**: Update UI before server confirms
✅ **Simpler Code**: No manual loading/error state management
✅ **Type Safety**: Full TypeScript support with Axios
✅ **Interceptors**: Centralized error handling and auth

---

## Migration from Legacy Pattern

If you see hooks using `useState` + `useEffect` + `fetch`, **migrate to React Query**:

### Before (Legacy):
```ts
const [data, setData] = useState([]);
const [isLoading, setIsLoading] = useState(false);
const [error, setError] = useState(null);

useEffect(() => {
  const controller = new AbortController();
  setIsLoading(true);
  fetch('/api/admin-users', { signal: controller.signal })
    .then(res => res.json())
    .then(setData)
    .catch(setError)
    .finally(() => setIsLoading(false));
  return () => controller.abort();
}, []);
```

### After (React Query + Axios):
```ts
const { data = [], isLoading, error } = useQuery({
  queryKey: ['admin-users'],
  queryFn: async () => {
    const response = await apiClient.get('/admin-users');
    return response.data.data;
  },
});
```

**Much simpler and more robust!** 🎉
