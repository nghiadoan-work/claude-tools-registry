# 02 — Tech Stack & Dependencies

This document defines the approved technologies and libraries for the application. Adhering to this list ensures consistency and avoids dependency conflicts.

## Core Technologies

-   **Framework**: Next.js (App Router)
-   **UI**: React
-   **Language**: TypeScript (Strict Mode)
-   **Server State**: TanStack Query (React Query) for data fetching and caching
-   **UI State**: React Hooks (`useState`)
-   **HTTP Client**: Axios with interceptors
-   **Authentication**: NextAuth.js with Keycloak
-   **Validation**: Zod
-   **Forms**: React Hook Form
-   **i18n**: `next-intl`

---

## FORBIDDEN Dependencies

The following libraries are **strictly forbidden** to maintain architectural integrity.

-   **Alternative State Management**: `zustand`, `jotai`, `redux`, `valtio`, `recoil`.
    -   **Reason**: The project standardizes on TanStack Query for server state and React Hooks for UI state.

-   **Alternative HTTP Clients**: Do not use `fetch` directly in hooks, `ky`, `got`, or other HTTP libraries.
    -   **Reason**: Use the configured Axios client (`@/lib/api/client`) for consistent error handling and interceptors.

---

## Configuration Guide

Instead of including full configuration files, follow these guiding principles.

-   **`tsconfig.json`**: 
    -   **MUST** be in `strict` mode.
    -   **MUST** define path aliases (`@/domain/*`, `@/infrastructure/*`, etc.) to match the project structure.

-   **`.eslintrc.json`**:
    -   **SHOULD** include rules to restrict imports between layers (e.g., prevent `domain` from importing `infrastructure`).

-   **`next.config.js`**:
    -   **SHOULD** enable `typedRoutes` for improved type safety in navigation.
