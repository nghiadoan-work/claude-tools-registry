# 04 — Routing & Internationalization (i18n)

T#### ✅ Do
-   **Use `getTranslations` in Server Components**: For server-rendered pages and components.
-   **Use `useTranslations` in Client Components**: For interactive components that need access to translations on the client.
-   **Use ICU Message Format**: For handling plurals and variables in your translations (e.g., `"{count, plural, =1 {1 item} other {# items}}"`).
-   **Use Scoped Translation Keys**: When using `useTranslations("namespace")`, access keys directly without the namespace prefix. Use `t("title")`, NOT `t("users.title")` when your hook is already scoped to the users namespace.
    ```typescript
    // ✅ Correct - scoped to namespace
    const t = useTranslations("users");
    return <h1>{t("title")}</h1>; // Looks for users.title
    
    // ❌ Wrong - double namespace
    const t = useTranslations("users");
    return <h1>{t("users.title")}</h1>; // Looks for users.users.title
    ```document defines routing conventions and i18n patterns using the Next.js App Router and `next-intl`.

## Routing Guide

### ✅ Do
-   **Use Locale-Prefixed Paths**: All user-facing routes **MUST** be prefixed with a locale (e.g., `/en/dashboard`, `/th/users`). This is enforced by the `next-intl` middleware.
-   **Use `kebab-case` for URL Segments**: Keep URLs clean and readable (e.g., `/admin/user-management`).
-   **Organize Routes by Feature**: Group related pages under a common directory (e.g., `app/[locale]/(app)/users/...`).
-   **Use Route Groups for Layouts**: Use Next.js route groups `(group-name)` to structure layouts without affecting the URL path.
-   **Use `next/navigation` for Navigation**: For client-side navigation, always use the `useRouter` or `usePathname` hooks. For server-side redirects, use the `redirect` function.

### ❌ Don't
-   **Do not use query parameters for primary navigation**. Use route segments instead (e.g., use `/users/123/edit`, not `/users/edit?id=123`). Query parameters are acceptable for secondary state like filters or sorting.
-   **Avoid deep nesting**. Aim for a maximum of 3-4 URL segments where possible to maintain clarity.

---

## Internationalization (i18n) Guide

### Message Organization

#### ✅ Do
-   **Organize by Namespace**: Create separate JSON files for each feature or domain (e.g., `common.json`, `users.json`, `dashboard.json`).
-   **Place Files by Locale**: Store all translation files in `src/lib/i18n/locales/[locale]/`.
-   **Use Nested JSON**: Structure messages hierarchically for clarity (e.g., `users.form.fullName`).
-   **Keep Keys Consistent**: Ensure that translation keys are identical across all locale files.
-   **Register Translation Namespaces**: When creating new translation files, ensure they are imported and registered in `src/lib/i18n/request.ts`. Add the import statement and include the namespace in the messages object to avoid `MISSING_MESSAGE` errors.
    ```typescript
    // Import the translation file
    import dashboardTranslations from './locales/en/dashboard.json';
    
    // Add to messages object
    const messages = {
      common: commonTranslations,
      dashboard: dashboardTranslations, // Register the namespace
      // ... other namespaces
    };
    ```

#### ❌ Don't
-   **Do not hardcode any user-facing text** in components. Always use the `useTranslations` or `getTranslations` hooks.
-   **Do not create one large JSON file** for all translations.

### Translation Usage

#### ✅ Do
-   **Use `getTranslations` in Server Components**: For server-rendered pages and components.
-   **Use `useTranslations` in Client Components**: For interactive components that need access to translations on the client.
-   **Use ICU Message Format**: For handling plurals and variables in your translations (e.g., `"{count, plural, =1 {1 item} other {# items}}"`).

### Locale-Aware Formatting

#### ✅ Do
-   **Use `useFormatter` or `getFormatter`**: For formatting dates, times, and numbers according to the user's locale. This ensures consistency and correctness.

#### ❌ Don't
-   **Do not use `new Date().toLocaleDateString()` directly**. Rely on the `next-intl` formatters, which provide more control and consistency.
