# 08 — Caching Strategies

This document defines the caching patterns for server-side data.

## Caching Guide

### Server-Side Caching (Next.js)
This is the primary caching mechanism for data fetched on the server.

#### ✅ Do
-   **Use `unstable_cache`**: For any data fetching that occurs within Server Components (e.g., for initial page loads), wrap the data-fetching function in `unstable_cache` to enable memoization within a single request and across requests.
-   **Use Cache Tags**: Tag cached data with descriptive keys (e.g., `['users', 'list']`).
-   **Revalidate on Mutation**: Use `revalidateTag()` in Server Actions or API Routes after a successful data mutation to invalidate the relevant server-side caches.

#### ❌ Don't
-   **Do not implement client-side caching manually**. The current architecture relies on fresh data fetches for each client-side navigation and does not use a client-side cache.
