# 06 — Dependency Injection

This document defines the dependency injection (DI) pattern used in the application. The goal is to decouple layers by composing them at the application's entry points (e.g., API Routes).

## Core Principle: Manual Injection in API Routes

Instead of a complex container, dependencies are instantiated and "wired up" manually at the beginning of each API Route handler. This is the application's **Composition Root**.

---

## DI Guide

### ✅ Do
-   **Instantiate Dependencies in API Routes**: Inside an API Route handler (`app/api/.../route.ts`), create the concrete instances of your repository and use case.
-   **Inject Repositories into Use Cases**: Pass the repository instance into the use case factory function.
-   **Keep Dependencies Explicit**: This pattern makes the dependencies for each endpoint clear and self-contained.

### ❌ Don't
-   **Do not use a global or singleton DI container**. Each request should compose its own dependencies.
-   **Do not instantiate repositories or gateways directly within use cases**. They should always be injected.

---

## Usage Guide

### API Routes

#### ✅ Do
1.  Inside your `GET` or `POST` handler, create an instance of your repository (e.g., `new HttpUsersRepository()`).
2.  Create an instance of your use case by passing the repository to it (e.g., `createListUsersUseCase(repo)`).
3.  Execute the use case to handle the request.

### Testing

#### ✅ Do
-   **Test Use Cases with Mocks**: When unit testing a use case, create a mock implementation of the repository (e.g., using `jest.fn()`) and pass it to the use case factory. This allows you to test the business logic in isolation.
