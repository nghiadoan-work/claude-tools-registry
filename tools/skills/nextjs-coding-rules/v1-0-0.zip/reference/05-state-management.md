# 05 — State Management

This document defines the rules for state management using **React Query** for server state and **useState** for UI state.

## Overview

State is categorized into two types:
- **Server State**: Data from APIs (managed with TanStack Query)
- **UI State**: Local component state like filters, search, pagination (managed with `useState`)

---

## Server State with React Query

All data fetching **MUST** use TanStack Query (`@tanstack/react-query`) for server state management.

### ✅ Do
-   **Use `useQuery` for GET requests**: Fetch data with automatic caching, background refetching, and deduplication.
-   **Use `useMutation` for mutations**: Handle POST, PUT, DELETE operations with optimistic updates and cache invalidation.
-   **Define proper `queryKey` structure**: Use arrays like `['feature-name', params]` for automatic cache invalidation.
-   **Call API Routes via Axios**: Use the configured Axios client from `@/lib/api/client` for all HTTP requests.
-   **Invalidate queries after mutations**: Use `queryClient.invalidateQueries()` to refresh data after create/update/delete operations.

### ❌ Don't
-   **Do not use manual `useEffect` + `fetch` for data fetching**. React Query handles this better with caching and error handling.
-   **Do not call use cases or repositories directly from the client**. All requests must go through `/api/*` routes.
-   **Do not use Redux or Zustand for server state**. React Query is the standard.

---

## UI State with useState

UI state (filters, pagination, search input) is managed with React's built-in `useState` hook.

### ✅ Do
-   **Use `useState` for UI-only state**: Page numbers, search queries, filter selections, modal open/closed state.
-   **Combine with React Query**: Pass UI state as parameters to `useQuery` via the `queryKey`.
-   **Create custom hooks**: Encapsulate related state and queries in custom hooks (e.g., `useAdminUsers`).

### ❌ Don't
-   **Do not use `useReducer`** unless state logic is exceptionally complex. Prefer multiple `useState` hooks.
-   **Do not mix server state in `useState`**. Keep fetched data in React Query cache only.

---

## The Custom Hook Pattern

All state and data-fetching logic for a feature **MUST** be encapsulated within a custom hook.

### Example: List Hook with React Query

```ts
// hooks/use-admin-users.ts
'use client';

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiClient } from '@/lib/api/client';

export function useAdminUsers(options?: {
  initialPage?: number;
  initialPageSize?: number;
  initialSearch?: string;
}) {
  // UI State (local to hook)
  const [page, setPage] = useState(options?.initialPage ?? 1);
  const [pageSize, setPageSize] = useState(options?.initialPageSize ?? 20);
  const [search, setSearch] = useState(options?.initialSearch ?? '');

  // Server State (React Query)
  const queryResult = useQuery({
    queryKey: ['admin-users', { page, pageSize, search }],
    queryFn: async () => {
      const response = await apiClient.get('/admin-users', {
        params: { page, pageSize, search },
      });
      return response.data;
    },
  });

  return {
    // Data from React Query
    data: queryResult.data?.data ?? [],
    total: queryResult.data?.total ?? 0,
    isLoading: queryResult.isLoading,
    error: queryResult.error?.message ?? null,

    // UI State
    page,
    pageSize,
    search,

    // UI State Setters
    setPage,
    setPageSize: (value: number) => {
      setPageSize(value);
      setPage(1); // Reset to page 1 when changing page size
    },
    setSearch: (value: string) => {
      setSearch(value);
      setPage(1); // Reset to page 1 when searching
    },

    // Refresh function
    refresh: () => {
      queryResult.refetch();
    },
  };
}
```

### Example: Detail Hook with Mutations

```ts
// hooks/use-admin-user.ts
'use client';

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiClient } from '@/lib/api/client';

export function useAdminUser(id: string) {
  const queryClient = useQueryClient();

  // Fetch single item
  const queryResult = useQuery({
    queryKey: ['admin-user', id],
    queryFn: async () => {
      const response = await apiClient.get(`/admin-users/${id}`);
      return response.data.data;
    },
    enabled: !!id,
  });

  // Update mutation
  const updateMutation = useMutation({
    mutationFn: async (updates: Partial<AdminUser>) => {
      const response = await apiClient.put(`/admin-users/${id}`, updates);
      return response.data.data;
    },
    onSuccess: () => {
      // Invalidate related queries
      queryClient.invalidateQueries({ queryKey: ['admin-users'] });
      queryClient.invalidateQueries({ queryKey: ['admin-user', id] });
    },
  });

  return {
    data: queryResult.data ?? null,
    isLoading: queryResult.isLoading,
    error: queryResult.error?.message ?? null,
    isUpdating: updateMutation.isPending,
    updateError: updateMutation.error?.message ?? null,
    update: (updates: Partial<AdminUser>) => updateMutation.mutateAsync(updates),
    refresh: () => {
      queryResult.refetch();
    },
  };
}
```

### Example: Create Mutation Hook

```ts
// hooks/use-create-admin-user.ts
'use client';

import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiClient } from '@/lib/api/client';

export function useCreateAdminUser() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (data: CreateAdminUserInput) => {
      const response = await apiClient.post('/admin-users', data);
      return response.data.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-users'] });
    },
  });
}

// Usage in component
function CreateUserForm() {
  const createUser = useCreateAdminUser();

  const handleSubmit = async (data) => {
    try {
      await createUser.mutateAsync(data);
      toast.success('User created!');
    } catch (error) {
      toast.error(createUser.error?.message ?? 'Failed to create user');
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      {/* form fields */}
      <button disabled={createUser.isPending}>
        {createUser.isPending ? 'Creating...' : 'Create User'}
      </button>
    </form>
  );
}
```

---

## URL State (Routing)

URL state should be used for shareable/bookmarkable filters and pagination.

### ✅ Do
-   **Use URL `searchParams` for filters and pagination**: e.g., `?page=2&search=john&role=admin`
-   **Read params with `useSearchParams`**: Initialize hook state from URL params.
-   **Update URL with `useRouter`**: Keep URL in sync with state changes for shareability.

### ❌ Don't
-   **Do not store sensitive data in URL params** (e.g., passwords, tokens).

---

## React Query Configuration

The QueryClient is configured in `src/lib/react-query/provider.client.tsx`:

```ts
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 60 * 1000, // 1 minute
      gcTime: 10 * 60 * 1000, // 10 minutes (garbage collection)
      refetchOnWindowFocus: true,
      retry: 1,
    },
  },
});
```

### Query Options

- **`staleTime`**: How long data is considered fresh (default: 1 minute)
- **`gcTime`**: How long unused data stays in cache (default: 10 minutes)
- **`refetchOnWindowFocus`**: Auto-refetch when window regains focus
- **`retry`**: Number of retry attempts on failure

### Customizing Per Query

```ts
useQuery({
  queryKey: ['categories'],
  queryFn: fetchCategories,
  staleTime: 5 * 60 * 1000, // 5 minutes - categories rarely change
  gcTime: 30 * 60 * 1000, // 30 minutes
  retry: 3, // Retry 3 times for critical data
});
```

---

## Benefits of React Query

- ✅ **Automatic Caching**: Reduces unnecessary network requests
- ✅ **Request Deduplication**: Multiple components requesting same data = single request
- ✅ **Background Refetching**: Keep data fresh automatically
- ✅ **Retry Logic**: Built-in retry on failure
- ✅ **Optimistic Updates**: Update UI before server confirms
- ✅ **Simpler Code**: No manual loading/error state management
- ✅ **DevTools**: Inspect cache and queries in React Query DevTools

---

## Migration from Legacy Pattern

If you see hooks using `useState` + `useEffect` + `fetch`, migrate to React Query:

### Before (Legacy):
```ts
const [data, setData] = useState([]);
const [isLoading, setIsLoading] = useState(false);
const [error, setError] = useState(null);

useEffect(() => {
  const controller = new AbortController();
  setIsLoading(true);
  fetch('/api/users', { signal: controller.signal })
    .then(res => res.json())
    .then(setData)
    .catch(setError)
    .finally(() => setIsLoading(false));
  return () => controller.abort();
}, []);
```

### After (React Query):
```ts
const { data = [], isLoading, error } = useQuery({
  queryKey: ['users'],
  queryFn: async () => {
    const response = await apiClient.get('/users');
    return response.data;
  },
});
```

**Much cleaner!** 🎉
