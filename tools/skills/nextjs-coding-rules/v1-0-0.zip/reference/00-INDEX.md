# Next.js Coding Rules - Reference Documentation

This directory contains comprehensive reference documentation for the Residence Backoffice Next.js application architecture and coding standards.

## Quick Navigation

### Architecture & Structure
- **[01-project-structure.md](./01-project-structure.md)** - Layer organization, file structure, directory conventions
- **[02-tech-stack.md](./02-tech-stack.md)** - Approved libraries, versions, forbidden dependencies
- **[03-clean-architecture.md](./03-clean-architecture.md)** - Layer definitions, dependency rule, data flow

### Routing & Internationalization
- **[04-routing-i18n.md](./04-routing-i18n.md)** - App Router conventions, locale handling, translation patterns

### State & Data Management
- **[05-state-management.md](./05-state-management.md)** - TanStack Query patterns, custom hooks, useState rules
- **[06-dependency-injection.md](./06-dependency-injection.md)** - Composition root pattern, manual DI
- **[07-server-networking.md](./07-server-networking.md)** - API routes, Axios configuration, repository patterns
- **[08-caching.md](./08-caching.md)** - React Query caching, cache invalidation strategies

### Forms & Tables
- **[09-forms.md](./09-forms.md)** - React Hook Form + Zod patterns, Server Actions
- **[14-tables-pagination.md](./14-tables-pagination.md)** - TanStack Table implementation, column definitions

### Conventions & Standards
- **[10-naming-conventions.md](./10-naming-conventions.md)** - File naming, symbol naming, KEBAB_CASE rules
- **[11-testing.md](./11-testing.md)** - Layer-specific testing strategies
- **[12-security-environment.md](./12-security-environment.md)** - Environment variables, authentication, security
- **[13-ui-theming-shadcn.md](./13-ui-theming-shadcn.md)** - Token-based theming, shadcn/ui usage

### Examples & Patterns
- **[EXAMPLES.md](./EXAMPLES.md)** - Complete architecture examples with code
- **[README.md](./README.md)** - Overview of coding rules and principles

## How to Use This Reference

### For Quick Lookup
Use the table of contents above to find specific topics.

### For Implementation
1. Start with **03-clean-architecture.md** to understand layer separation
2. Review **05-state-management.md** for data fetching patterns
3. Check **14-tables-pagination.md** for table implementation
4. Reference **EXAMPLES.md** for complete code examples

### For Code Review
1. Check **10-naming-conventions.md** for file/symbol naming
2. Review **03-clean-architecture.md** for layer boundary violations
3. Verify **05-state-management.md** for state management compliance
4. Check **09-forms.md** for form validation patterns

## Core Principles Summary

### Clean Architecture
- **Domain Layer**: Pure business logic (no framework dependencies)
- **Infrastructure Layer**: External services, repositories
- **Hooks Layer**: Custom hooks with TanStack Query + useState
- **UI Layer**: Pages and presentational components

### Dependency Rule
```
UI → Hooks → Infrastructure → Domain
```
Dependencies flow inward only. No layer can depend on outer layers.

### State Management
- **Server State**: TanStack Query (`useQuery`, `useMutation`)
- **UI State**: React `useState` (filters, pagination, modals)
- **URL State**: Next.js `searchParams` (shareable filters)

### Data Flow
```
UI Component → Custom Hook → API Route → Use Case → Repository
```

## Constitutional Alignment

These coding rules implement the 14 core principles from `/CLAUDE.md`:
- Principle I: Clean Architecture
- Principle II: Client-Centric Data Flow
- Principle III: State Management Discipline
- Principle IV: Type Safety
- Principle VI: Naming Conventions
- Principle VII: Internationalization
- Principle VIII: Token-Based Theming
- Principle IX: Security & Environment Management
- Principle X: Form Handling Standardization
- Principle XI: Dependency Injection Pattern
- Principle XII: HTTP Client Standardization
- Principle XIII: Routing & File Organization
- Principle XIV: Table & Pagination Management

## Related Resources

- **Main Skill**: `../SKILL.md` - Quick reference and patterns
- **Examples**: `../examples/` - Working code examples
- **Constitution**: `/CLAUDE.md` - Core principles and governance
- **Coding Rules Source**: `/command-center/coding-rules/` - Original documentation
