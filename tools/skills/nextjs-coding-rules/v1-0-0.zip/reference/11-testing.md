# 11 — Testing

This document defines the testing strategy, which focuses on unit and integration tests for business logic and data layers. **UI component testing is explicitly out of scope.**

## Testing Strategy by Layer

### 1. Domain Layer (`src/domain`)
-   **Focus**: Pure business logic, validation rules, and entity behavior.
-   **Type**: Unit Tests.
-   **Tools**: `vitest`.
-   **Guide**:
    -   ✅ **Do**: Test pure functions and Zod schemas directly.
    -   ✅ **Do**: Test use cases by providing mock repositories and asserting that the business rules behave as expected.
    -   ❌ **Don't**: Do not mock any dependencies within the domain itself, as this layer should have none.

### 2. Infrastructure Layer (`src/infrastructure`)
-   **Focus**: Repositories, gateways, and other adapters.
-   **Type**: Integration Tests.
-   **Tools**: `vitest` with mocking.
-   **Guide**:
    -   ✅ **Do**: Mock external dependencies (like databases or HTTP clients using `msw` or `jest.mock`) to test the repository's logic in isolation.
    -   ❌ **Don't**: Do not test the external services themselves; assume they work as specified by their contract.

### 3. Hooks Layer (`src/hooks`)
-   **Focus**: State management and data fetching logic within custom hooks.
-   **Type**: Integration Tests.
-   **Tools**: `vitest`, `@testing-library/react-hooks`.
-   **Guide**:
    -   ✅ **Do**: Test the custom hook's behavior by rendering it and asserting its return values.
    -   ✅ **Do**: Mock the `fetch` API to simulate different network responses (success, error, loading).
    -   ✅ **Do**: Use `act` and `waitFor` from testing-library to handle asynchronous state updates.

---

## Best Practices

### ✅ Do
-   **Co-locate Tests**: Place test files next to the source files they are testing (e.g., `list-users.usecase.ts` and `list-users.usecase.test.ts`).
-   **Use Descriptive Names**: Follow the `describe('FeatureName')` and `it('should do something')` pattern.
-   **Arrange, Act, Assert**: Structure tests clearly into these three parts.
-   **Reset Mocks**: Ensure mocks are reset between tests using `afterEach`.

### ❌ Don't
-   **Do not test UI components**. The strategy focuses on logic, not visual output.
-   **Do not test third-party libraries**. Assume they work correctly.
-   **Do not test implementation details**. Focus on the public API and behavior of your modules.
