# 12 — Security & Environment

This document defines security patterns, environment variable handling, and data protection strategies.

## Environment Variables

### ✅ Do
-   **Validate on Startup**: All environment variables **MUST** be validated on application startup using a Zod schema located in `src/lib/env.ts`. This ensures that the application fails fast if critical variables are missing or invalid.
-   **Use `.env.local` for Secrets**: Store all secrets and local overrides in `.env.local`, which is git-ignored.
-   **Maintain `.env.example`**: Keep `.env.example` up-to-date with all required environment variables, but with placeholder or non-sensitive values.

### ❌ Don't
-   **Do not commit any secret keys** or sensitive credentials to the Git repository.
-   **Do not access `process.env` directly** in your application code. Always import the validated `env` object from `src/lib/env.ts`.

---

## Authentication & Authorization

### ✅ Do
-   **Use Server-Only Auth Logic for Session Creation**: Initial authentication and session creation should be handled securely on the server.
-   **Handle Tokens on the Client**: For a client-centric data flow, the client will need to manage the auth token. Store it securely (e.g., in memory) and attach it to outgoing API requests via your HTTP client's interceptors.
-   **Protect Routes via Middleware**: Use `src/middleware.ts` to protect routes by verifying the presence and validity of an authentication cookie or token. Unauthenticated users should be redirected to the login page.
-   **Use Keycloak for SSO**: All authentication must go through the configured Keycloak SSO provider.

### ❌ Don't
-   **Do not implement custom form-based login flows**.
-   **Do not store sensitive session information on the client-side** other than the authentication token itself (which should be handled securely by NextAuth.js or in an `HttpOnly` cookie).

---

## Data Security

### ✅ Do
-   **Validate All Input**: Validate all incoming data in Server Actions using Zod schemas, even if it was already validated on the client.
-   **Use Parameterized Queries**: When interacting with a database, always use an ORM or library that provides parameterized queries (like Drizzle) to prevent SQL injection.
-   **Sanitize HTML**: Before rendering any user-generated content that may contain HTML, sanitize it using a library like `DOMPurify` to prevent XSS attacks.

### ❌ Don't
-   **Do not construct SQL queries using string concatenation** with user input.
-   **Do not use `dangerouslySetInnerHTML`** without first sanitizing the content.

---

## General Best Practices

-   **Configure Security Headers**: Use `next.config.js` to set security headers like `X-Frame-Options`, `X-Content-Type-Options`, and a strict `Content-Security-Policy`.
-   **Implement Rate Limiting**: Protect sensitive endpoints (like login or form submissions) against brute-force attacks by implementing rate limiting.
-   **Sanitize Error Messages**: Ensure that detailed internal error messages or stack traces are not sent to the client in production. Log them on the server and return a generic error message to the user.
