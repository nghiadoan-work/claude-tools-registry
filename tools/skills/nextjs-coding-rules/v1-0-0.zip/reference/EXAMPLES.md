# Architecture Examples

This document provides concrete examples of the correct architectural patterns.

## ✅ Correct Pattern: Page Hook → UI Component

### Page Component (`src/app/[locale]/(app)/users/page.tsx`)

```tsx
'use client';

import { useUsersList } from '@/hooks/use-users-list';
import { UserTable } from '@/ui/users/user-table';
import { UserFilters } from '@/ui/users/user-filters';

export default function UsersPage() {
  // All state and API logic in the hook
  const {
    users,
    isLoading,
    error,
    page,
    setPage,
    search,
    setSearch,
    statusFilter,
    setStatusFilter,
    refresh,
  } = useUsersList();

  // Page component just orchestrates and passes props down
  return (
    <div>
      <UserFilters
        search={search}
        onSearchChange={setSearch}
        statusFilter={statusFilter}
        onStatusFilterChange={setStatusFilter}
      />

      <UserTable
        users={users}
        isLoading={isLoading}
        error={error}
        page={page}
        onPageChange={setPage}
        onRefresh={refresh}
      />
    </div>
  );
}
```

### Custom Hook (`src/hooks/use-users-list.ts`)

```tsx
'use client';

import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { apiClient } from '@/lib/api/client';
import type { User } from '@/domain/entities/user.types';

export function useUsersList() {
  // All state management here
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  // All API calls here
  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ['users', { page, search, statusFilter }],
    queryFn: async () => {
      const response = await apiClient.get('/users', {
        params: { page, search, status: statusFilter },
      });
      return response.data;
    },
  });

  return {
    users: data?.users ?? [],
    total: data?.total ?? 0,
    isLoading,
    error,
    page,
    setPage,
    search,
    setSearch,
    statusFilter,
    setStatusFilter,
    refresh: refetch,
  };
}
```

### UI Component (`src/ui/users/user-table.tsx`)

```tsx
'use client';

import { useState } from 'react';
import type { User } from '@/domain/entities/user.types';

interface UserTableProps {
  users: User[];
  isLoading: boolean;
  error: Error | null;
  page: number;
  onPageChange: (page: number) => void;
  onRefresh: () => void;
}

export function UserTable({
  users,
  isLoading,
  error,
  page,
  onPageChange,
  onRefresh
}: UserTableProps) {
  // ✅ OK: Internal UI state for component-specific behavior
  const [selectedRows, setSelectedRows] = useState<string[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);

  if (isLoading) return <div>Loading...</div>;
  if (error) return <div>Error: {error.message}</div>;

  return (
    <div>
      <table>
        {users.map(user => (
          <tr key={user.id}>
            <td>{user.name}</td>
            <td>{user.email}</td>
          </tr>
        ))}
      </table>

      <Pagination
        page={page}
        onChange={onPageChange}
      />

      <button onClick={onRefresh}>Refresh</button>
    </div>
  );
}
```

## ❌ Wrong Pattern: UI Component Makes API Calls

### ❌ WRONG: UI Component (`src/ui/users/user-table.tsx`)

```tsx
'use client';

import { useQuery } from '@tanstack/react-query'; // ❌ WRONG!
import { apiClient } from '@/lib/api/client';

export function UserTable() {
  // ❌ WRONG: UI component should NOT use React Query
  const { data, isLoading } = useQuery({
    queryKey: ['users'],
    queryFn: () => apiClient.get('/users'),
  });

  // ❌ WRONG: This makes the component not reusable
  // ❌ WRONG: Can't use this component with different data
  // ❌ WRONG: Hard to test in isolation

  return <div>...</div>;
}
```

## Key Principles

### ✅ DO

1. **Page Components**: Create hooks, pass props
   ```tsx
   const { data, actions } = useMyHook();
   return <MyComponent data={data} onAction={actions.doSomething} />;
   ```

2. **Hooks**: Manage all state and API calls
   ```tsx
   const [state, setState] = useState();
   const { data } = useQuery(...);
   return { state, setState, data };
   ```

3. **UI Components**: Accept props, manage local UI state only
   ```tsx
   function MyComponent({ data, onAction }: Props) {
     const [isOpen, setIsOpen] = useState(false); // ✅ OK: UI state
     return <div>...</div>;
   }
   ```

### ❌ DON'T

1. **Page Components**: Don't use `useState`/`useEffect` directly
   ```tsx
   // ❌ WRONG
   const [data, setData] = useState();
   useEffect(() => { ... }, []);
   ```

2. **UI Components**: Don't use React Query or make API calls
   ```tsx
   // ❌ WRONG
   const { data } = useQuery(...);
   const result = await apiClient.get(...);
   ```

## Benefits of This Pattern

1. **Reusability**: UI components can be reused with different data sources
2. **Testability**: Components can be tested with mock props
3. **Separation of Concerns**: Data fetching logic is centralized in hooks
4. **Performance**: React Query caching works at the hook level
5. **Maintainability**: Easy to find and update data fetching logic
