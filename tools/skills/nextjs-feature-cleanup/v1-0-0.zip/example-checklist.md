# Example: Contact Submissions Feature Removal Checklist

**Generated**: 2025-11-04 10:45:00
**Feature**: contact-submissions
**Total Files**: 12
**Status**: Needs review

## Summary

The contact-submissions feature handles form submissions from the public contact form. It includes API endpoints, database storage via repositories, admin UI for viewing submissions, and email notification capabilities.

## Pre-Removal Verification

- [ ] All developers are aware of the feature removal
- [ ] Feature is confirmed to be deprecated/unused
- [ ] Backup/export any necessary data from contact_submissions table
- [ ] Document reason for removal in project changelog

## Files to Remove

### Domain Layer

- [ ] `src/domain/entities/contact-submission.types.ts` - Contact submission entity types
  - Exported symbols: ContactSubmission, ContactSubmissionStatus, CreateContactSubmissionDTO
  - Used by: None (isolated to feature)

- [ ] `src/domain/use-cases/list-contact-submissions.use-case.ts` - Use case for listing submissions
  - Exported symbols: ListContactSubmissionsUseCase
  - Used by: src/app/api/contact-submissions/route.ts

- [ ] `src/domain/use-cases/update-contact-submission-status.use-case.ts` - Use case for status updates
  - Exported symbols: UpdateContactSubmissionStatusUseCase
  - Used by: src/app/api/contact-submissions/[id]/route.ts

### Infrastructure Layer

- [ ] `src/infrastructure/repositories/contact-submissions.repository.ts` - Database access
  - Exported symbols: ContactSubmissionsRepository
  - Used by: API route handlers

### Hooks Layer

- [ ] `src/hooks/use-contact-submissions.ts` - Data fetching hook
  - Exported symbols: useContactSubmissions, useUpdateContactSubmissionStatus
  - Used by: src/app/[locale]/admin/contact-submissions/page.tsx

### App Layer (Routes & API)

- [ ] `src/app/[locale]/admin/contact-submissions/` - Admin page directory
  - Route: /admin/contact-submissions
  - Dependencies: use-contact-submissions hook

- [ ] `src/app/api/contact-submissions/route.ts` - List API endpoint
  - Route: GET /api/contact-submissions
  - Dependencies: ListContactSubmissionsUseCase

- [ ] `src/app/api/contact-submissions/[id]/route.ts` - Update API endpoint
  - Route: PATCH /api/contact-submissions/:id
  - Dependencies: UpdateContactSubmissionStatusUseCase

### UI Layer

- [ ] `src/ui/contact-submissions/contact-submissions-table.tsx` - Table component
  - Used by: Admin contact-submissions page only

- [ ] `src/ui/contact-submissions/contact-submission-status-badge.tsx` - Status badge
  - Used by: contact-submissions-table.tsx only

### Internationalization

- [ ] `messages/en/contact-submissions.json`
- [ ] `messages/th/contact-submissions.json`
- [ ] Remove registration from `src/lib/i18n/request.ts` (line 42)

## Dependencies to Remove

### Safe to Remove (Only used by this feature)

No unique dependencies - feature uses standard project stack.

### Needs Manual Review

None identified.

## Configuration Updates

- [ ] Update sidebar navigation in `src/ui/layout/admin-sidebar.tsx` - Remove contact submissions link
- [ ] Update `.env.example` if CONTACT_FORM_EMAIL env var is only used here
- [ ] Check database migrations - may need to drop contact_submissions table

## Shared Dependencies (CANNOT REMOVE)

None - This feature is completely isolated.

## Post-Removal Verification

- [ ] Run `pnpm lint` - All passing
- [ ] Run `pnpm type-check` - No errors
- [ ] Run `pnpm test` - All passing
- [ ] Run `pnpm build` - Successful build
- [ ] Test application locally - No console errors
- [ ] Check admin sidebar navigation works
- [ ] Verify no broken imports
- [ ] Review git diff for unintended changes

## Rollback Plan

If issues arise after removal:

1. Revert commit: `git revert <commit-hash>`
2. Restore files from: `git checkout <commit-hash> -- src/`
3. Reinstall dependencies: `pnpm install`

## Notes

- This feature stores user contact form data - ensure data is backed up before removal
- Email notifications may need to be disabled in production before removing code
- Consider keeping database table for historical data even after removing UI/API

---

**Removal Difficulty**: Easy
**Estimated Time**: 2-3 hours
**Reviewer**: Tech Lead
