# Feature Cleanup Quick Reference

## Common File Patterns by Layer

### Domain Layer Patterns

```
src/domain/entities/{feature-name}.types.ts
src/domain/entities/{feature-name}/
src/domain/use-cases/{feature-name}-*.use-case.ts
src/domain/use-cases/{feature-name}/
src/domain/errors/{feature-name}-*.ts
```

**Example**: For "project" feature:
- `src/domain/entities/project.types.ts`
- `src/domain/use-cases/create-project.use-case.ts`
- `src/domain/use-cases/list-projects.use-case.ts`

### Infrastructure Layer Patterns

```
src/infrastructure/repositories/{feature-name}.repository.ts
src/infrastructure/repositories/{feature-name}s.repository.ts
src/infrastructure/server/actions/{feature-name}-*.ts
src/infrastructure/http/{feature-name}/
```

**Example**: For "facility" feature:
- `src/infrastructure/repositories/facilities.repository.ts`
- `src/infrastructure/server/actions/facility-actions.ts`

### Hooks Layer Patterns

```
src/hooks/use-{feature-name}.ts
src/hooks/use-{feature-name}s.ts
src/hooks/{feature-name}/
```

**Example**: For "maintenance-request" feature:
- `src/hooks/use-maintenance-requests.ts`
- `src/hooks/use-maintenance-request.ts` (singular for single item)

### App Layer Patterns

```
src/app/[locale]/{feature-name}/
src/app/[locale]/admin/{feature-name}/
src/app/api/{feature-name}/
src/app/api/{feature-name}s/
```

**Example**: For "users" feature:
- `src/app/[locale]/admin/users/page.tsx`
- `src/app/api/users/route.ts`
- `src/app/api/users/[id]/route.ts`

### UI Layer Patterns

```
src/ui/{feature-name}/
src/ui/components/{feature-name}-*.tsx
src/ui/forms/{feature-name}-*.tsx
src/ui/tables/{feature-name}-*.tsx
```

**Example**: For "category" feature:
- `src/ui/category/category-list.tsx`
- `src/ui/category/category-form.tsx`

### i18n Patterns

```
messages/en/{feature-name}.json
messages/th/{feature-name}.json
```

**Registration**:
```typescript
// In src/lib/i18n/request.ts
import featureMessages from './messages/en/{feature-name}.json';
```

## Search Commands

### Find All Feature Files

```bash
# Case-insensitive search for feature files
find src/ -type f -iname "*{feature}*"

# Using fd (faster alternative)
fd -i "{feature}" src/
```

### Find Import References

```bash
# Find all files importing from a specific file
grep -r "from.*/{filename}" src/ --exclude="{filename}"
grep -r "import.*{filename}" src/ --exclude="{filename}"

# Find dynamic imports
grep -r "import(.*{filename}" src/
```

### Find Symbol Usage

```bash
# Find usage of a type/interface
grep -r "\\b{TypeName}\\b" src/

# Find usage of a function/hook
grep -r "\\b{functionName}\\(" src/

# Find usage in import statements only
grep -r "import.*{SymbolName}" src/
```

### Find Dependency Usage

```bash
# Find all imports from a package
grep -r "from ['\"]${package}" src/

# Count occurrences
grep -r "from ['\"]${package}" src/ | wc -l
```

## Glob Tool Patterns

```typescript
// Domain entities
pattern: "src/domain/entities/*{feature}*.ts"

// All use cases
pattern: "src/domain/use-cases/**/*{feature}*.ts"

// Repositories
pattern: "src/infrastructure/repositories/*{feature}*.ts"

// Hooks
pattern: "src/hooks/**/*{feature}*.ts"

// Pages (all locales)
pattern: "src/app/**/\\[locale\\]/**/{feature}/**"

// API routes
pattern: "src/app/api/**/{feature}*/**"

// UI components
pattern: "src/ui/**/*{feature}*"

// Tests
pattern: "src/**/*{feature}*.test.ts"

// i18n
pattern: "messages/**/{feature}.json"
```

## Grep Tool Patterns

```typescript
// Find imports of a file (without extension)
{
  pattern: "from.*/{filename-without-ext}",
  glob: "**/*.{ts,tsx}",
  output_mode: "files_with_matches"
}

// Find usage of a type
{
  pattern: "\\b{TypeName}\\b",
  glob: "**/*.{ts,tsx}",
  output_mode: "content",
  "-n": true  // Show line numbers
}

// Find hook usage
{
  pattern: "use{FeatureName}\\(",
  glob: "**/*.{ts,tsx}",
  output_mode: "content"
}

// Find component usage
{
  pattern: "<{ComponentName}",
  glob: "**/*.tsx",
  output_mode: "files_with_matches"
}
```

## Common Pitfalls

### 1. Pluralization Variations

Features may have both singular and plural forms:
- `user.types.ts` vs `users.repository.ts`
- `use-category.ts` vs `use-categories.ts`
- `/api/project/` vs `/api/projects/`

**Solution**: Search for both variations.

### 2. Kebab-case vs PascalCase

Files use kebab-case, symbols use PascalCase:
- File: `contact-submission.types.ts`
- Type: `ContactSubmission`
- Hook: `useContactSubmissions`

**Solution**: Convert between cases when searching.

### 3. Shared Utilities

Some files appear feature-specific but are used across features:
- `use-auth.ts` - Used everywhere
- `common.types.ts` - Shared types
- `api-client.ts` - Shared HTTP client

**Solution**: Always verify cross-references before marking for removal.

### 4. Nested Features

Some features have sub-features:
- `terms-conditions/` main feature
- `terms-conditions/version-history/` sub-feature
- `use-terms-conditions-editor.ts` related hook

**Solution**: Map the entire feature tree before removal.

### 5. Implicit Dependencies

Some dependencies are not directly imported:
- Environment variables referenced in config
- Database migrations
- API endpoint contracts used by mobile apps

**Solution**: Review feature documentation and related systems.

## Verification Checklist

Before generating removal checklist, verify:

- [ ] Searched for both singular and plural forms
- [ ] Checked both kebab-case files and PascalCase symbols
- [ ] Searched in all layers (domain, infrastructure, hooks, app, ui)
- [ ] Checked i18n files in all locales
- [ ] Verified no cross-feature imports
- [ ] Identified feature-specific dependencies
- [ ] Checked for related database migrations
- [ ] Reviewed environment variables
- [ ] Checked navigation/menu references
- [ ] Looked for feature flags or config

## Step-by-Step Discovery Process

### Step 1: Initial Discovery
```bash
# Find all files with feature name
find src/ -type f -iname "*{feature}*"
```

### Step 2: Symbol Extraction
For each file found:
1. Read the file
2. Extract exported symbols (types, functions, classes)
3. Note if symbols follow different naming convention

### Step 3: Cross-Reference Check
For each file and symbol:
```bash
# Check file usage
grep -r "from.*{filename}" src/ --exclude="{filename}"

# Check symbol usage
grep -r "\\b{SymbolName}\\b" src/
```

### Step 4: Dependency Analysis
```bash
# Extract unique imports from feature files
grep -h "^import.*from" {feature-files} | sort -u

# For each dependency, check usage
grep -r "from ['\"]${package}" src/ | wc -l
```

### Step 5: Configuration Scan
- Read package.json for dependencies
- Read tsconfig.json for path aliases
- Read next.config.js for feature config
- Read .env.example for env vars
- Read navigation components for links

## Size Estimation

**Small Feature** (1-2 hours):
- 3-8 files across 3-4 layers
- No unique dependencies
- No cross-feature usage
- Example: Simple CRUD feature

**Medium Feature** (3-5 hours):
- 9-20 files across all layers
- 1-3 feature-specific dependencies
- Minimal cross-feature usage
- Example: Feature with complex UI

**Large Feature** (1-2 days):
- 20+ files across all layers
- Multiple unique dependencies
- Significant cross-feature usage
- Requires refactoring shared code
- Example: Core business feature

## Pro Tips

1. **Start with UI layer**: Least dependent, safest to remove first
2. **Work backwards**: UI → App → Hooks → Infrastructure → Domain
3. **Test incrementally**: Run tests after each layer removal
4. **Keep git clean**: Commit each layer removal separately
5. **Document surprises**: Note any unexpected dependencies in checklist
6. **Use feature branch**: Never remove features directly on main
7. **Pair review**: Have another developer review the analysis
8. **Consider alternatives**: Maybe archive instead of delete
