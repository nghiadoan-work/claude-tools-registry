---
name: nextjs-feature-cleanup
description: Systematically removes features from the Residence Backoffice project. Scans all layers (domain, infrastructure, hooks, app, UI) to find related code, validates no cross-feature usage, identifies unused dependencies, and generates a comprehensive removal checklist for safe feature deletion.
---

# Feature Cleanup - Residence Backoffice

## Overview

This skill systematically removes one or multiple features from the project while ensuring:
- All related code across all layers is identified
- Code is not reused in non-related features
- Unused dependencies are identified for removal
- A comprehensive removal checklist is generated for each feature

## Feature Cleanup Process

### 1. Feature Identification Phase

For each feature to remove, identify files across all Clean Architecture layers:

**Domain Layer** (`src/domain/`):
- Entity types: `{feature-name}.types.ts`
- Use cases: `src/domain/use-cases/{feature-name}-*.use-case.ts`
- Related domain errors: `src/domain/errors/{feature-name}-*.ts`
- DTOs: Files containing `{feature-name}DTO` or similar

**Infrastructure Layer** (`src/infrastructure/`):
- Repositories: `{feature-name}.repository.ts` or `{feature-name}s.repository.ts`
- Server actions: `src/infrastructure/server/actions/{feature-name}-*.ts`
- API utilities: Files in infrastructure specific to this feature

**Hooks Layer** (`src/hooks/`):
- Custom hooks: `use-{feature-name}.ts` or `use-{feature-name}s.ts`
- Feature-specific hook folders: `src/hooks/{feature-name}/`

**App Layer** (`src/app/`):
- Pages: `src/app/[locale]/{feature-name}/` or similar
- API routes: `src/app/api/{feature-name}/` or `src/app/api/{feature-name}s/`
- Server components specific to feature

**UI Layer** (`src/ui/`):
- Components: `src/ui/{feature-name}/` or components with `{feature-name}` prefix
- Shared components only used by this feature

**i18n** (`messages/`):
- Translation files: Search for `{feature-name}.json` in all locale folders
- Translation keys: References to `{feature-name}` namespace in translation files

**Types** (`src/types/`):
- Shared types related to feature

### 2. Cross-Reference Analysis Phase

For EACH identified file, search the codebase to verify it's not used elsewhere:

**Import Analysis**:
```bash
# Search for imports of the file (excluding the file itself)
grep -r "from.*{filename}" src/ --exclude="{filename}"
grep -r "import.*{filename}" src/ --exclude="{filename}"
```

**Symbol Analysis**:
For each exported symbol (type, function, class) in the file:
```bash
# Search for usage of the symbol
grep -r "{SymbolName}" src/ --exclude="{filename}"
```

**Critical Check**:
- If a file/symbol is used OUTSIDE the feature being removed, mark it as "CANNOT REMOVE - SHARED DEPENDENCY"
- Document which other features depend on it
- Consider extracting to a shared module if appropriate

### 3. Dependency Analysis Phase

Identify dependencies that may become unused after feature removal:

**Step 1: Find Feature-Specific Dependencies**
- Search for unique imports in all feature files
- Common feature-specific dependencies might include:
  - Specific UI libraries (e.g., tiptap, lexical for rich text)
  - Specialized utilities
  - Feature-specific SDKs

**Step 2: Verify Dependency Usage**
For each potential dependency:
```bash
# Search for usage across codebase
grep -r "from '{package-name}'" src/
grep -r "import.*{package-name}" src/
```

**Step 3: Check package.json**
- Read `package.json` to get full dependency list
- Cross-reference with identified unused dependencies
- Separate into categories:
  - **Safe to remove**: Only used by removed feature
  - **Potentially unused**: Used sparingly, needs manual review
  - **Keep**: Used by other features

### 4. Related Configuration Analysis

Check for feature-specific configuration in:

**ESLint Configuration**:
- `.eslintrc.js` or `.eslintrc.json`
- Feature-specific rules or ignores

**TypeScript Configuration**:
- `tsconfig.json`
- Path aliases for the feature

**Next.js Configuration**:
- `next.config.js`
- Feature-specific rewrites, redirects, or headers

**Environment Variables**:
- `.env.example`
- Feature-specific environment variables

**Test Configuration**:
- `vitest.config.ts`
- Feature-specific test setup

### 5. Checklist Generation Phase

For EACH feature, generate a markdown checklist file:

**File Location**: `feature-remove-task-list/{feature-name}-remove-task-check-list.md`

**Checklist Structure**:

```markdown
# {Feature Name} Removal Checklist

**Generated**: {timestamp}
**Feature**: {feature-name}
**Total Files**: {count}
**Status**: Ready for removal / Has dependencies / Needs review

## Summary

Brief description of the feature being removed and scope of changes.

## Pre-Removal Verification

- [ ] All developers are aware of the feature removal
- [ ] Feature is confirmed to be deprecated/unused
- [ ] Backup/export any necessary data
- [ ] Document reason for removal in project changelog

## Files to Remove

### Domain Layer

- [ ] `src/domain/entities/{file}` - {description}
  - Exported symbols: {list}
  - Used by: {list or "None"}

- [ ] `src/domain/use-cases/{file}` - {description}
  - Exported symbols: {list}
  - Used by: {list or "None"}

### Infrastructure Layer

- [ ] `src/infrastructure/{path}/{file}` - {description}
  - Exported symbols: {list}
  - Used by: {list or "None"}

### Hooks Layer

- [ ] `src/hooks/{file}` - {description}
  - Exported symbols: {list}
  - Used by: {list or "None"}

### App Layer (Routes & API)

- [ ] `src/app/{path}` - {description}
  - Route: {route}
  - Dependencies: {list}

### UI Layer

- [ ] `src/ui/{path}/{file}` - {description}
  - Used by: {list or "None"}

### Internationalization

- [ ] `messages/en/{feature}.json`
- [ ] `messages/th/{feature}.json`
- [ ] Remove registration from `src/lib/i18n/request.ts`

## Dependencies to Remove

### Safe to Remove (Only used by this feature)

- [ ] `{package-name}` - Version: {version}
  - Used in: {list of files}
  - Remove command: `pnpm remove {package-name}`

### Needs Manual Review

- [ ] `{package-name}` - Version: {version}
  - Used in: {list of files}
  - Reason: {why needs review}

## Configuration Updates

- [ ] Update `.eslintrc.js` if feature-specific rules exist
- [ ] Update `tsconfig.json` if feature-specific paths exist
- [ ] Update `next.config.js` if feature-specific config exists
- [ ] Update `.env.example` if feature-specific env vars exist
- [ ] Remove from navigation menus/sidebars if applicable

## Shared Dependencies (CANNOT REMOVE)

### Files with Cross-Feature Usage

- **File**: `{path}`
  - **Used by features**: {list}
  - **Action**: DO NOT REMOVE - Extract shared code if needed
  - **Symbols**: {list}

## Post-Removal Verification

- [ ] Run `pnpm lint` - All passing
- [ ] Run `pnpm type-check` - No errors
- [ ] Run `pnpm test` - All passing
- [ ] Run `pnpm build` - Successful build
- [ ] Test application locally - No console errors
- [ ] Check all navigation links work
- [ ] Verify no broken imports
- [ ] Review git diff for unintended changes

## Rollback Plan

If issues arise after removal:

1. Revert commit: `git revert {commit-hash}`
2. Restore files from: `git checkout {commit-hash} -- {file-path}`
3. Reinstall dependencies: `pnpm install`

## Notes

{Any additional notes, warnings, or context about this removal}

---

**Removal Difficulty**: Easy / Medium / Complex
**Estimated Time**: {estimate}
**Reviewer**: {who should review this}
```

## Execution Guidelines

### When to Use This Skill

Use this skill when:
- Removing deprecated features
- Cleaning up unused/experimental code
- Refactoring to consolidate features
- Decommissioning legacy functionality

### Safety Checks

**CRITICAL - Before Any Deletion**:

1. **Confirm with stakeholders** feature is truly deprecated
2. **Back up any production data** related to feature
3. **Create a feature branch** for the removal
4. **Generate checklist first**, review before deletion
5. **Remove files incrementally**, test after each layer

### Recommended Deletion Order

Remove files in this order to minimize breakage:

1. **UI Components** - Lowest dependency level
2. **App Pages/Routes** - Next level up
3. **Custom Hooks** - State management layer
4. **Infrastructure** - Data access layer
5. **Domain Use Cases** - Business logic
6. **Domain Entities** - Last (most depended upon)
7. **Dependencies** - After all code removed
8. **i18n files** - After confirming no references

### Anti-Patterns to Avoid

**❌ Don't**:
- Delete files without checking cross-references
- Remove dependencies without verifying unused
- Skip generating the checklist (critical for safety)
- Delete all at once without testing incrementally
- Ignore TypeScript errors during removal
- Remove shared utilities without migrating

**✅ Do**:
- Generate comprehensive checklist first
- Verify each file is not imported elsewhere
- Test after each major removal step
- Keep stakeholders informed
- Document reason for removal
- Update related documentation

## Tool Usage

### Required Tools for Analysis

**File Search**:
```bash
# Find all files related to feature
find src/ -type f -name "*{feature}*"
```

**Content Search**:
```bash
# Find all imports of a specific file
grep -r "from.*{filename}" src/
grep -r "import.*{filename}" src/

# Find all usages of a symbol
grep -r "{SymbolName}" src/
```

**Dependency Usage**:
```bash
# Check dependency usage across codebase
grep -r "from '{package}'" src/
```

### Glob Patterns for Discovery

Use Glob tool with these patterns:

- Domain entities: `src/domain/entities/*{feature}*.ts`
- Domain use cases: `src/domain/use-cases/*{feature}*.ts`
- Repositories: `src/infrastructure/**/*{feature}*.ts`
- Hooks: `src/hooks/*{feature}*.ts`
- Pages: `src/app/**/\(locale\)/**/{feature}/**`
- API routes: `src/app/api/**/{feature}/**`
- UI components: `src/ui/**/*{feature}*`
- i18n: `messages/**/{feature}.json`

### Grep Patterns for Cross-Reference

Use Grep tool with these patterns:

```typescript
// Find imports of a specific file
pattern: "from.*{filename-without-extension}"
glob: "**/*.{ts,tsx}"

// Find usage of a type/interface
pattern: "\\b{TypeName}\\b"
glob: "**/*.{ts,tsx}"

// Find usage of a function/hook
pattern: "\\b{functionName}\\("
glob: "**/*.{ts,tsx}"
```

## Multiple Feature Removal

When removing multiple features:

1. **Analyze each feature independently** first
2. **Identify shared dependencies** between features being removed
3. **Generate separate checklists** for each feature
4. **Create a master checklist** that coordinates all removals
5. **Remove in logical order** (dependencies first, dependents last)

## Output Deliverables

For each feature removal, deliver:

1. **Removal Checklist**: `feature-remove-task-list/{feature-name}-remove-task-check-list.md`
2. **Analysis Summary**: Report of cross-references and blockers
3. **Dependency Report**: List of safe-to-remove vs keep dependencies
4. **Risk Assessment**: Complexity rating and potential issues

## Example Workflow

```bash
# 1. User requests removal
"Remove the contact-submissions feature"

# 2. Identify all files
- Find files matching "*contact-submission*" across all layers
- Total: 12 files identified

# 3. Analyze cross-references
- Check each file for imports from other features
- Found: 2 files used by maintenance-requests feature

# 4. Analyze dependencies
- No unique dependencies (uses standard stack)

# 5. Generate checklist
- Create contact-submissions-remove-task-check-list.md
- Mark 2 files as "SHARED - NEEDS REVIEW"
- List 10 files as safe to remove

# 6. Present to user
- Summary of findings
- Link to checklist
- Highlight shared dependencies
- Provide recommendation
```

## Success Criteria

A successful feature cleanup:

✅ All related files identified across all layers
✅ Cross-references analyzed and documented
✅ No unintended deletion of shared code
✅ Unused dependencies identified
✅ Comprehensive checklist generated
✅ All tests pass after removal
✅ No TypeScript errors
✅ Application builds successfully
✅ No broken links or navigation

## Notes

- **Thoroughness over speed**: Better to analyze completely than miss shared code
- **Communication is key**: Keep stakeholders informed of progress
- **Test incrementally**: Don't remove everything at once
- **Document decisions**: Why this feature was removed
- **Consider migration**: Some features may need data migration before removal
