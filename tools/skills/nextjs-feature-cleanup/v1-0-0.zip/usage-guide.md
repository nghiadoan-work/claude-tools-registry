# Feature Cleanup Skill - Usage Guide

## How to Use This Skill

### Basic Usage

To analyze and generate a removal checklist for a single feature:

```
Use the feature-cleanup skill to remove the contact-submissions feature
```

To analyze multiple features:

```
Use the feature-cleanup skill to remove the following features:
- contact-submissions
- legacy-reports
- experimental-dashboard
```

### What the Skill Does

1. **Discovery**: Scans entire codebase for feature-related files
2. **Analysis**: Checks cross-references and shared dependencies
3. **Validation**: Identifies safe-to-remove vs. shared code
4. **Documentation**: Generates comprehensive removal checklist
5. **Reporting**: Provides summary with risk assessment

### Expected Outputs

After running the skill, you'll receive:

1. **Analysis Summary** - Console output with:
   - Total files found
   - Cross-feature dependencies
   - Risk assessment
   - Estimated removal time

2. **Removal Checklist** - Markdown file in `feature-remove-task-list/`:
   - Complete file inventory
   - Verification steps
   - Dependencies to remove
   - Post-removal validation

3. **Recommendations** - What to do next:
   - Safe to proceed
   - Needs review
   - Blocked by dependencies

## Step-by-Step Workflow

### Phase 1: Analysis (Automated by Skill)

1. **Invoke the skill**:
   ```
   Use feature-cleanup skill for {feature-name}
   ```

2. **Skill performs**:
   - File discovery across all layers
   - Import/usage analysis
   - Dependency checking
   - Cross-reference validation

3. **Review output**:
   - Check analysis summary
   - Review identified files
   - Note any warnings about shared code

### Phase 2: Checklist Review (Manual)

1. **Open generated checklist**:
   ```
   feature-remove-task-list/{feature-name}-remove-task-check-list.md
   ```

2. **Verify accuracy**:
   - Confirm all listed files are correct
   - Review shared dependencies section
   - Check if any files were missed

3. **Assess risk**:
   - Read "Removal Difficulty" rating
   - Review "Shared Dependencies" section
   - Consider impact on other features

4. **Get approval**:
   - Share checklist with team
   - Confirm with stakeholders
   - Document in project management tool

### Phase 3: Pre-Removal Preparation (Manual)

1. **Create feature branch**:
   ```bash
   git checkout -b remove-{feature-name}
   ```

2. **Back up data** (if applicable):
   - Export database tables
   - Archive user data
   - Document API endpoints used externally

3. **Update documentation**:
   - Note feature deprecation
   - Update README if needed
   - Add to CHANGELOG

4. **Communicate**:
   - Notify team of upcoming removal
   - Coordinate with dependent teams
   - Schedule removal window

### Phase 4: Execution (Manual)

Follow the checklist order:

1. **Start with UI components**:
   ```bash
   git rm src/ui/{feature-name}/
   ```

2. **Remove app pages and API routes**:
   ```bash
   git rm -r src/app/[locale]/{feature-name}/
   git rm -r src/app/api/{feature-name}/
   ```

3. **Remove hooks**:
   ```bash
   git rm src/hooks/use-{feature-name}.ts
   ```

4. **Remove infrastructure**:
   ```bash
   git rm src/infrastructure/repositories/{feature-name}.repository.ts
   ```

5. **Remove domain layer**:
   ```bash
   git rm src/domain/use-cases/{feature-name}-*.use-case.ts
   git rm src/domain/entities/{feature-name}.types.ts
   ```

6. **Remove i18n files**:
   ```bash
   git rm messages/en/{feature-name}.json
   git rm messages/th/{feature-name}.json
   ```

7. **Update i18n registration**:
   ```typescript
   // Edit src/lib/i18n/request.ts
   // Remove import and registration for {feature-name}
   ```

8. **Remove dependencies**:
   ```bash
   pnpm remove {package-name}
   ```

9. **Test after each major step**:
   ```bash
   pnpm type-check
   pnpm lint
   ```

### Phase 5: Validation (Manual)

Run all verification steps from checklist:

```bash
# Type checking
pnpm type-check

# Linting
pnpm lint

# Tests
pnpm test

# Build
pnpm build

# Local testing
pnpm dev
# Manually test application
```

### Phase 6: Finalization (Manual)

1. **Review changes**:
   ```bash
   git status
   git diff --staged
   ```

2. **Commit removal**:
   ```bash
   git add .
   git commit -m "feat: remove {feature-name} feature

   - Removed all {feature-name} related files from domain, infrastructure, hooks, app, and UI layers
   - Removed {feature-name} i18n files
   - Removed unused dependencies: {list}
   - Updated navigation and configuration

   Fixes #123

   🤖 Generated with [Claude Code](https://claude.com/claude-code)

   Co-Authored-By: Claude <noreply@anthropic.com>"
   ```

3. **Create PR**:
   ```bash
   git push -u origin remove-{feature-name}
   gh pr create --title "Remove {feature-name} feature" --body "See commit message for details"
   ```

4. **Archive checklist** (optional):
   ```bash
   git mv feature-remove-task-list/{feature-name}-remove-task-check-list.md \
          feature-remove-task-list/archive/
   ```

## Common Scenarios

### Scenario 1: Simple Feature Removal

**Situation**: Removing a small, isolated feature with no dependencies.

**Example**:
```
Remove the demo-widget feature
```

**Expected Result**:
- 5-8 files identified
- No shared dependencies
- Checklist marked as "Easy" difficulty
- 1-2 hours estimated time

**Next Steps**:
1. Review checklist
2. Execute removal following checklist order
3. Run validation steps
4. Commit and create PR

### Scenario 2: Feature with Shared Code

**Situation**: Feature has some components used by other features.

**Example**:
```
Remove the legacy-dashboard feature
```

**Expected Result**:
- 15 files identified
- 3 files marked as "SHARED - CANNOT REMOVE"
- Checklist marked as "Medium" difficulty
- Requires refactoring shared components

**Next Steps**:
1. Review shared dependencies
2. Extract shared code to common location
3. Update imports in dependent features
4. Re-run analysis to verify extraction
5. Proceed with removal

### Scenario 3: Multiple Related Features

**Situation**: Removing multiple features that depend on each other.

**Example**:
```
Remove the following features:
- old-reporting
- report-templates
- report-scheduler
```

**Expected Result**:
- Separate checklist for each feature
- Analysis of inter-feature dependencies
- Recommended removal order

**Next Steps**:
1. Review all three checklists
2. Identify shared code between features
3. Remove in recommended order
4. Test after each feature removal

### Scenario 4: Feature with External Dependencies

**Situation**: Feature integrates with external services or has unique npm packages.

**Example**:
```
Remove the payment-processing feature
```

**Expected Result**:
- Multiple unique dependencies identified (stripe, payment SDKs)
- Database migration considerations
- API contract implications
- Marked as "Complex" difficulty

**Next Steps**:
1. Coordinate with teams using the API
2. Plan data migration
3. Schedule deprecation period
4. Remove external service configurations
5. Proceed with code removal

## Troubleshooting

### Issue: Skill misses some files

**Cause**: Files don't follow standard naming conventions.

**Solution**:
1. Manually search for additional files:
   ```bash
   grep -r "{feature-keyword}" src/
   ```
2. Add findings to checklist manually
3. Consider renaming files to follow conventions in future

### Issue: Too many shared dependencies

**Cause**: Feature wasn't properly isolated.

**Solution**:
1. Extract shared code to `src/ui/shared/` or similar
2. Create new hooks for shared functionality
3. Update dependent features
4. Re-run analysis after extraction

### Issue: Tests fail after removal

**Cause**: Missed dependency or shared test utilities.

**Solution**:
1. Read test output carefully
2. Identify missing imports
3. Check if test fixtures/mocks were feature-specific
4. Update or remove affected tests

### Issue: Type errors after removal

**Cause**: Types were used elsewhere but not detected.

**Solution**:
1. Run `pnpm type-check` for full error list
2. Search for the missing type
3. Either keep the type or find replacement
4. Update imports across codebase

### Issue: Build succeeds but runtime errors

**Cause**: Dynamic imports or runtime dependencies.

**Solution**:
1. Check browser console for errors
2. Look for dynamic imports: `import()`
3. Check for string-based references
4. Review route handlers and API endpoints

## Best Practices

### ✅ Do

- **Review checklist thoroughly** before starting removal
- **Create feature branch** for the removal work
- **Test incrementally** after each layer removed
- **Commit in logical chunks** (one layer at a time)
- **Document reason** for removal in commit message
- **Back up data** before removing data-related features
- **Coordinate with team** about feature removal timing
- **Keep stakeholders informed** of progress

### ❌ Don't

- **Rush the analysis** - thoroughness prevents bugs
- **Remove all files at once** - incremental is safer
- **Skip validation steps** - tests catch issues early
- **Forget about i18n** - orphaned translations waste space
- **Ignore shared code** - causes breakage elsewhere
- **Skip git commits** - makes rollback harder
- **Remove without approval** - coordinate with stakeholders

## Integration with PR Workflow

After feature removal, use the `pr-code-review` skill to validate:

```bash
# After creating PR
Use pr-code-review skill to review the feature removal PR
```

The skill will verify:
- No orphaned imports
- No broken tests
- Proper layer separation maintained
- No accidental removal of shared code

## Metrics to Track

After each feature removal:

- **Files removed**: {count}
- **Lines of code removed**: `git diff --stat`
- **Dependencies removed**: {count}
- **Build time improvement**: Before vs. After
- **Time taken**: Actual vs. estimated
- **Issues encountered**: Document for future reference

## Getting Help

If you encounter issues or have questions:

1. **Review the quick-reference.md** for search patterns
2. **Check example-checklist.md** for reference format
3. **Ask team members** who worked on the feature
4. **Review git history** of the feature files:
   ```bash
   git log --follow src/path/to/{feature-file}
   ```
5. **Update this usage guide** with your learnings

## Feedback and Improvements

After using this skill, consider:

- Did the analysis catch all files?
- Were cross-references accurate?
- Was the checklist helpful?
- What could be improved?

Document feedback in:
```
feature-remove-task-list/_feedback.md
```

This helps improve the skill for future removals!
