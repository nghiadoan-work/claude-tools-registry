# Feature Cleanup Skill

Systematically remove features from the Residence Backoffice project with comprehensive analysis and safety checks.

## Quick Start

### Single Feature Removal
```
Use feature-cleanup skill to remove the contact-submissions feature
```

### Multiple Features Removal
```
Use feature-cleanup skill to remove these features:
- contact-submissions
- legacy-reports
- experimental-dashboard
```

## What This Skill Does

1. **🔍 Discovery**: Scans all Clean Architecture layers for feature files
   - Domain (entities, use cases)
   - Infrastructure (repositories, actions)
   - Hooks (custom hooks)
   - App (pages, API routes)
   - UI (components)
   - i18n (translations)

2. **🔗 Cross-Reference Analysis**: Validates no code is shared with other features
   - Checks imports across entire codebase
   - Identifies symbol usage
   - Flags shared dependencies

3. **📦 Dependency Analysis**: Identifies unused npm packages
   - Feature-specific dependencies
   - Safe to remove
   - Requires manual review

4. **📋 Checklist Generation**: Creates comprehensive removal task list
   - Complete file inventory
   - Step-by-step instructions
   - Verification steps
   - Rollback procedures

## Output Location

Generated checklists are saved to:
```
feature-remove-task-list/{feature-name}-remove-task-check-list.md
```

## Documentation

- **SKILL.md** - Complete skill specification and process
- **usage-guide.md** - Step-by-step workflow and scenarios
- **quick-reference.md** - File patterns and search commands
- **example-checklist.md** - Sample output for reference

## Safety Features

✅ Identifies shared code that CANNOT be removed
✅ Validates no cross-feature dependencies
✅ Lists all verification steps
✅ Provides rollback procedures
✅ Estimates removal difficulty and time

## Typical Workflow

1. **Invoke skill** → Analyze feature
2. **Review checklist** → Verify accuracy
3. **Get approval** → Team/stakeholder sign-off
4. **Execute removal** → Follow checklist
5. **Run verification** → Tests, linting, build
6. **Create PR** → Review and merge

## Example Output

```markdown
# Contact Submissions Removal Checklist

**Status**: Ready for removal
**Total Files**: 12
**Difficulty**: Easy
**Estimated Time**: 2-3 hours

## Files to Remove

### Domain Layer
- [ ] src/domain/entities/contact-submission.types.ts
- [ ] src/domain/use-cases/list-contact-submissions.use-case.ts

### Infrastructure Layer
- [ ] src/infrastructure/repositories/contact-submissions.repository.ts

### Hooks Layer
- [ ] src/hooks/use-contact-submissions.ts

...

## Post-Removal Verification
- [ ] pnpm lint - passing
- [ ] pnpm type-check - no errors
- [ ] pnpm build - successful
```

## When to Use

- Removing deprecated features
- Cleaning up experimental code
- Consolidating features
- Decommissioning legacy functionality

## Best Practices

✅ Create feature branch before starting
✅ Review checklist thoroughly
✅ Test incrementally after each layer
✅ Back up any data before removal
✅ Commit changes in logical chunks
✅ Coordinate with team and stakeholders

❌ Don't remove all files at once
❌ Don't skip validation steps
❌ Don't ignore shared code warnings
❌ Don't forget i18n files

## Getting Help

For detailed documentation, see:
- Usage Guide: `usage-guide.md`
- Quick Reference: `quick-reference.md`
- Example: `example-checklist.md`

## Integration

Works well with other project tools:
- **pr-code-review** skill - Validate removal PRs
- **Git workflow** - Branch, commit, PR creation
- **CI/CD** - Automated testing and validation

## Feedback

After using this skill, document your experience in:
```
feature-remove-task-list/_feedback.md
```

This helps improve future removals!
