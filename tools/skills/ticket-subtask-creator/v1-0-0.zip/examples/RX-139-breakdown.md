# RX-139 Subtask Breakdown

## Summary
- **Ticket**: [BO][BE] Project List
- **Components**: [BO][BE]
- **Total Subtasks**: 14

---

## [BO] Back Office Subtasks

### UI Implementation

#### [BO] - Project List Table Component
**Requirements**: FR-2
**Description**: Implement the main project list table displaying all projects with the following columns:
- Project Name
- Project ID
- Province
- Project Type (Detached house, condo, townhome, etc.)
- Project Status (Active/Inactive)
- Last Updated Date/Time
- Action buttons (View/Edit based on permissions)

**Acceptance Criteria**:
- [ ] Table renders with all required columns
- [ ] Supports client-side pagination
- [ ] Action buttons conditionally rendered based on user permissions
- [ ] Matches Figma design specification
- [ ] Responsive layout for different screen sizes

---

#### [BO] - Search Input Component
**Requirements**: FR-3
**Description**: Implement type-to-search functionality that searches by Project Name and Project ID. Search should work with debouncing and integrate with current filters/sort.

**Acceptance Criteria**:
- [ ] Input field with search icon
- [ ] Debounced search (300ms delay)
- [ ] Searches both Project Name and Project ID
- [ ] Preserves current filter and sort when searching
- [ ] Clear button to reset search

---

#### [BO] - Filter Dropdowns (Type, Province)
**Requirements**: FR-4
**Description**: Implement filter dropdowns for Project Type and Province. Filters should be multi-select capable and apply to both list display and export.

**Acceptance Criteria**:
- [ ] Project Type dropdown with all available types
- [ ] Province dropdown with all available provinces
- [ ] Filters apply immediately on selection
- [ ] Clear/reset filter option
- [ ] Filter state persists during session

---

#### [BO] - NEW/UPDATE Badge Indicators
**Requirements**: FR-7
**Description**: Display visual indicators for projects that are newly synced from ICON ("NEW" badge) or have updates from ICON ("UPDATE" badge).

**Acceptance Criteria**:
- [ ] "NEW" badge displayed for newly imported projects
- [ ] "UPDATE" badge displayed for projects with ICON updates
- [ ] Badges are visually distinct and match design system
- [ ] Badges removed after user opens project detail

---

### API Integration

#### [BO] - Project List Data Fetching
**Requirements**: FR-2, FR-3, FR-4, FR-5
**Description**: Integrate with GET /projects API to fetch project list data. Handle search, filter, sort, and pagination parameters.

**Acceptance Criteria**:
- [ ] Fetches paginated project data on mount
- [ ] Passes search query parameter
- [ ] Passes filter parameters (type, province)
- [ ] Passes sort parameter (field + direction)
- [ ] Handles API errors gracefully
- [ ] Shows loading skeleton during fetch

**Dependencies**: [BE] - GET /projects List Endpoint

---

#### [BO] - Export API Integration
**Requirements**: FR-6
**Description**: Integrate with export endpoint to download project list as XLSX. Export should respect current search/filter/sort state.

**Acceptance Criteria**:
- [ ] Export button triggers API call with current filters
- [ ] Downloads XLSX file to user's device
- [ ] Shows loading state during export generation
- [ ] Export button disabled when list is empty
- [ ] Handles export errors with user feedback

**Dependencies**: [BE] - GET /projects/export Export Endpoint

---

#### [BO] - Manual Sync API Integration
**Requirements**: FR-8
**Description**: Integrate with sync endpoint to trigger manual ICON synchronization. Display last sync timestamp and handle sync completion.

**Acceptance Criteria**:
- [ ] Sync button triggers POST /projects/sync
- [ ] Shows "last synced" timestamp under button
- [ ] Loading spinner during sync operation
- [ ] Refreshes list after sync completes
- [ ] Updates "last synced" timestamp on success

**Dependencies**: [BE] - POST /projects/sync Manual Sync Trigger

---

### Behavior & Error Handling

#### [BO] - Permission-based UI Controls
**Requirements**: FR-1
**Description**: Implement permission checks to control UI visibility and actions. Staff can only see/interact with features they have permission for.

**Acceptance Criteria**:
- [ ] Menu/page hidden for users without view permission
- [ ] Edit action button hidden for users without edit permission
- [ ] No delete action exists in UI (not just hidden)
- [ ] Permission check on component mount
- [ ] Graceful redirect if permission denied

---

#### [BO] - Loading/Error/Retry States
**Requirements**: FR-11
**Description**: Implement comprehensive loading, error, and retry states for all async operations (list load, export, sync).

**Acceptance Criteria**:
- [ ] Loading skeleton shown during initial list fetch
- [ ] Inline loading for filter/search changes
- [ ] User-friendly error messages displayed
- [ ] Retry button available on error
- [ ] No infinite loading states (timeout handling)

---

#### [BO] - Real-time Sync Notification Toast
**Requirements**: FR-10
**Description**: Display toast notification to all Back Office users when ICON sync completes. This requires WebSocket or similar real-time mechanism.

**Acceptance Criteria**:
- [ ] Toast appears when sync completes
- [ ] Toast shows success/failure status
- [ ] All active BO users receive notification
- [ ] Toast auto-dismisses after 5 seconds
- [ ] Click to dismiss available

---

## [BE] Backend Subtasks

### API Endpoints

#### [BE] - GET /projects List Endpoint
**Requirements**: FR-2, FR-3, FR-4, FR-5
**Description**: Implement REST endpoint to return paginated project list with support for search, filter, and sort parameters.

**Endpoint**: `GET /api/v1/projects`

**Query Parameters**:
- `page` (int): Page number
- `limit` (int): Items per page
- `search` (string): Search by name/ID
- `type` (string[]): Filter by project type
- `province` (string[]): Filter by province
- `sortBy` (string): Field to sort by
- `sortOrder` (string): ASC or DESC

**Acceptance Criteria**:
- [ ] Returns paginated response with total count
- [ ] Search filters by name and ID (partial match)
- [ ] Type filter supports multiple values
- [ ] Province filter supports multiple values
- [ ] Sort works for name and lastUpdated
- [ ] Returns 403 if user lacks view permission
- [ ] No delete endpoint exists

---

#### [BE] - GET /projects/export Export Endpoint
**Requirements**: FR-6
**Description**: Implement endpoint to export project list as XLSX file. Export should apply the same search/filter/sort as list endpoint.

**Endpoint**: `GET /api/v1/projects/export`

**Query Parameters**: Same as list endpoint (search, type, province, sortBy, sortOrder)

**Acceptance Criteria**:
- [ ] Returns XLSX file with correct MIME type
- [ ] Includes all list columns in export
- [ ] Respects current search/filter/sort
- [ ] Returns empty file or appropriate response if no data
- [ ] Permission check enforced

**Dependencies**: [BE] - GET /projects List Endpoint

---

#### [BE] - POST /projects/sync Manual Sync Trigger
**Requirements**: FR-8
**Description**: Implement endpoint to trigger manual synchronization from ICON. Returns immediately and processes sync asynchronously.

**Endpoint**: `POST /api/v1/projects/sync`

**Acceptance Criteria**:
- [ ] Triggers ICON sync job asynchronously
- [ ] Returns sync job ID for status tracking
- [ ] Returns last sync timestamp in response
- [ ] Broadcasts notification on completion (WebSocket)
- [ ] Handles concurrent sync requests gracefully

**Dependencies**: [BE] - ICON Sync Service with Merge Rules

---

### Functions & Services

#### [BE] - ICON Sync Service with Merge Rules
**Requirements**: FR-7, FR-9
**Description**: Implement service to synchronize projects from ICON system. Must follow merge rules to preserve BO-enriched fields while updating ICON-owned fields.

**ICON-owned fields** (updated from ICON):
- Project Name
- Project ID
- Province
- Project Type

**BO-owned fields** (never overwritten by sync):
- Project Status (Active/Inactive)
- Any BO-enriched metadata

**Acceptance Criteria**:
- [ ] Fetches all projects from ICON API
- [ ] For new projects: Creates with inactive status, sets "NEW" flag
- [ ] For existing projects: Updates only ICON-owned fields
- [ ] For changed projects: Sets "UPDATE" flag
- [ ] Never overwrites BO-owned fields
- [ ] Logs sync results for debugging
- [ ] Handles ICON API failures gracefully

---

## Dependency Graph

```
[BE Layer - Implement First]
[BE] - ICON Sync Service
    └── [BE] - POST /projects/sync
[BE] - GET /projects List Endpoint
    └── [BE] - GET /projects/export

[BO Layer - Implement After BE]
[BO] - Project List Table Component
    ├── [BO] - Search Input Component
    ├── [BO] - Filter Dropdowns
    └── [BO] - NEW/UPDATE Badge Indicators

[BE] - GET /projects ──► [BO] - Project List Data Fetching
                              └── [BO] - Loading/Error/Retry States

[BE] - GET /projects/export ──► [BO] - Export API Integration

[BE] - POST /projects/sync ──► [BO] - Manual Sync API Integration
                                    └── [BO] - Real-time Sync Notification Toast

[Independent]
[BO] - Permission-based UI Controls
```

## Suggested Implementation Order

1. **Phase 1 - Backend Foundation**
   - [BE] - ICON Sync Service with Merge Rules
   - [BE] - GET /projects List Endpoint

2. **Phase 2 - Backend Features**
   - [BE] - GET /projects/export Export Endpoint
   - [BE] - POST /projects/sync Manual Sync Trigger

3. **Phase 3 - Frontend UI**
   - [BO] - Permission-based UI Controls
   - [BO] - Project List Table Component
   - [BO] - Search Input Component
   - [BO] - Filter Dropdowns (Type, Province)
   - [BO] - NEW/UPDATE Badge Indicators

4. **Phase 4 - Frontend Integration**
   - [BO] - Project List Data Fetching
   - [BO] - Loading/Error/Retry States
   - [BO] - Export API Integration
   - [BO] - Manual Sync API Integration
   - [BO] - Real-time Sync Notification Toast
