# Ticket Subtask Creator Examples

This directory contains example outputs from the ticket-subtask-creator skill.

## Examples Index

- **RX-139-breakdown.md** - Full breakdown of a [BO][BE] Project List ticket demonstrating all subtask types

## How to Use

When you say "Break down {TICKET-ID}", the skill will:

1. Read `tickets/{TICKET-ID}/requirements.md`
2. Parse the functional requirements
3. Generate a breakdown similar to these examples

## Example Commands

```
Break down RX-139
```

```
Create subtasks for RX-140
```

```
Decompose ticket RX-141 into BO and BE tasks
```

## Output Location

Subtask breakdowns can be:
- Displayed directly in the conversation
- Saved to `tickets/{TICKET-ID}/subtasks.md` if requested
