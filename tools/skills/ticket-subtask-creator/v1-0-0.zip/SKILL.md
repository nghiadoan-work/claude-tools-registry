---
name: ticket-subtask-creator
description: Break down tickets into BO/BE subtasks with structured task decomposition
---

# Ticket Subtask Creator

A skill for decomposing project tickets into granular, actionable subtasks organized by component type (Back Office and Backend).

## Quick Start

This skill helps break down feature tickets into structured subtasks for development teams.

Use this skill when you need to:
- Break down a ticket (e.g., RX-139) into development subtasks
- Create BO (Back Office) and BE (Backend) task breakdowns
- Generate implementation checklists for development teams
- Ensure comprehensive coverage of UI, API, and behavior requirements

**Quick Usage:**
```
Break down RX-139
```

The skill will:
1. Read `tickets/RX-139/requirements.md`
2. Analyze requirements for BO and BE components
3. Generate structured subtasks for each component

## Implementation Workflow

### Step 1: Read the Ticket Requirements
Read the ticket file at `tickets/{TICKET-ID}/requirements.md` to understand:
- Objective and scope
- Functional requirements (numbered list)
- Acceptance criteria
- Edge cases
- Reference links (Figma, related tickets)

### Step 2: Identify Components
Determine which components are involved based on the ticket title tags:
- `[BO]` - Back Office (frontend/admin UI)
- `[BE]` - Backend (API/services)
- `[BO][BE]` - Both components required

### Step 3: Extract Functional Requirements
Parse the numbered functional requirements from the ticket and categorize them by:
- UI/Display requirements
- Data/API requirements
- Behavior/interaction requirements
- Error handling requirements

### Step 4: Generate BO Subtasks
For Back Office components, create subtasks in three categories:

**UI Implementation:**
- Page layout and components
- Table/list displays
- Forms and inputs
- Visual indicators (badges, status)

**API Integration:**
- API calls and data fetching
- State management
- Data transformation
- Caching strategies

**Behavior & Error Handling:**
- User interactions
- Loading states
- Error displays and retry logic
- Permission-based UI changes

### Step 5: Generate BE Subtasks
For Backend components, create subtasks in two categories:

**API Endpoints:**
- REST endpoints (GET, POST, PUT, DELETE)
- Request/response schemas
- Authentication/authorization
- Rate limiting

**Functions & Services:**
- Business logic
- Data processing
- External integrations
- Background jobs/sync operations

### Step 6: Output Structured Subtasks
Format the output as a clear, hierarchical task list with:
- Subtask ID (parent ticket + component + number)
- Task title
- Brief description
- Acceptance criteria reference

## Knowledge Areas

- **Ticket Parsing**: Understanding ticket format and extracting requirements
- **Component Identification**: Recognizing BO vs BE responsibilities
- **Task Decomposition**: Breaking features into atomic, implementable tasks
- **Dependency Mapping**: Understanding task order and dependencies
- **Acceptance Criteria**: Ensuring subtasks map to acceptance criteria

## Best Practices

1. **Read Full Requirements First**: Always read the entire requirements.md before generating subtasks to understand the full scope

2. **Keep Subtasks Atomic**: Each subtask should be completable independently and testable on its own

3. **Reference Original Requirements**: Link subtasks back to specific functional requirement numbers (e.g., "FR-3: Search")

4. **Include Acceptance Criteria**: Each subtask should have clear done criteria derived from the parent ticket

5. **Order by Dependencies**: List subtasks in implementation order - BE APIs before BO integration

6. **Separate Concerns**: Don't mix UI work with API integration in the same subtask

7. **Cover Edge Cases**: Create specific subtasks for edge cases mentioned in the ticket

8. **Include Error States**: Always create subtasks for error handling and loading states

## Patterns

### Pattern 1: BO UI Implementation Subtask

**When to use**: For any visual/display component in Back Office

**Template:**
```
### [BO] - {Component Name}
**Category**: UI Implementation
**Requirements**: FR-{X}, FR-{Y}
**Description**: Implement {component} with {key features}
**Acceptance Criteria**:
- [ ] Component renders correctly
- [ ] Displays required data fields
- [ ] Responsive/matches Figma design
```

**Example:**
```
### [BO] - Project List Table Component
**Category**: UI Implementation
**Requirements**: FR-2
**Description**: Implement project list table with columns: Project Name, Project ID,
Province, Project Type, Project Status, Last Updated, Actions
**Acceptance Criteria**:
- [ ] Table displays all required columns
- [ ] Action buttons show based on permissions
- [ ] Supports pagination
- [ ] Matches Figma design
```

---

### Pattern 2: BO API Integration Subtask

**When to use**: For connecting UI to backend APIs

**Template:**
```
### [BO] - {Integration Name}
**Category**: API Integration
**Requirements**: FR-{X}
**Description**: Integrate {API endpoint} with {UI component}
**Acceptance Criteria**:
- [ ] API call implemented correctly
- [ ] Response data mapped to UI
- [ ] Loading state shown during fetch
- [ ] Error handling implemented
```

**Example:**
```
### [BO] - Project List Data Fetching
**Category**: API Integration
**Requirements**: FR-3, FR-4, FR-5
**Description**: Integrate GET /projects API with project list table,
including search, filter, and sort parameters
**Acceptance Criteria**:
- [ ] Fetches projects with pagination
- [ ] Passes search/filter/sort params
- [ ] Updates table on response
- [ ] Shows loading skeleton during fetch
```

---

### Pattern 3: BO Behavior & Error Handling Subtask

**When to use**: For user interactions and error states

**Template:**
```
### [BO] - {Behavior Name}
**Category**: Behavior & Error Handling
**Requirements**: FR-{X}
**Description**: Implement {behavior} including {error scenarios}
**Acceptance Criteria**:
- [ ] User interaction works correctly
- [ ] Loading states displayed
- [ ] Error messages shown appropriately
- [ ] Retry option available
```

**Example:**
```
### [BO] - Sync Button Behavior
**Category**: Behavior & Error Handling
**Requirements**: FR-8, FR-10, FR-11
**Description**: Implement manual sync button with loading state,
success/failure toast, and real-time notification
**Acceptance Criteria**:
- [ ] Button triggers sync API call
- [ ] Shows loading spinner during sync
- [ ] Displays success/failure toast
- [ ] Updates "last synced" timestamp
- [ ] Handles sync failure with retry option
```

---

### Pattern 4: BE API Endpoint Subtask

**When to use**: For creating new API endpoints

**Template:**
```
### [BE] - {Endpoint Name}
**Category**: API Endpoint
**Requirements**: FR-{X}
**Description**: Implement {METHOD} {path} endpoint for {purpose}
**Acceptance Criteria**:
- [ ] Endpoint returns correct response schema
- [ ] Authentication/authorization enforced
- [ ] Input validation implemented
- [ ] Error responses follow standard format
```

**Example:**
```
### [BE] - GET /projects List Endpoint
**Category**: API Endpoint
**Requirements**: FR-2, FR-3, FR-4, FR-5
**Description**: Implement project list endpoint with search, filter,
sort, and pagination support
**Acceptance Criteria**:
- [ ] Returns paginated project list
- [ ] Supports search by name/ID
- [ ] Supports filter by type/province
- [ ] Supports sort by name/lastUpdated
- [ ] Permission check returns 403 if unauthorized
```

---

### Pattern 5: BE Function/Service Subtask

**When to use**: For business logic and background operations

**Template:**
```
### [BE] - {Function Name}
**Category**: Function/Service
**Requirements**: FR-{X}
**Description**: Implement {function} to handle {purpose}
**Acceptance Criteria**:
- [ ] Function performs required logic
- [ ] Handles edge cases
- [ ] Unit tests written
- [ ] Integrates with dependent services
```

**Example:**
```
### [BE] - ICON Sync Service
**Category**: Function/Service
**Requirements**: FR-7, FR-9
**Description**: Implement sync service to fetch projects from ICON,
apply merge rules (ICON-owned vs BO-owned fields), and update database
**Acceptance Criteria**:
- [ ] Fetches all projects from ICON API
- [ ] Creates new projects with inactive status
- [ ] Updates only ICON-owned fields for existing
- [ ] Marks new projects with "NEW" flag
- [ ] Marks updated projects with "UPDATE" flag
- [ ] Preserves BO-enriched fields
```

---

### Pattern 6: Export/Report Subtask

**When to use**: For data export functionality

**Template:**
```
### [BE] - {Export Name}
**Category**: Function/Service
**Requirements**: FR-{X}
**Description**: Implement {format} export with {filters applied}
**Acceptance Criteria**:
- [ ] Export respects current filters/search/sort
- [ ] File format correct
- [ ] All required columns included
- [ ] Disabled when no data
```

**Example:**
```
### [BE] - Project List XLSX Export
**Category**: Function/Service
**Requirements**: FR-6
**Description**: Implement XLSX export endpoint that respects
current search/filter/sort criteria
**Acceptance Criteria**:
- [ ] Generates valid XLSX file
- [ ] Includes all list columns
- [ ] Applies current filters to export data
- [ ] Returns empty file handling (or disabled on BO)
```

## Common Pitfalls

- **Missing Permission Subtasks**: Forgetting to create subtasks for permission checks → Always include authorization for both UI visibility and API enforcement

- **Ignoring Loading States**: Not creating subtasks for loading indicators → Include loading state subtasks for every async operation

- **Skipping Error Scenarios**: Only planning happy path → Review edge cases section and create error handling subtasks

- **Coupling UI and API Work**: Combining frontend and backend in same subtask → Keep BO and BE subtasks separate for parallel development

- **Missing Sync/Notification Tasks**: Forgetting real-time updates → Check for WebSocket/notification requirements and create dedicated subtasks

- **No Export Test Data**: Creating export without considering empty states → Include empty state handling in export subtasks

- **Overlooking Field Ownership**: Not considering merge rules for synced data → Create specific subtasks for data merge logic when external sync is involved

## Troubleshooting

**Problem**: Can't find requirements file
**Solution**: Ensure the ticket folder exists at `tickets/{TICKET-ID}/requirements.md`. Create it if missing.

**Problem**: Unclear component ownership
**Solution**: If ticket doesn't have [BO] or [BE] tags, analyze requirements to determine if it needs UI work, API work, or both.

**Problem**: Requirements too vague for subtasks
**Solution**: Generate subtasks based on standard patterns (list page = table + search + filter + export), then flag unclear requirements for clarification.

**Problem**: Too many subtasks generated
**Solution**: Combine related small tasks (e.g., multiple simple filters into one filter subtask). Aim for 3-8 subtasks per component.

## Output Format

When breaking down a ticket, output in this structure:

```markdown
# {TICKET-ID} Subtask Breakdown

## Summary
- **Ticket**: {Title}
- **Components**: [BO] / [BE] / [BO][BE]
- **Total Subtasks**: {count}

---

## [BO] Back Office Subtasks

### UI Implementation

#### [BO] - {Component Name}
**Requirements**: FR-{X}
**Description**: {Brief description}
**Acceptance Criteria**:
- [ ] {Criterion 1}
- [ ] {Criterion 2}

### API Integration

#### [BO] - {Integration Name}
**Requirements**: FR-{X}
**Description**: {Brief description}
**Acceptance Criteria**:
- [ ] {Criterion 1}
- [ ] {Criterion 2}

### Behavior & Error Handling

#### [BO] - {Behavior Name}
**Requirements**: FR-{X}
**Description**: {Brief description}
**Acceptance Criteria**:
- [ ] {Criterion 1}
- [ ] {Criterion 2}

---

## [BE] Backend Subtasks

### API Endpoints

#### [BE] - {Endpoint Name}
**Requirements**: FR-{X}
**Description**: {Brief description}
**Acceptance Criteria**:
- [ ] {Criterion 1}
- [ ] {Criterion 2}

### Functions & Services

#### [BE] - {Function Name}
**Requirements**: FR-{X}
**Description**: {Brief description}
**Acceptance Criteria**:
- [ ] {Criterion 1}
- [ ] {Criterion 2}

---

## Dependency Graph
{List subtask dependencies and suggested implementation order}
```

## Additional Resources

- **Ticket Location**: `tickets/{TICKET-ID}/requirements.md`
- **Figma Designs**: Usually linked in the ticket's Reference section
- **Related Tickets**: Check "Issue links" section for cloned/related tickets
