# [Test Category Name] Test Report

**Test Category:** TC-[CATEGORY] ([Category Full Name])
**Total Tests:** X
**Execution Date:** YYYY-MM-DD HH:MM
**Tester:** [Name]
**Environment:** [Development/Staging/Production]
**Backend Version:** [Version]
**Base URL:** `http://localhost:8080/api/v1`

---

## Executive Summary

Brief overview of test execution results and major findings.

### Summary Metrics

| Status | Count | Percentage |
|--------|-------|------------|
| ✅ Passed | X | XX% |
| ❌ Failed | X | XX% |
| ⚠️ Blocked | X | XX% |
| ⏭️ Not Executed | X | XX% |
| **TOTAL** | X | 100% |

### Pass Rate: XX%

---

## Test Results

### TC-XXX-001: [Test Case Name]

**Status:** ✅ Passed / ❌ Failed / ⚠️ Blocked / ⏭️ Not Executed

**Objective:** [Brief description of what this test verifies]

**Prerequisites:**
- Prerequisite 1
- Prerequisite 2

**Test Steps Executed:**

1. **Step 1:** [Action taken]
   - **Expected:** [Expected result]
   - **Actual:** [Actual result]
   - **Status:** ✅ Pass / ❌ Fail

2. **Step 2:** [Action taken]
   - **Expected:** [Expected result]
   - **Actual:** [Actual result]
   - **Status:** ✅ Pass / ❌ Fail

**Evidence:**

```json
{
  "request": {
    "method": "POST",
    "url": "/endpoint",
    "headers": {
      "Authorization": "Bearer xxx",
      "Content-Type": "application/json"
    },
    "body": {
      "field": "value"
    }
  },
  "response": {
    "status": 200,
    "body": {
      "data": {},
      "message": "Success"
    }
  }
}
```

**Execution Time:** XX seconds

**Notes:** Any additional observations or comments

---

### TC-XXX-002: [Next Test Case Name]

[Repeat structure above for each test case]

---

## Issues Found

### Issue #1: [Issue Title]

**Test Case:** TC-XXX-XXX
**Severity:** Critical / High / Medium / Low
**Status:** Open / In Progress / Resolved

**Description:**
Detailed description of the issue.

**Reproduction Steps:**
1. Step 1
2. Step 2
3. Step 3

**Expected Behavior:**
What should happen

**Actual Behavior:**
What actually happened

**Evidence:**
```
Error logs, screenshots, or API responses
```

**Impact:**
How this affects the system or users

**Suggested Fix:**
Recommendation for resolution

---

### Issue #2: [Next Issue]

[Repeat structure above for each issue]

---

## Test Environment Details

**Configuration:**
- Database: PostgreSQL 15
- Keycloak: Version X.X
- Backend Server: Go 1.21+
- Test Users Created: Yes
- Test Data Seeded: Yes
- ICON Mock Data: Synced

**Environment Variables:**
```
PORT=8080
ENV=development
DB_HOST=localhost
DB_PORT=6543
KEYCLOAK_URL=http://localhost:8081
```

---

## Test Data

**Projects:** X projects
**Users:** X test users (superadmin, manager, technician, readonly)
**Categories:** X categories
**Contractors:** X contractors
**Test Tickets:** X created during testing

---

## Recommendations

1. **Recommendation 1:** [Description]
   - Priority: High/Medium/Low
   - Estimated Effort: [Time estimate]

2. **Recommendation 2:** [Description]
   - Priority: High/Medium/Low
   - Estimated Effort: [Time estimate]

---

## Blockers & Dependencies

**Blocked Tests:**
- TC-XXX-XXX: [Reason blocked] - Waiting on [dependency]

**Dependencies:**
- Dependency 1
- Dependency 2

---

## Next Steps

1. Fix critical issues identified
2. Re-test failed test cases
3. Execute remaining blocked tests
4. Move to next test category

---

## Attachments

- API request/response logs: `./logs/category-api-logs.txt`
- Screenshots: `./screenshots/category/`
- Test data dumps: `./data/category-test-data.sql`

---

## Sign-off

**Tester:** ________________ Date: _____

**Reviewed By:** ________________ Date: _____

**Approved By:** ________________ Date: _____

---

**Report Generated:** YYYY-MM-DD HH:MM
**Document Version:** 1.0
