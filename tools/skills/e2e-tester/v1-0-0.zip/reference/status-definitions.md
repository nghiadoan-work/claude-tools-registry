# Test Status Definitions

This document defines the meaning and usage of test execution statuses.

## Status Types

### ✅ Passed

**Definition:** Test executed successfully and all expected results were achieved.

**When to Use:**
- All test steps completed without errors
- Actual results match expected results exactly
- No unexpected behavior observed
- All assertions passed

**Documentation Requirements:**
- Record actual results (even if they match expected)
- Capture evidence (API responses, logs)
- Note execution time

**Example:**
```markdown
### TC-AUTH-001: Successful Login
**Status:** ✅ Passed
**Actual Result:** Login successful, received valid JWT token
**Evidence:** [API response captured]
```

---

### ❌ Failed

**Definition:** Test executed but did not produce expected results.

**When to Use:**
- Actual results differ from expected results
- Test encountered an error or exception
- Assertion failed
- Unexpected behavior observed

**Documentation Requirements:**
- Detailed description of failure
- Expected vs Actual results comparison
- Complete error messages and stack traces
- Steps to reproduce the failure
- Evidence (screenshots, logs, API responses)
- Create issue/defect report

**Example:**
```markdown
### TC-AUTH-005: Token Expiration
**Status:** ❌ Failed
**Expected Result:** 401 Unauthorized with error message
**Actual Result:** 500 Internal Server Error
**Evidence:** [Error log attached]
**Issue Created:** ISSUE-023
```

**Severity Classification:**
- **Critical**: Blocks core functionality, no workaround
- **High**: Major feature broken, workaround exists
- **Medium**: Feature partially broken, minor impact
- **Low**: Cosmetic issue, no functional impact

---

### ⚠️ Blocked

**Definition:** Test cannot be executed due to external dependencies or blockers.

**When to Use:**
- Prerequisites not met
- Required test data unavailable
- Dependent service/feature not working
- Environment issue preventing execution
- Waiting on another test to complete
- Missing test credentials or access

**Documentation Requirements:**
- Clear reason for blockage
- What is needed to unblock
- Who can resolve the blocker
- Expected resolution date (if known)
- Alternative test approach (if any)

**Example:**
```markdown
### TC-FILE-007: Download Attachment
**Status:** ⚠️ Blocked
**Reason:** File upload feature (TC-FILE-001) failed, no files available for download test
**Blocker:** ISSUE-015 - File upload returns 500 error
**Dependencies:** TC-FILE-001 must pass first
**Unblock Action:** Fix file upload bug
**Expected Resolution:** 2025-12-23
```

**Common Blockers:**
- Database not accessible
- Test user accounts not created
- Required feature not implemented yet
- Dependent test failed
- Environment configuration missing
- Third-party service unavailable

---

### ⏭️ Not Executed

**Definition:** Test was not run during this test cycle.

**When to Use:**
- Test skipped intentionally
- Out of scope for current cycle
- Deferred to later phase
- Low priority test
- Time constraints

**Documentation Requirements:**
- Reason for not executing
- When it will be executed
- Priority level
- Impact of not testing this

**Example:**
```markdown
### TC-PERF-005: Export 5000 Records
**Status:** ⏭️ Not Executed
**Reason:** Performance tests deferred to Phase 2
**Priority:** Low
**Planned For:** Next test cycle
**Impact:** No impact on functional testing
```

---

### 🔄 In Progress

**Definition:** Test execution currently ongoing.

**When to Use:**
- Test started but not completed
- Long-running test
- Test paused mid-execution

**Documentation Requirements:**
- What steps completed
- What remains
- Current status/observations
- Expected completion time

**Example:**
```markdown
### TC-E2E-001: Complete Ticket Lifecycle
**Status:** 🔄 In Progress
**Completed:** Steps 1-8 (Create, Assign, Update)
**Remaining:** Steps 9-16 (Work log, Close, Export)
**Notes:** Taking longer due to manual screenshot capture
**Expected Completion:** 14:00
```

---

## Status Transitions

### Allowed Transitions

```
⏭️ Not Executed
    ↓
🔄 In Progress
    ↓
✅ Passed / ❌ Failed / ⚠️ Blocked
    ↓
🔄 In Progress (if retesting)
    ↓
✅ Passed / ❌ Failed
```

### Re-testing

When re-testing a failed or blocked test:

1. **Mark as In Progress**: Change status to 🔄
2. **Document Re-test**: Add note about re-test attempt
3. **Compare Results**: Note if issue is fixed or persists
4. **Update Status**: Mark final status (Passed/Failed)

**Example:**
```markdown
### TC-AUTH-003: Unauthorized Access
**Original Status:** ❌ Failed (2025-12-22 10:00)
**Re-test Status:** 🔄 In Progress (2025-12-22 15:00)
**Final Status:** ✅ Passed (2025-12-22 15:15)
**Notes:** Fixed by commit #abc123, re-tested and now passing
```

---

## Status Metrics

### Calculating Pass Rate

```
Pass Rate = (Passed / (Passed + Failed)) × 100%
```

**Notes:**
- Exclude Blocked and Not Executed from calculation
- Only count Passed and Failed tests
- Report as percentage with 1 decimal place

**Example:**
- Passed: 45
- Failed: 5
- Blocked: 2
- Not Executed: 3
- Pass Rate: 45 / (45 + 5) × 100% = **90.0%**

### Coverage Metrics

```
Test Coverage = (Executed / Total) × 100%
Executed = Passed + Failed
Total = All tests (including Blocked and Not Executed)
```

**Example:**
- Total Tests: 55
- Passed: 45
- Failed: 5
- Blocked: 2
- Not Executed: 3
- Coverage: (45 + 5) / 55 × 100% = **90.9%**

---

## Best Practices

### Status Updates

1. **Update Immediately**: Change status as soon as test completes
2. **Be Accurate**: Don't mark as Passed if there were issues
3. **Document Thoroughly**: Include all required information for status
4. **Link Issues**: Reference defect IDs for failed tests
5. **Track Blockers**: Actively manage blocked tests to unblock them

### Status Communication

**In Reports:**
- Use emoji icons for quick visual scanning
- Include counts and percentages
- Show status distribution in tables
- Highlight critical failures

**In Task Lists:**
- Check boxes for passed tests
- Leave unchecked for pending tests
- Add emoji status indicators
- Calculate and show progress percentage

**In Meetings:**
- Report counts by status
- Discuss failed and blocked tests
- Share pass rate trends
- Identify blockers needing help

---

## Status Examples Table

| Status | Symbol | Use Case | Documentation Needed |
|--------|--------|----------|---------------------|
| Passed | ✅ | Test successful | Results, evidence |
| Failed | ❌ | Test unsuccessful | Issue details, logs, steps |
| Blocked | ⚠️ | Cannot execute | Blocker reason, dependencies |
| Not Executed | ⏭️ | Skipped | Reason, future plan |
| In Progress | 🔄 | Currently running | Progress, ETA |

---

## Frequently Asked Questions

**Q: Should I mark a test as Passed if it mostly worked?**
A: No. If any expected result was not achieved, mark as Failed and document what didn't work.

**Q: When should I use Blocked vs Failed?**
A: Use Failed if the test ran but didn't pass. Use Blocked if you couldn't run the test at all.

**Q: Can a test be both Failed and Blocked?**
A: No. Choose the most accurate status. If it failed, it wasn't blocked. If it's blocked, it couldn't be executed to fail.

**Q: Should I count Blocked tests in pass rate?**
A: No. Pass rate should only include tests that were actually executed (Passed + Failed).

**Q: How do I track re-testing?**
A: Add a note to the test result showing original status, re-test date, and final status.

**Q: What if a test partially passes?**
A: Mark as Failed. Document what passed and what failed. Create specific test cases for partial scenarios if needed.
