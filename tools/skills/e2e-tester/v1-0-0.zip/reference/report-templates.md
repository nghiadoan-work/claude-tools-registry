# Test Report Templates

This document provides various report templates for different testing scenarios.

## Table of Contents

1. [Category Test Report](#category-test-report)
2. [Final Test Summary Report](#final-test-summary-report)
3. [Issue Report](#issue-report)
4. [Daily Test Progress Report](#daily-test-progress-report)

---

## Category Test Report

Use this template for reporting results of a single test category (e.g., Authentication, CRUD operations).

### Template Structure

```markdown
# [Category] Test Report

**Category:** TC-[CODE]
**Tests:** X total
**Date:** YYYY-MM-DD
**Tester:** Name
**Environment:** Env

## Summary
[Metrics table]

## Test Results
[Individual test results]

## Issues Found
[List of issues]

## Recommendations
[Improvements suggested]
```

### When to Use
- After completing all tests in a category
- Before moving to next category
- For focused reporting on specific feature areas

---

## Final Test Summary Report

Use this template for overall test cycle summary across all categories.

### Template Structure

```markdown
# E2E Test Execution Summary Report

**Project:** Fast Fix API
**Version:** X.X.X
**Test Cycle:** [Name/Date Range]
**Environment:** [Environment]

## Executive Summary
[High-level overview]

## Overall Metrics
| Category | Total | Passed | Failed | Blocked | Pass Rate |
|----------|-------|--------|--------|---------|-----------|
| Auth | 6 | 5 | 1 | 0 | 83% |
| Master Data | 16 | 14 | 2 | 0 | 88% |
[...]

## Critical Issues Summary
[Top issues across all categories]

## Test Coverage
- API Endpoints Tested: X/Y (Z%)
- Features Covered: X/Y (Z%)

## Recommendations
[Overall recommendations]

## Sign-off
[Approval section]
```

### When to Use
- End of complete test cycle
- Before production release
- For stakeholder reporting

---

## Issue Report

Use this template for detailed bug/defect reporting.

### Template Structure

```markdown
# Issue Report: [Issue Title]

**Issue ID:** ISSUE-XXX
**Severity:** Critical/High/Medium/Low
**Priority:** P1/P2/P3
**Status:** Open/In Progress/Resolved/Closed
**Found In:** Test TC-XXX-XXX
**Environment:** [Environment]

## Description
[Clear description of the issue]

## Reproduction Steps
1. Step 1
2. Step 2
3. Step 3

## Expected vs Actual
**Expected:** [What should happen]
**Actual:** [What actually happened]

## Evidence
[Logs, screenshots, API responses]

## Impact Analysis
**User Impact:** [How users are affected]
**System Impact:** [System-level effects]
**Workaround:** [If any]

## Root Cause (If Known)
[Analysis of why this happened]

## Suggested Fix
[Recommendation for resolution]

## Related Issues
- ISSUE-YYY: [Related issue]
```

### When to Use
- When documenting a defect
- For tracking issues in bug tracking system
- For detailed defect analysis

---

## Daily Test Progress Report

Use this template for daily standup or progress tracking.

### Template Structure

```markdown
# Daily Test Progress Report

**Date:** YYYY-MM-DD
**Tester:** Name

## Tests Executed Today
- Total tests executed: X
- Passed: Y
- Failed: Z
- Blocked: A

## Categories Completed
- [x] Authentication & Authorization (6/6 tests)
- [ ] Master Data Management (10/16 tests) - IN PROGRESS
- [ ] Ticket Management (0/20 tests) - NOT STARTED

## Issues Found Today
1. [Issue 1] - Severity: High
2. [Issue 2] - Severity: Medium

## Blockers
- [Blocker 1]: Waiting on database fix
- [Blocker 2]: Need test user credentials

## Plan for Tomorrow
1. Complete Master Data tests
2. Start Ticket Management category
3. Retest auth issue after fix

## Notes
[Any additional comments]
```

### When to Use
- Daily progress tracking
- Team standup meetings
- Continuous testing cycles

---

## Report Naming Conventions

**Category Reports:**
- Format: `[NN]-[category-name]-report.md`
- Example: `01-authentication-report.md`

**Summary Reports:**
- Format: `[YYYY-MM-DD]-test-summary.md`
- Example: `2025-12-22-test-summary.md`

**Issue Reports:**
- Format: `ISSUE-[NNN]-[brief-title].md`
- Example: `ISSUE-001-token-expiration-bug.md`

**Daily Reports:**
- Format: `daily-[YYYY-MM-DD].md`
- Example: `daily-2025-12-22.md`

---

## Best Practices

1. **Be Consistent**: Use the same template structure for similar report types
2. **Include Metadata**: Always add date, environment, tester information
3. **Use Tables**: Tables make metrics easy to scan
4. **Add Evidence**: Include API responses, logs, screenshots
5. **Link Related Docs**: Reference test cases, issues, other reports
6. **Version Reports**: Track report versions for updates
7. **Review Before Publishing**: Have another team member review
8. **Archive Reports**: Keep historical reports for trending analysis

---

## Template Customization

Feel free to customize these templates based on:
- Project-specific requirements
- Team preferences
- Stakeholder needs
- Regulatory compliance requirements

Maintain consistency across your testing team by agreeing on standard templates and updating this reference document as templates evolve.
