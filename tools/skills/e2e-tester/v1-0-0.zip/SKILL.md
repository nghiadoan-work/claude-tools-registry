---
name: e2e-tester
description: End-to-end API testing, test execution, and comprehensive test reporting
---

# E2E API Testing Skill

Expert guidance for executing end-to-end API tests, tracking progress, and generating detailed test reports for REST APIs.

## Quick Start

This skill provides comprehensive E2E testing workflow management for REST APIs.

Use this skill when you need to:
- Execute end-to-end API test cases systematically
- Track test execution progress and results
- Generate detailed test reports for each test category
- Document test outcomes with evidence and screenshots
- Perform regression testing across API features

**Quick Example:**
See `./examples/basic-test-execution.md` for a simple test execution workflow.

## Implementation Workflow

### Step 1: Test Environment Setup
Verify test environment is ready with required services, test users, and seed data before executing tests.

**Key Tasks:**
- Start backend server and dependencies (database, Keycloak)
- Create test users with different roles
- Seed database with test data
- Verify environment connectivity

### Step 2: Test Case Organization
Organize test cases into logical categories based on feature areas.

**Categories:**
- Authentication & Authorization
- Master Data Management
- Core Business Logic (Tickets, Projects, etc.)
- File Operations
- Reporting & Analytics
- Performance & Load Testing
- Security & Validation

### Step 3: Sequential Test Execution
Execute tests in dependency order, marking progress as you go.

**Execution Pattern:**
1. Read test specification from test cases document
2. Execute test steps manually or with automated tools
3. Record actual results vs expected results
4. Capture evidence (API responses, errors, screenshots)
5. Update test status (Passed/Failed/Blocked)

### Step 4: Generate Test Reports
After completing a test category, generate a detailed markdown report.

**Report Includes:**
- Test summary (passed/failed/blocked counts)
- Detailed results for each test case
- Evidence and logs
- Issues found
- Recommendations

### Step 5: Test Summary & Sign-off
Create final test execution summary with overall metrics and sign-off checklist.

**Deliverables:**
- Overall pass rate
- Critical issues list
- Test coverage metrics
- Sign-off document

## Knowledge Areas

For detailed reference materials, see the `./reference/` folder.

- **Test Execution Strategies**: Sequential vs parallel testing, dependency management, test isolation
- **Test Case Structure**: Test ID, prerequisites, steps, expected results, actual results
- **Test Data Management**: Seed data creation, test data cleanup, data isolation
- **API Testing Tools**: cURL, Postman, automated testing frameworks, assertion libraries
- **Test Reporting**: Markdown reports, evidence collection, metrics calculation
- **Test Status Management**: Status definitions (Passed/Failed/Blocked/Not Executed), progress tracking
- **Defect Management**: Issue documentation, severity classification, reproduction steps
- **Test Environment**: Environment setup, configuration management, service dependencies

Detailed documentation available in `./reference/` folder.

## Best Practices

1. **Execute Tests in Order**: Follow dependency chains - run authentication tests before feature tests

2. **Document Evidence**: Capture API responses, error messages, and relevant logs for every test execution

3. **Use Consistent Test Data**: Maintain stable test data to ensure reproducible results

4. **Update Status Immediately**: Mark test status as soon as completed to maintain accurate progress

5. **Separate Test Categories**: Generate individual reports for each test category (Auth, CRUD, etc.)

6. **Include Actual Results**: Always document actual results, even for passing tests

7. **Track Blockers**: Document blocked tests with clear reasons and dependencies

8. **Clean Up Between Runs**: Reset test environment to known state before new test cycle

9. **Version Test Reports**: Include version, date, and environment details in all reports

10. **Review Before Sign-off**: Conduct thorough review of test results before final approval

## Patterns

### Pattern 1: Test Execution Loop

Execute tests systematically with progress tracking.

**Implementation:**
See `./examples/test-execution-loop.md` for complete implementation.

```markdown
For each test case:
1. Read test specification (ID, steps, expected results)
2. Check prerequisites are met
3. Execute test steps sequentially
4. Compare actual vs expected results
5. Mark status: ✅ Passed / ❌ Failed / ⚠️ Blocked / ⏭️ Not Executed
6. Document evidence and notes
7. Update progress tracker
```

**Key Points:**
- Never skip prerequisite checks
- Document failures with full details
- Update task list immediately after each test

---

### Pattern 2: Test Report Generation

Generate detailed reports after completing a test category.

**Implementation:**
See `./examples/test-report-template.md` for complete implementation.

```markdown
# [Category] Test Report

**Date:** YYYY-MM-DD
**Tester:** [Name]
**Environment:** [Staging/Dev]

## Test Summary
- Total Tests: X
- Passed: Y (Z%)
- Failed: A
- Blocked: B
- Not Executed: C

## Test Results

### TC-XXX-001: [Test Name]
**Status:** ✅ Passed
**Execution Time:** HH:MM
**Steps Executed:**
1. Step 1 - Result
2. Step 2 - Result

**Evidence:**
```json
{
  "response": "API response here"
}
```

**Notes:** Any observations

[Repeat for each test]

## Issues Found
1. [Issue description] - Severity: High/Medium/Low
2. [Issue description]

## Recommendations
1. [Recommendation]
```

**Key Points:**
- Generate report immediately after category completion
- Include all test results, not just failures
- Attach evidence files if needed

---

### Pattern 3: Progress Tracking

Track overall test execution progress using task lists.

**Implementation:**
See `./examples/progress-tracking.md` for complete implementation.

```markdown
## Test Category: Authentication (6 tests)

- [x] TC-AUTH-001: Successful Login ✅
- [x] TC-AUTH-002: Get Current User ✅
- [ ] TC-AUTH-003: Unauthorized Access
- [ ] TC-AUTH-004: Forbidden Access
- [ ] TC-AUTH-005: Token Expiration
- [ ] TC-AUTH-006: Logout

**Status:** 2/6 Passed (33%)
```

**Key Points:**
- Update checkboxes as tests complete
- Calculate and display progress percentage
- Use status emojis for quick visual scan

---

### Pattern 4: Test Data Setup

Prepare test environment with required data before execution.

**Implementation:**
See `./examples/test-data-setup.md` for complete implementation.

```bash
# 1. Reset database
make migrate-down
make migrate-up

# 2. Seed initial data
./scripts/seed-test-data.sh

# 3. Create test users in Keycloak
# - superadmin@test.com
# - manager@test.com
# - technician@test.com
# - readonly@test.com

# 4. Sync ICON mock data
curl -X POST http://localhost:8080/api/v1/projects/sync-icon \
  -H "Authorization: Bearer $ADMIN_TOKEN"

# 5. Verify data
curl http://localhost:8080/api/v1/projects
```

**Key Points:**
- Document exact setup steps
- Verify data is loaded correctly
- Use scripts for repeatable setup

---

### Pattern 5: API Test Execution

Execute API tests with proper request formatting and response validation.

**Implementation:**
See `./examples/api-test-execution.md` for complete implementation.

```bash
# Execute API call
RESPONSE=$(curl -s -w "\n%{http_code}" -X POST \
  http://localhost:8080/api/v1/maintenance-requests \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "project_id": "uuid",
    "title": "Test Ticket",
    "priority": "HIGH"
  }')

# Extract status code
STATUS=$(echo "$RESPONSE" | tail -n1)

# Validate response
if [ "$STATUS" -eq 201 ]; then
  echo "✅ Test Passed"
else
  echo "❌ Test Failed: Expected 201, got $STATUS"
  echo "$RESPONSE"
fi
```

**Key Points:**
- Capture full response and status code
- Validate both status and response body
- Log failures with complete details

---

### Pattern 6: Test Category Report

Generate focused report for a single test category.

**Implementation:**
See `./examples/category-report.md` for complete implementation.

```markdown
# Authentication & Authorization Test Report

**Test Category:** TC-AUTH (Authentication & Authorization)
**Total Tests:** 6
**Execution Date:** 2025-12-22
**Tester:** QA Team
**Environment:** Staging

## Summary
| Status | Count | Percentage |
|--------|-------|------------|
| ✅ Passed | 5 | 83.3% |
| ❌ Failed | 1 | 16.7% |
| ⚠️ Blocked | 0 | 0% |
| ⏭️ Not Executed | 0 | 0% |

## Detailed Results

[Individual test results...]

## Critical Issues
1. **Token expiration not handled properly** (TC-AUTH-005)
   - Severity: High
   - Impact: Users not redirected on token expiry
   - Reproduction: [Steps]

## Recommendations
1. Implement automatic token refresh
2. Add better error messages for auth failures
```

**Key Points:**
- Focus on single category
- Include summary metrics table
- Highlight critical findings

## Common Pitfalls

- **Skipping Prerequisites**: Running tests without proper environment setup → Always verify prerequisites checklist first

- **Not Documenting Evidence**: Marking test as passed/failed without saving proof → Always capture API responses and logs

- **Testing Out of Order**: Running dependent tests before dependencies → Follow test sequence defined in test plan

- **Ignoring Blocked Tests**: Not tracking why tests are blocked → Document blockers with clear reasons and resolution path

- **Missing Test Data Cleanup**: Polluted test data affecting subsequent tests → Reset database between test cycles

- **Incomplete Reports**: Generating reports only for failures → Include all test results in reports for complete audit trail

- **Not Updating Progress**: Forgetting to update task list during execution → Update status immediately after each test

- **Mixing Test Environments**: Running tests across different environments → Use consistent environment for entire test cycle

- **Inadequate Issue Documentation**: Logging "test failed" without details → Include reproduction steps, actual vs expected, and evidence

- **No Version Tracking**: Reports without version/date information → Always include test metadata (version, environment, date)

## Resources

For detailed reference materials, see the `./reference/` folder:
- `./reference/test-case-format.md` - Test case specification format
- `./reference/status-definitions.md` - Test status meanings and usage
- `./reference/report-templates.md` - Report structure and examples
- `./reference/api-testing-tools.md` - Tools and utilities for API testing

**Testing Tools:**
- [cURL](https://curl.se/) - Command-line HTTP client
- [jq](https://stedolan.github.io/jq/) - JSON processor for parsing responses
- [Postman](https://www.postman.com/) - API testing platform
- [Bruno](https://www.usebruno.com/) - Open-source API client

**Documentation Standards:**
- [Markdown Guide](https://www.markdownguide.org/) - Markdown formatting reference
- [Test Reporting Best Practices](https://www.softwaretestinghelp.com/test-report/) - Industry standards

**Related Skills:**
- `api-testing` - General API testing patterns
- `test-automation` - Automated test framework setup
- `bug-reporting` - Defect documentation standards
