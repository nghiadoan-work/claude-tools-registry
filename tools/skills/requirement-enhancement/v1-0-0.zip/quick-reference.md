# Requirement Enhancement - Quick Reference

## One-Line Summary

Interactive requirement clarification tool that asks questions with options and generates comprehensive enhanced documentation.

## Command

```bash
# Enhance a requirement file
requirement-enhancement skill on requirement/requirement.md
```

## Process Flow

```
Read Requirement
  ↓
Identify Gaps (functional, technical, non-functional, data, UI/UX, testing, deployment, business)
  ↓
Generate Prioritized Questions (critical path → high impact → dependencies)
  ↓
Ask Questions One-by-One (with 3 options + custom input)
  ↓
Collect Answers
  ↓
Generate Enhanced Document (requirement/[name]-enhanced.md)
  ↓
Provide Summary & Next Steps
```

## Question Structure

Every question includes:
- **Context**: Why this decision matters
- **Question**: Clear, specific question
- **3 Options**: Distinct approaches with trade-offs
- **Custom Input**: Always available via "Other"

## Question Categories (9 Dimensions)

1. **Functional Requirements**
   - User stories, acceptance criteria, edge cases, error scenarios

2. **Technical Specifications**
   - Tech stack, data models, API contracts, integrations

3. **Non-Functional Requirements**
   - Performance, security, scalability, accessibility

4. **Data Requirements**
   - Data sources, validation, persistence, migration

5. **UI/UX Requirements**
   - User flows, wireframes, responsive design, accessibility

6. **Testing Requirements**
   - Testing scope, test data, environments, success criteria

7. **Deployment & Operations**
   - Hosting, infrastructure, monitoring, backups

8. **Business Context**
   - Timeline, budget, KPIs, stakeholders

9. **Dependencies & Constraints**
   - External dependencies, integrations, technical/legal constraints

## Enhanced Document Sections

- Executive Summary
- Original Requirements (preserved)
- Clarifications & Enhancements
  - Functional Requirements
  - Technical Specifications
  - Non-Functional Requirements
  - User Experience
  - Data Requirements
  - Testing Strategy
  - Deployment & Operations
  - Project Constraints
  - Dependencies & Risks
- Implementation Recommendations
- Appendix (assumptions, out of scope, future considerations)
- Q&A Log

## Example Questions

### Authentication
```
Q: What authentication method should be implemented?
Options:
1. OAuth 2.0 (Google, GitHub) - Industry standard, better UX
2. JWT with email/password - Full control, simpler
3. Session-based cookies - Traditional, good for SSR
```

### Database
```
Q: What database should be used for data persistence?
Options:
1. PostgreSQL - Robust, ACID, relational
2. MongoDB - Flexible schema, document-based
3. SQLite - Simple, file-based, good for prototypes
```

### Rendering
```
Q: What rendering strategy should Next.js use?
Options:
1. Server-Side Rendering (SSR) - Dynamic, SEO-friendly
2. Static Site Generation (SSG) - Fast, cached pages
3. Incremental Static Regeneration (ISR) - Best of both
```

## Quality Checks

### Before Asking
- ✅ Question not already answered
- ✅ Question is specific and actionable
- ✅ Options are distinct and viable
- ✅ Options include trade-offs

### Before Writing Enhanced Doc
- ✅ All critical questions answered
- ✅ Answers are consistent
- ✅ Technical details are feasible
- ✅ Requirements are testable
- ✅ Document is comprehensive

## Best Practices

### DO
- Read the entire requirement first
- Prioritize architectural decisions
- Provide context for each question
- Offer diverse, viable options
- Allow custom answers
- Document rationale for decisions
- Adaptive questioning based on previous answers

### DON'T
- Ask obvious questions
- Provide similar options
- Ask more than 4 questions at once
- Use jargon without explanation
- Make assumptions without asking
- Skip documenting rationale

## Output File

**Location**: `requirement/[original-name]-enhanced.md`

**Example**:
- Input: `requirement/requirement.md`
- Output: `requirement/requirement-enhanced.md`

## Success Metrics

- All ambiguities resolved
- Questions are actionable
- Options are well-reasoned
- Enhanced doc is comprehensive
- Requirements are implementation-ready
- Technical feasibility validated
- Clear next steps provided

## Integration Points

- **Input**: Any requirement markdown file
- **Output**: Enhanced requirement markdown file
- **Next Step**: Use with `task-check-list-worker` to generate implementation tasks
- **Validation**: Use with `pr-code-review` to validate against enhanced specs

## Tips

1. **For Users**:
   - Answer honestly based on your needs
   - Use "Other" for custom requirements
   - Ask for clarification if question is unclear

2. **For Skill**:
   - Analyze thoroughly before questioning
   - Prioritize by architectural impact
   - Adapt questions based on answers
   - Document all decisions with rationale

---

**Version**: 1.0.0
**Last Updated**: 2025-11-11
