---
name: requirement-enhancement
description: Analyzes requirement documents to identify ambiguities, uncertainties, and missing details. Asks clarifying questions one by one with 3 best options (or custom input), then generates an enhanced, comprehensive requirement document with all clarifications incorporated.
---

# Requirement Enhancement Skill

## Overview

This skill systematically analyzes requirement documents to:
- Identify ambiguities, uncertainties, and missing critical details
- Ask clarifying questions one by one with 3 contextual options
- Collect answers through interactive dialog
- Generate an enhanced requirement document with all clarifications

## Enhancement Process

### Phase 1: Requirement Analysis

**Step 1: Read the Requirement File**

First, identify and read the requirement file:
- Check the `requirement/` folder for the target file
- Read the entire content to understand scope and context
- Parse the document structure (sections, requirements, constraints)

**Step 2: Identify Uncertainties**

Analyze the requirement across these dimensions:

**Functional Requirements**:
- Are user stories/use cases complete?
- Are acceptance criteria defined?
- Are edge cases considered?
- Are error scenarios documented?

**Technical Specifications**:
- Is the tech stack clearly specified?
- Are data models/schemas defined?
- Are API contracts documented?
- Are integration points clear?

**Non-Functional Requirements**:
- Performance requirements (response times, throughput)?
- Security requirements (authentication, authorization, data protection)?
- Scalability needs (expected users, data volume)?
- Accessibility requirements (WCAG level, supported devices)?

**Data Requirements**:
- Data sources identified?
- Data validation rules specified?
- Data persistence strategy defined?
- Data migration needs (if applicable)?

**UI/UX Requirements**:
- User flow documented?
- Wireframes/mockups needed?
- Responsive design requirements?
- Accessibility considerations?

**Testing Requirements**:
- Testing scope defined?
- Test data requirements?
- Testing environments specified?
- Success criteria defined?

**Deployment & Operations**:
- Deployment environment specified?
- Infrastructure requirements?
- Monitoring/logging needs?
- Backup/recovery strategy?

**Business Context**:
- Project timeline/deadlines?
- Budget constraints?
- Success metrics/KPIs?
- Stakeholders identified?

**Dependencies & Constraints**:
- External dependencies identified?
- Third-party integrations?
- Technical constraints?
- Legal/compliance requirements?

### Phase 2: Question Generation

For each identified uncertainty, generate a clarifying question following this structure:

**Question Components**:
1. **Context**: Brief explanation of why this matters
2. **Question**: Clear, specific question
3. **Options**: 3 well-reasoned options that represent common/best practices
4. **Custom Input**: Always allow user to provide their own answer

**Example Question Structure**:
```
Context: User authentication affects security, UX, and development complexity.

Question: What authentication method should be implemented?

Options:
1. OAuth 2.0 with third-party providers (Google, GitHub) - Industry standard, better UX, less maintenance
2. JWT-based authentication with email/password - Full control, simpler implementation, no third-party dependency
3. Session-based authentication with cookies - Traditional approach, simpler for server-side rendering
```

**Question Quality Criteria**:
- Specific and actionable
- Provides sufficient context for decision-making
- Options represent viable, distinct approaches
- Options include trade-offs (pros/cons)
- Options are ordered by recommendation level (best first)

### Phase 3: Interactive Clarification

**Step 1: Prioritize Questions**

Sort questions by:
1. **Critical Path**: Questions that block other decisions
2. **Impact Level**: High-impact architectural decisions first
3. **Dependencies**: Questions that inform subsequent questions

**Step 2: Ask Questions One by One**

Use the `AskUserQuestion` tool with this format:

```typescript
{
  questions: [{
    question: "What authentication method should be implemented?",
    header: "Auth Method",
    multiSelect: false,
    options: [
      {
        label: "OAuth 2.0 (Google, GitHub)",
        description: "Industry standard, better UX, less maintenance but requires third-party dependency"
      },
      {
        label: "JWT with email/password",
        description: "Full control, simpler implementation, no third-party dependency but requires password management"
      },
      {
        label: "Session-based with cookies",
        description: "Traditional approach, simpler for SSR but requires server-side session storage"
      }
    ]
  }]
}
```

**Question Flow**:
- Ask 1-4 related questions per interaction (use AskUserQuestion's multi-question capability when questions are related)
- Wait for user response before proceeding to next question
- Adapt subsequent questions based on previous answers
- Track all answers for the final document

**Step 3: Handle Custom Answers**

When user selects "Other" or provides custom input:
- Acknowledge the custom answer
- If unclear, ask follow-up question for clarification
- Document the custom answer with full context

### Phase 4: Enhanced Document Generation

**Step 1: Integrate Clarifications**

Take the original requirement and enhance it by:
- Adding new sections for clarified items
- Expanding existing sections with details
- Maintaining original requirement structure where possible
- Clearly marking enhanced sections

**Step 2: Document Structure**

The enhanced document should include:

```markdown
# [Original Requirement Title] - Enhanced

**Original Requirement**: [Original file name]
**Enhanced Date**: [Current date]
**Enhancement Status**: Complete
**Questions Clarified**: [Count]

## Executive Summary

[Brief overview of the requirement and key enhancements]

---

## Original Requirements

[Include original requirements, potentially reorganized for clarity]

---

## Clarifications & Enhancements

### Functional Requirements

#### [Feature/Section Name]

**Original**: [Original requirement text if any]

**Enhanced**:
- [Detailed requirement based on Q&A]
- [Acceptance criteria]
- [Edge cases to handle]

**Decision Rationale**: [Why this approach based on user answers]

### Technical Specifications

#### Architecture & Tech Stack

**Selected Approach**: [Based on user answers]

**Rationale**: [Why this approach]

**Components**:
- [Component 1]: [Description]
- [Component 2]: [Description]

#### Data Models

[Define data structures based on clarifications]

```typescript
interface ExampleModel {
  // Fields based on requirements
}
```

#### API Contracts

[Define API endpoints if applicable]

```
GET /api/example
POST /api/example
```

### Non-Functional Requirements

#### Performance
- Response time: [Specified value]
- Throughput: [Specified value]
- Concurrent users: [Specified value]

#### Security
- Authentication: [Method]
- Authorization: [Approach]
- Data protection: [Requirements]

#### Scalability
- Expected users: [Count/range]
- Data volume: [Estimate]
- Growth projection: [Timeline]

### User Experience

#### User Flows

[Document key user flows]

1. [Flow 1]
   - Step 1
   - Step 2
   - Step 3

#### UI Requirements

- Responsive design: [Requirements]
- Accessibility: [WCAG level, requirements]
- Browser support: [List]

### Data Requirements

#### Data Sources
- [Source 1]: [Description]
- [Source 2]: [Description]

#### Data Validation
- [Field 1]: [Validation rules]
- [Field 2]: [Validation rules]

#### Data Persistence
- Storage: [Technology/approach]
- Backup: [Strategy]
- Retention: [Policy]

### Testing Strategy

#### Testing Scope
- Unit tests: [Coverage]
- Integration tests: [Scope]
- E2E tests: [Key flows]

#### Test Data
- [Data requirement 1]
- [Data requirement 2]

#### Success Criteria
- [Criterion 1]
- [Criterion 2]

### Deployment & Operations

#### Environment
- Hosting: [Platform]
- Infrastructure: [Requirements]

#### Monitoring
- Logging: [Requirements]
- Metrics: [What to track]
- Alerts: [Alert conditions]

### Project Constraints

#### Timeline
- Estimated duration: [Time]
- Key milestones: [List]
- Deadlines: [If any]

#### Resources
- Team size: [If specified]
- Budget: [If specified]

#### Technical Constraints
- [Constraint 1]
- [Constraint 2]

### Dependencies & Risks

#### External Dependencies
- [Dependency 1]: [Description, impact]
- [Dependency 2]: [Description, impact]

#### Risks
- [Risk 1]: [Description, mitigation]
- [Risk 2]: [Description, mitigation]

---

## Implementation Recommendations

### Phase 1: [Phase name]
- [Task 1]
- [Task 2]

### Phase 2: [Phase name]
- [Task 1]
- [Task 2]

---

## Appendix

### Assumptions Made
- [Assumption 1]
- [Assumption 2]

### Out of Scope
- [Item 1]
- [Item 2]

### Future Considerations
- [Consideration 1]
- [Consideration 2]

---

## Q&A Log

[Optional: Document all questions asked and answers received for reference]

| # | Question | Answer | Rationale |
|---|----------|--------|-----------|
| 1 | [Question] | [Answer] | [Why] |
| 2 | [Question] | [Answer] | [Why] |
```

**Step 3: File Naming & Location**

- Extract base name from original file: `requirement.md` → `requirement`
- Create enhanced file: `requirement/[base-name]-enhanced.md`
- Example: `requirement/requirement-enhanced.md`

**Step 4: Quality Checks**

Before finalizing:
- Ensure all questions have been addressed in the document
- Verify technical details are consistent
- Check that enhanced sections add value
- Confirm document is comprehensive and actionable

### Phase 5: Delivery

**Step 1: Write the Enhanced File**

Use the Write tool to create the enhanced markdown file in the `requirement/` folder.

**Step 2: Provide Summary**

After writing the file, provide user with:
- Path to the enhanced file
- Summary of key enhancements
- Count of questions clarified
- Any remaining ambiguities (if any)
- Recommended next steps

**Example Summary**:
```
✅ Enhanced requirement document created: requirement/requirement-enhanced.md

📊 Enhancement Summary:
- Questions clarified: 15
- New sections added: 8
- Original requirements: Preserved and expanded

🎯 Key Enhancements:
- Defined authentication approach (OAuth 2.0)
- Specified data models and API contracts
- Documented performance requirements
- Added testing strategy
- Clarified deployment environment

📋 Recommended Next Steps:
1. Review the enhanced document
2. Share with stakeholders for approval
3. Create technical specification document
4. Begin implementation planning
```

## Execution Guidelines

### When to Use This Skill

Use this skill when:
- Starting a new project with incomplete requirements
- Requirements are too high-level or vague
- Stakeholders need help defining detailed specifications
- Converting user stories to technical requirements
- Before starting implementation to avoid rework

### Question Strategy

**Good Questions**:
- Specific and actionable
- Provide context for why it matters
- Offer well-reasoned options
- Allow for custom answers

**Bad Questions**:
- Too broad or philosophical
- Obvious or already answered in requirement
- Too technical without context
- Binary yes/no without nuance

**Example Good Question**:
```
Question: How should property images be stored and served?

Options:
1. Cloud storage (S3/CloudFront) - Best performance, CDN, scalable but ongoing costs
2. Local file system with CDN - Lower cost, more control but requires server management
3. Third-party image service (Cloudinary) - Full-featured, optimized but vendor lock-in
```

**Example Bad Question**:
```
Question: Do you want to use images? (Too obvious, already stated in requirement)
```

### Handling Different Requirement Types

**User Stories**:
- Focus on acceptance criteria
- Clarify user flows and edge cases
- Define success metrics

**Technical Specs**:
- Focus on architecture decisions
- Clarify integration points
- Define data models and APIs

**Feature Requests**:
- Focus on scope and boundaries
- Clarify user experience details
- Define priorities (must-have vs nice-to-have)

**Business Requirements**:
- Focus on success metrics
- Clarify timeline and resources
- Define stakeholders and approval process

### Adaptive Questioning

**Context-Aware Questions**:
- If user selects "React", ask about state management
- If user selects "Next.js", ask about rendering strategy (SSR/SSG/ISR)
- If user mentions authentication, ask about authorization
- If user specifies database, ask about migration strategy

**Follow-up Questions**:
- If answer is vague, ask for clarification
- If answer creates new uncertainty, address it
- If answer contradicts earlier requirement, flag it

### Quality Assurance

**Before asking questions**:
- ✅ Verify question isn't already answered
- ✅ Check question is specific enough
- ✅ Ensure options are distinct and viable
- ✅ Confirm question is within scope

**Before writing enhanced document**:
- ✅ All critical questions answered
- ✅ Answers are consistent and non-contradictory
- ✅ Technical details are feasible
- ✅ Requirements are testable/verifiable
- ✅ Document is comprehensive

## Tool Usage

### Required Tools

**Read**: To read the original requirement file
**AskUserQuestion**: To ask clarifying questions interactively
**Write**: To create the enhanced requirement document

### AskUserQuestion Usage

**Single Question**:
```typescript
{
  questions: [{
    question: "What database should be used for data persistence?",
    header: "Database",
    multiSelect: false,
    options: [
      { label: "PostgreSQL", description: "Robust, ACID compliant, great for relational data" },
      { label: "MongoDB", description: "Flexible schema, good for document-based data" },
      { label: "SQLite", description: "Simple, file-based, good for prototypes/small apps" }
    ]
  }]
}
```

**Multiple Related Questions** (1-4 questions at once):
```typescript
{
  questions: [
    {
      question: "What rendering strategy should Next.js use?",
      header: "Rendering",
      multiSelect: false,
      options: [...]
    },
    {
      question: "What styling approach should be used?",
      header: "Styling",
      multiSelect: false,
      options: [...]
    }
  ]
}
```

**Multi-Select Question**:
```typescript
{
  questions: [{
    question: "Which third-party services should be integrated?",
    header: "Integrations",
    multiSelect: true,
    options: [
      { label: "Payment (Stripe)", description: "For handling transactions" },
      { label: "Email (SendGrid)", description: "For notifications" },
      { label: "Analytics (GA)", description: "For tracking user behavior" }
    ]
  }]
}
```

## Success Criteria

A successful requirement enhancement:

✅ All critical ambiguities identified and clarified
✅ Questions are specific, actionable, and well-structured
✅ Options provided are viable and distinct
✅ User answers captured accurately
✅ Enhanced document is comprehensive and actionable
✅ Original requirements preserved and expanded
✅ Technical feasibility validated
✅ Requirements are testable and verifiable
✅ Document follows clear structure
✅ Next steps are clear

## Common Question Categories

### Architecture & Design
- Monolith vs microservices
- Server-side rendering vs client-side
- REST vs GraphQL
- Stateful vs stateless

### Data & Storage
- Database selection (SQL vs NoSQL)
- Data model design
- Caching strategy
- File storage approach

### Authentication & Security
- Authentication method
- Authorization approach
- Session management
- Data encryption requirements

### UI/UX
- Responsive design requirements
- Accessibility level
- Browser support
- Design system/framework

### Performance
- Response time requirements
- Concurrent users
- Data volume
- Caching needs

### Testing
- Testing scope
- Test coverage targets
- E2E testing requirements
- Performance testing needs

### Deployment
- Hosting platform
- CI/CD requirements
- Environment setup
- Monitoring needs

## Anti-Patterns to Avoid

**❌ Don't**:
- Ask questions already answered in requirement
- Provide options that are essentially the same
- Ask too many questions at once (more than 4)
- Use technical jargon without explanation
- Make assumptions without asking
- Skip documenting rationale for decisions

**✅ Do**:
- Ask specific, actionable questions
- Provide diverse, viable options with trade-offs
- Group related questions together
- Explain technical terms in options
- Validate all assumptions with questions
- Document why each decision was made

## Example Workflow

```
User: "Enhance the requirement/requirement.md file"

# Phase 1: Analysis
Assistant: [Reads requirement/requirement.md]
Assistant: [Analyzes requirement and identifies 12 uncertainties across 6 categories]

# Phase 2: Clarification (Ask questions one by one or in related groups)
Assistant: [Uses AskUserQuestion with first question about authentication]
User: [Selects "JWT with email/password"]
Assistant: [Asks next batch of related questions about database and storage]
User: [Selects "PostgreSQL" for database]

[... continues through all 12 questions ...]

# Phase 3: Document Generation
Assistant: [Generates requirement-enhanced.md with all clarifications integrated]
Assistant: [Writes file to requirement/requirement-enhanced.md]

# Phase 4: Delivery
Assistant: "✅ Enhanced requirement created at requirement/requirement-enhanced.md"
Assistant: [Provides summary of enhancements and next steps]
```

## Notes

- The skill maintains context across all questions to ask adaptive follow-ups
- Questions are prioritized by architectural impact
- All answers are documented in the enhanced file with rationale
- The skill can handle complex requirements with many ambiguities
- Enhanced documents serve as single source of truth for implementation

## Tips for Effective Requirement Enhancement

1. **Read Carefully**: Understand the full context before identifying gaps
2. **Prioritize Wisely**: Start with architectural decisions that affect other choices
3. **Provide Context**: Each question should explain why it matters
4. **Offer Quality Options**: Research-backed, diverse approaches with clear trade-offs
5. **Stay Focused**: Keep questions specific and actionable
6. **Document Thoroughly**: The enhanced document should be implementation-ready
7. **Think Adaptively**: Use previous answers to inform subsequent questions

## Integration with Other Skills

This skill works well in combination with:
- **task-check-list-worker**: Use enhanced requirements to generate implementation checklists
- **pr-code-review**: Validate implementations against enhanced requirements
- **feature-cleanup**: Use to document removed features comprehensively

---

**Version**: 1.0.0  
**Created**: 2025-11-11  
**Purpose**: Transform vague requirements into comprehensive, actionable specifications
